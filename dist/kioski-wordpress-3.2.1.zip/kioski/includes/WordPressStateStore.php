<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

use Kiosky\Core\StateStore;
use RuntimeException;

final class WordPressStateStore implements StateStore
{
    private const OPTION = 'kiosky_application_state';

    public function load(): array
    {
        $state = get_option(self::OPTION, []);
        return is_array($state) ? $state : [];
    }

    public function save(array $state): void
    {
        if (!update_option(self::OPTION, $state, false) && get_option(self::OPTION, null) !== $state) {
            throw new RuntimeException('Kiosky-Daten konnten nicht in WordPress gespeichert werden.', 500);
        }
    }
}
