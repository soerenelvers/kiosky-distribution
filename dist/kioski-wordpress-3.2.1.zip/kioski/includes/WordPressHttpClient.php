<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

use Kiosky\Core\HttpClient;
use Kiosky\Core\HttpResponse;
use RuntimeException;

final class WordPressHttpClient implements HttpClient
{
    public function request(string $method, string $url, array $headers = [], ?string $body = null, int $timeoutSeconds = 15, bool $allowPrivateNetwork = false, bool $verifyTls = true): HttpResponse
    {
        $response = wp_remote_request($url, [
            'method' => strtoupper($method),
            'headers' => $headers,
            'body' => $body,
            'timeout' => $timeoutSeconds,
            'redirection' => 3,
            // easyjob commonly runs on an internal host at port 8008. Only its
            // explicitly validated requests may bypass WordPress' public-port list.
            'reject_unsafe_urls' => !$allowPrivateNetwork,
            'sslverify' => $verifyTls,
            'user-agent' => 'Kiosky/' . (defined('KIOSKY_PLUGIN_VERSION') ? KIOSKY_PLUGIN_VERSION : 'cms') . ' WordPress',
        ]);
        if (is_wp_error($response)) {
            $message = $response->get_error_message();
            if (str_contains(strtolower($message), 'timed out')) throw new RuntimeException('Der externe Dienst hat das Zeitlimit überschritten.', 504);
            throw new RuntimeException('Der externe Dienst konnte nicht erreicht werden: ' . $message, 502);
        }
        $responseHeaders = [];
        foreach (wp_remote_retrieve_headers($response) as $name => $value) $responseHeaders[(string)$name] = is_array($value) ? implode(', ', $value) : (string)$value;
        return new HttpResponse(
            (int)wp_remote_retrieve_response_code($response),
            $responseHeaders,
            (string)wp_remote_retrieve_body($response),
        );
    }
}
