<?php
/**
 * Plugin Name: Kiosky
 * Description: Eigenständiges Digital-Signage-System für WordPress.
 * Version: 3.2.1
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Update URI: https://api.github.com/repos/soerenelvers/kiosky-distribution/contents/latest.json?ref=main
 * Author: Sören Elvers
 * License: GPL-2.0-or-later
 * Copyright: © 2026 Sören Elvers
 * Text Domain: kiosky
 */

defined('ABSPATH') || exit;

const KIOSKY_PLUGIN_VERSION = '3.2.1';
const KIOSKY_VERSION = '3.2.1';
const KIOSKY_UPDATE_MANIFEST_URL = 'https://api.github.com/repos/soerenelvers/kiosky-distribution/contents/latest.json?ref=main';

require_once __DIR__ . '/includes/Core/StateStore.php';
require_once __DIR__ . '/includes/Core/HttpClient.php';
require_once __DIR__ . '/includes/Core/Crypto.php';
require_once __DIR__ . '/includes/Core/CrewBrainService.php';
require_once __DIR__ . '/includes/Core/EasyJobService.php';
require_once __DIR__ . '/includes/Core/DwdService.php';
require_once __DIR__ . '/includes/Core/TransferService.php';
require_once __DIR__ . '/includes/Core/PublicEventCalendar.php';
require_once __DIR__ . '/includes/Core/Api.php';
require_once __DIR__ . '/includes/WordPressStateStore.php';
require_once __DIR__ . '/includes/WordPressHttpClient.php';
require_once __DIR__ . '/includes/Updater.php';

Kiosky\WordPress\Updater::register(__FILE__, KIOSKY_UPDATE_MANIFEST_URL, KIOSKY_PLUGIN_VERSION);

function kiosky_register_roles(): void {
    add_role('kiosky_administrator', __('Kiosky Administrator', 'kiosky'), [
        'read' => true, 'kiosky_access' => true, 'kiosky_edit' => true, 'kiosky_admin' => true,
    ]);
    add_role('kiosky_editor', __('Kiosky Redakteur', 'kiosky'), [
        'read' => true, 'kiosky_access' => true, 'kiosky_edit' => true,
    ]);
    add_role('kiosky_viewer', __('Kiosky Betrachter', 'kiosky'), [
        'read' => true, 'kiosky_access' => true,
    ]);

    foreach (wp_roles()->roles as $slug => $definition) {
        $role = get_role($slug);
        if (!$role) continue;
        if (!empty($definition['capabilities']['manage_options'])) {
            $role->add_cap('kiosky_access');
            $role->add_cap('kiosky_edit');
            $role->add_cap('kiosky_admin');
        } elseif (!empty($definition['capabilities']['edit_posts'])) {
            $role->add_cap('kiosky_access');
            $role->add_cap('kiosky_edit');
        } elseif ($slug === 'subscriber') {
            $role->add_cap('kiosky_access');
        }
    }
}

/** @return 'admin'|'editor'|'viewer'|null */
function kiosky_current_role(): ?string {
    if (!is_user_logged_in() || !current_user_can('kiosky_access')) return null;
    if (current_user_can('kiosky_admin')) return 'admin';
    if (current_user_can('kiosky_edit')) return 'editor';
    return 'viewer';
}

function kiosky_activate(): void {
    kiosky_register_roles();
    add_rewrite_rule('^kiosky-player/?$', 'index.php?kiosky_app=player', 'top');
    add_rewrite_rule('^kiosky-player-center/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^player/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^kiosky-player-browser/?$', 'index.php?kiosky_app=player-browser', 'top');
    add_rewrite_rule('^kiosky-player-download/([^/]+)/?$', 'index.php?kiosky_app=player-download&kiosky_player_platform=$matches[1]', 'top');
    if (!wp_next_scheduled('kiosky_scheduled_tasks')) {
        wp_schedule_event(time() + 60, 'kiosky_15_minutes', 'kiosky_scheduled_tasks');
    }
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'kiosky_activate');
add_action('init', 'kiosky_register_roles');
function kiosky_deactivate(): void {
    wp_clear_scheduled_hook('kiosky_scheduled_tasks');
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'kiosky_deactivate');

add_filter('cron_schedules', static function (array $schedules): array {
    $schedules['kiosky_15_minutes'] = ['interval' => 15 * MINUTE_IN_SECONDS, 'display' => __('Alle 15 Minuten (Kiosky)', 'kiosky')];
    return $schedules;
});

function kiosky_rewrite_rules(): void {
    add_rewrite_rule('^kiosky-player/?$', 'index.php?kiosky_app=player', 'top');
    add_rewrite_rule('^kiosky-player-center/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^player/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^kiosky-player-browser/?$', 'index.php?kiosky_app=player-browser', 'top');
    add_rewrite_rule('^kiosky-player-download/([^/]+)/?$', 'index.php?kiosky_app=player-download&kiosky_player_platform=$matches[1]', 'top');
}
add_action('init', 'kiosky_rewrite_rules');
add_action('init', static function (): void {
    if (!wp_next_scheduled('kiosky_scheduled_tasks')) {
        wp_schedule_event(time() + 60, 'kiosky_15_minutes', 'kiosky_scheduled_tasks');
    }
});
add_filter('query_vars', static function (array $vars): array {
    $vars[] = 'kiosky_app';
    $vars[] = 'kiosky_player_platform';
    return $vars;
});

function kiosky_register_menu(): void {
    add_menu_page(
        __('Kiosky', 'kiosky'),
        __('Kiosky', 'kiosky'),
        'kiosky_access',
        'kiosky',
        'kiosky_render_admin_page',
        'dashicons-welcome-widgets-menus',
        58
    );
    $items = [
        ['kiosky', __('Übersicht', 'kiosky'), 'kiosky_access'],
        ['kiosky-events', __('Veranstaltungen', 'kiosky'), 'kiosky_access'],
        ['kiosky-displays', __('Displays', 'kiosky'), 'kiosky_access'],
        ['kiosky-content', __('Slides & Kanäle', 'kiosky'), 'kiosky_access'],
        ['kiosky-schedule', __('Zeitplanung', 'kiosky'), 'kiosky_access'],
        ['kiosky-operations', __('Presets & Warnhinweise', 'kiosky'), 'kiosky_edit'],
        ['kiosky-integrations', __('Schnittstellen', 'kiosky'), 'kiosky_admin'],
        ['kiosky-updates', __('Updates', 'kiosky'), 'kiosky_admin'],
        ['kiosky-settings', __('Einstellungen', 'kiosky'), 'kiosky_admin'],
    ];
    foreach ($items as [$slug, $label, $capability]) {
        add_submenu_page('kiosky', $label, $label, $capability, $slug, 'kiosky_render_admin_page');
    }
}
add_action('admin_menu', 'kiosky_register_menu');

function kiosky_view_for_admin_page(string $page): string {
    return [
        'kiosky' => 'dashboard',
        'kiosky-events' => 'events',
        'kiosky-displays' => 'displays',
        'kiosky-content' => 'channels',
        'kiosky-schedule' => 'schedule',
        'kiosky-operations' => 'operations',
        'kiosky-integrations' => 'integrations',
        'kiosky-updates' => 'updates',
        'kiosky-settings' => 'settings',
    ][$page] ?? 'dashboard';
}

function kiosky_render_admin_page(): void {
    if (!current_user_can('kiosky_access')) wp_die(esc_html__('Keine Berechtigung.', 'kiosky'));
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : 'kiosky';
    $url = add_query_arg(['action' => 'kiosky_app', 'view' => kiosky_view_for_admin_page($page)], admin_url('admin-post.php'));
    echo '<div class="wrap" style="margin:0 0 0 -20px">';
    printf(
        '<iframe src="%1$s" title="Kiosky" style="display:block;width:100%%;height:calc(100vh - 32px);min-height:760px;border:0;background:#fff"></iframe>',
        esc_url($url)
    );
    echo '</div>';
}

function kiosky_admin_app(): void {
    if (!current_user_can('kiosky_access')) wp_die(esc_html__('Keine Berechtigung.', 'kiosky'), 403);
    $view = isset($_GET['view']) ? sanitize_key(wp_unslash($_GET['view'])) : 'dashboard';
    $allowed = ['dashboard', 'events', 'displays', 'channels', 'schedule', 'operations', 'integrations', 'updates', 'settings'];
    $role = kiosky_current_role();
    if ($role !== 'admin') $allowed = array_diff($allowed, ['integrations', 'settings']);
    if ($role === 'viewer') $allowed = array_diff($allowed, ['operations']);
    kiosky_output_app(false, in_array($view, $allowed, true) ? $view : 'dashboard');
}
add_action('admin_post_kiosky_app', 'kiosky_admin_app');

function kiosky_public_app(): void {
    $app = (string)get_query_var('kiosky_app');
    if ($app === 'player') kiosky_output_app(true, 'dashboard');
    if ($app === 'player-center') kiosky_output_player_portal('index');
    if ($app === 'player-browser') kiosky_output_player_portal('browser');
    if ($app === 'player-download') kiosky_output_player_download((string)get_query_var('kiosky_player_platform'));
}
add_action('template_redirect', 'kiosky_public_app', 0);

/**
 * Theme-neutrale Website-Ausgabe. Beispiel:
 * [kiosky_event_calendar upcoming="15" show_search="true" show_upcoming="true"]
 *
 * @param array<string,mixed> $attributes
 */
function kiosky_event_calendar_shortcode(array $attributes = []): string {
    $attributes = shortcode_atts([
        'title' => '',
        'upcoming_title' => '',
        'upcoming' => '',
        'show_search' => '',
        'show_upcoming' => '',
    ], $attributes, 'kiosky_event_calendar');
    $overrides = [
        'title' => sanitize_text_field((string)$attributes['title']),
        'upcomingTitle' => sanitize_text_field((string)$attributes['upcoming_title']),
        'upcomingCount' => $attributes['upcoming'] === '' ? null : (int)$attributes['upcoming'],
        'showSearch' => $attributes['show_search'] === '' ? null : filter_var($attributes['show_search'], FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE),
        'showUpcoming' => $attributes['show_upcoming'] === '' ? null : filter_var($attributes['show_upcoming'], FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE),
    ];
    wp_enqueue_style('kiosky-event-calendar', plugin_dir_url(__FILE__) . 'assets/event-calendar/calendar.css', [], KIOSKY_PLUGIN_VERSION);
    wp_enqueue_script('kiosky-event-calendar', plugin_dir_url(__FILE__) . 'assets/event-calendar/calendar.js', [], KIOSKY_PLUGIN_VERSION, true);
    $state = (new Kiosky\WordPress\WordPressStateStore())->load();
    return Kiosky\Core\PublicEventCalendar::render($state, $overrides);
}
add_shortcode('kiosky_event_calendar', 'kiosky_event_calendar_shortcode');

function kiosky_output_app(bool $player, string $initial_view): never {
    $index_path = __DIR__ . '/assets/app/index.html';
    if (!is_readable($index_path)) wp_die(esc_html__('Die Kiosky-Oberfläche fehlt im Pluginpaket.', 'kiosky'), 500);
    $html = (string) file_get_contents($index_path);
    $asset_base = trailingslashit(plugin_dir_url(__FILE__) . 'assets/app');
    $bootstrap = '<base href="' . esc_url($asset_base) . '">'
        . '<meta name="kiosky-platform" content="wordpress">'
        . '<meta name="kiosky-api-endpoint" content="' . esc_url(rest_url('kiosky/v1/api')) . '">'
        . '<meta name="kiosky-asset-base-url" content="' . esc_url(untrailingslashit($asset_base)) . '">'
        . '<meta name="kiosky-player-base-url" content="' . esc_url(home_url('/kiosky-player/')) . '">'
        . '<meta name="kiosky-player-center-url" content="' . esc_url(home_url('/kiosky-player-center/')) . '">'
        . '<meta name="kiosky-initial-view" content="' . esc_attr($initial_view) . '">'
        . ($player ? '' : '<meta name="kiosky-request-header-x-wp-nonce" content="' . esc_attr(wp_create_nonce('wp_rest')) . '">');
    $html = str_replace('<head>', '<head>' . $bootstrap, $html);
    status_header(200);
    nocache_headers();
    header('Content-Type: text/html; charset=utf-8');
    header("Content-Security-Policy: default-src 'self' data: blob: https:; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self'; frame-src https:; object-src 'none'");
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- packaged application HTML
    exit;
}

function kiosky_output_player_portal(string $page): never {
    $path = __DIR__ . '/assets/app/player/' . ($page === 'browser' ? 'browser.html' : 'index.html');
    if (!is_readable($path)) wp_die(esc_html__('Das Kiosky Player Center fehlt im Pluginpaket.', 'kiosky'), 500);
    $asset = trailingslashit(plugin_dir_url(__FILE__) . 'assets/app/player');
    $html = str_replace('/player/', $asset, (string)file_get_contents($path));
    $runtime = $page === 'browser'
        ? '<script>window.KioskyPlayerRuntime=' . wp_json_encode(['apiEndpoint' => rest_url('kiosky/v1/api'), 'playerBaseUrl' => home_url('/kiosky-player/'), 'browserUrl' => home_url('/kiosky-player-browser/')]) . ';</script>'
        : '<script>window.KioskyPlayerCenterRuntime=' . wp_json_encode(['browserUrl' => home_url('/kiosky-player-browser/'), 'downloadBase' => home_url('/kiosky-player-download/')]) . ';</script>';
    $html = str_replace('</head>', $runtime . '</head>', $html);
    status_header(200); nocache_headers(); header('Content-Type: text/html; charset=utf-8');
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    exit;
}

function kiosky_output_player_download(string $platform): never {
    $files = ['windows-x64' => 'kiosky-player-windows-x64.exe', 'windows-x86' => 'kiosky-player-windows-x86.exe', 'linux-x64' => 'kiosky-player-linux-x64', 'macos-universal' => 'kiosky-player-macos-universal'];
    $file = $files[$platform] ?? '';
    $path = $file ? __DIR__ . '/assets/app/launchers/' . $file : '';
    if (!$path || !is_readable($path)) wp_die(esc_html__('Diese Player-Variante ist nicht verfügbar.', 'kiosky'), 404);
    nocache_headers(); header('Content-Type: application/octet-stream'); header('Content-Disposition: attachment; filename="' . basename($file) . '"'); header('Content-Length: ' . filesize($path));
    readfile($path); exit;
}

function kiosky_register_rest_routes(): void {
    register_rest_route('kiosky/v1', '/api', [
        'methods' => WP_REST_Server::ALLMETHODS,
        'callback' => 'kiosky_rest_api',
        'permission_callback' => 'kiosky_rest_permission',
    ]);
}
add_action('rest_api_init', 'kiosky_register_rest_routes');

function kiosky_rest_permission(WP_REST_Request $request): bool {
    $path = (string) $request->get_param('path');
    if ($path === '/api/public/calendar' || preg_match('#^/api/player/[^/]+/(state|heartbeat|proof)$#', $path) || str_starts_with($path, '/api/player-pairings')) return true;
    return kiosky_current_role() !== null;
}

/** @param array{id:string,name:string,email:string,role:string} $identity */
function kiosky_api(array $identity): Kiosky\Core\Api {
    $http = new Kiosky\WordPress\WordPressHttpClient();
    $crypto = new Kiosky\Core\Crypto(wp_salt('auth') . wp_salt('secure_auth'));
    $portableUsers = array_map(static function (WP_User $user): array {
        $role = user_can($user, 'kiosky_admin') || user_can($user, 'manage_options') ? 'admin' : (user_can($user, 'kiosky_edit') ? 'editor' : 'viewer');
        return ['email' => $user->user_email, 'username' => $user->user_login, 'displayName' => $user->display_name ?: $user->user_login, 'role' => $role, 'status' => 'active', 'allLocations' => true, 'locationIds' => []];
    }, get_users(['capability' => 'kiosky_access']));
    return new Kiosky\Core\Api(
        new Kiosky\WordPress\WordPressStateStore(),
        $identity,
        KIOSKY_PLUGIN_VERSION,
        new Kiosky\Core\CrewBrainService($http, $crypto),
        new Kiosky\Core\DwdService($http),
        new Kiosky\Core\EasyJobService($http, $crypto),
        $portableUsers,
        'wordpress',
    );
}

function kiosky_rest_api(WP_REST_Request $request): WP_REST_Response {
    $user = wp_get_current_user();
    $identity = [
        'id' => 'wp:' . (string) $user->ID,
        'name' => $user->display_name ?: $user->user_login,
        'email' => $user->user_email ?: $user->user_login,
        'role' => kiosky_current_role() ?? 'viewer',
    ];
    $body = $request->get_json_params();
    if (!is_array($body)) $body = [];
    $query = $request->get_query_params();
    unset($query['path']);
    $body = array_merge($query, $body);
    $apiPath = (string)$request->get_param('path');
    if (str_starts_with($apiPath, '/api/updates')) {
        if (!current_user_can('kiosky_admin') || !current_user_can('update_plugins')) {
            return new WP_REST_Response(['error' => ['code' => 'FORBIDDEN', 'message' => 'Updates dürfen nur von WordPress-Administratoren installiert werden.']], 403);
        }
        try {
            $update = match ([$request->get_method(), $apiPath]) {
                ['GET', '/api/updates/status'] => Kiosky\WordPress\Updater::status(),
                ['POST', '/api/updates/check'] => Kiosky\WordPress\Updater::status(true),
                ['POST', '/api/updates/install'] => Kiosky\WordPress\Updater::install(),
                default => null,
            };
            return $update === null
                ? new WP_REST_Response(['error' => ['code' => 'NOT_FOUND', 'message' => 'Update-Endpunkt nicht gefunden.']], 404)
                : new WP_REST_Response(['update' => $update, 'scheduled' => false], 200, ['Cache-Control' => 'no-store']);
        } catch (Throwable $error) {
            return new WP_REST_Response(['error' => ['code' => 'UPDATE_FAILED', 'message' => $error->getMessage()]], 422);
        }
    }
    $api = kiosky_api($identity);
    [$status, $payload] = $api->handle(
        $request->get_method(),
        $apiPath,
        $body,
        (string) $request->get_header('X-Player-Key')
    );
    return new WP_REST_Response($payload, $status, ['Cache-Control' => 'no-store']);
}

function kiosky_run_scheduled_tasks(): void {
    if (get_transient('kiosky_scheduled_tasks_lock')) return;
    set_transient('kiosky_scheduled_tasks_lock', '1', 10 * MINUTE_IN_SECONDS);
    try {
        kiosky_api(['id' => 'wp:cron', 'name' => 'WordPress Cron', 'email' => '', 'role' => 'admin'])->runScheduledTasks();
    } finally {
        delete_transient('kiosky_scheduled_tasks_lock');
    }
}
add_action('kiosky_scheduled_tasks', 'kiosky_run_scheduled_tasks');
