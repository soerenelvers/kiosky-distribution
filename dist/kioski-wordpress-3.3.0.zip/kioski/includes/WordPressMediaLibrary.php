<?php

declare(strict_types=1);
namespace Kiosky\WordPress;

use Kiosky\Core\MediaLibrary;
use Kiosky\Core\MediaUpload;
use RuntimeException;

final class WordPressMediaLibrary implements MediaLibrary
{
    public const TAXONOMY = 'kiosky_media_folder';

    public static function register(): void
    {
        register_taxonomy(self::TAXONOMY, 'attachment', ['hierarchical'=>true, 'public'=>false, 'show_ui'=>true, 'show_admin_column'=>true, 'label'=>'Kiosky Medienordner', 'capabilities'=>['manage_terms'=>'upload_files','edit_terms'=>'upload_files','delete_terms'=>'upload_files','assign_terms'=>'upload_files']]);
    }

    public function read(): array
    {
        $folders = [];
        $terms = get_terms(['taxonomy'=>self::TAXONOMY, 'hide_empty'=>false]);
        if (is_wp_error($terms)) throw new RuntimeException($terms->get_error_message(), 500);
        foreach ($terms as $term) $folders[] = ['id'=>'wp-folder:'.$term->term_id, 'name'=>$term->name, 'parentId'=>$term->parent ? 'wp-folder:'.$term->parent : null];
        $assets = [];
        foreach (get_posts(['post_type'=>'attachment','post_status'=>['inherit','private','trash'],'posts_per_page'=>-1,'orderby'=>'ID','order'=>'ASC']) as $post) {
            if (current_user_can('kiosky_access') && !current_user_can('read_post', $post->ID)) continue;
            $assets[] = $this->asset((int)$post->ID);
        }
        return ['folders'=>$folders,'assets'=>$assets];
    }

    private function asset(int $id): array
    {
        $post = get_post($id);
        if (!$post || $post->post_type !== 'attachment') throw new RuntimeException('CMS-Medium nicht gefunden.', 404);
        $meta = get_post_meta($id, '_kiosky_media', true);
        $meta = is_array($meta) ? $meta : [];
        $native = wp_get_attachment_metadata($id);
        $mime = (string)get_post_mime_type($id);
        $terms = wp_get_object_terms($id, self::TAXONOMY, ['fields'=>'ids']);
        $folder = !is_wp_error($terms) && $terms ? 'wp-folder:'.$terms[0] : null;
        return ['id'=>'wp:'.$id,'name'=>$post->post_title,'src'=>(string)wp_get_attachment_url($id),'type'=>str_starts_with($mime,'video/')?'video':($mime==='image/svg+xml'?'icon':(str_starts_with($mime,'image/')?'image':'file')),'folderId'=>$folder,'metadata'=>array_replace($meta,['cms'=>'wordpress','cmsId'=>$id,'mimeType'=>$mime,'width'=>$native['width']??null,'height'=>$native['height']??null]),'deletedAt'=>$post->post_status==='trash'?($meta['deletedAt']??gmdate('c')):null];
    }

    private function writable(?int $id = null): void
    {
        // Scheduled imports have no interactive user; the API supplies its system identity.
        if (wp_get_current_user()->ID && (!current_user_can('upload_files') || ($id && !current_user_can('edit_post', $id)))) throw new RuntimeException('Keine Berechtigung für dieses WordPress-Medium.', 403);
    }

    public function saveFolder(array $folder): array
    {
        $this->writable();
        $parent = (int)str_replace('wp-folder:', '', (string)($folder['parentId']??''));
        $id = str_starts_with($folder['id'],'wp-folder:') ? (int)substr($folder['id'],10) : 0;
        if (!$id) {
            $existing = get_terms(['taxonomy'=>self::TAXONOMY,'hide_empty'=>false,'meta_key'=>'_kiosky_legacy_id','meta_value'=>$folder['id']]);
            if (!is_wp_error($existing) && $existing) $id = (int)$existing[0]->term_id;
        }
        $result = $id ? wp_update_term($id,self::TAXONOMY,['name'=>$folder['name'],'parent'=>$parent]) : wp_insert_term($folder['name'],self::TAXONOMY,['parent'=>$parent]);
        if (is_wp_error($result)) {
            if ($result->get_error_code() !== 'term_exists') throw new RuntimeException($result->get_error_message(),422);
            $id = (int)$result->get_error_data();
        } else $id = (int)$result['term_id'];
        update_term_meta($id,'_kiosky_legacy_id',$folder['id']);
        return ['id'=>'wp-folder:'.$id,'name'=>$folder['name'],'parentId'=>$parent?'wp-folder:'.$parent:null];
    }

    public function deleteFolder(string $id): void
    {
        $this->writable();
        $result = wp_delete_term((int)substr($id,10),self::TAXONOMY);
        if (is_wp_error($result)) throw new RuntimeException($result->get_error_message(),422);
    }

    public function saveAsset(array $asset): array
    {
        $id = str_starts_with($asset['id'],'wp:') ? (int)substr($asset['id'],3) : 0;
        if (!$id) {
            $existing = get_posts(['post_type'=>'attachment','post_status'=>['inherit','trash'],'posts_per_page'=>1,'meta_key'=>'_kiosky_legacy_id','meta_value'=>$asset['id']]);
            if ($existing) $id = (int)$existing[0]->ID;
        }
        $this->writable($id ?: null);
        $src = (string)($asset['src']??'');
        if (!$id && !str_starts_with($src,'data:')) $id = (int)attachment_url_to_postid($src);
        $this->writable($id ?: null);
        if (!$id || $src !== (string)wp_get_attachment_url($id)) {
            if (!str_starts_with($src,'data:')) {
                $response = wp_safe_remote_get($src,['timeout'=>30,'limit_response_size'=>20_000_001]);
                if (is_wp_error($response) || wp_remote_retrieve_response_code($response)!==200) throw new RuntimeException('Das bisherige Medium konnte nicht in WordPress importiert werden.',422);
                $asset['src'] = 'data:application/octet-stream;base64,'.base64_encode(wp_remote_retrieve_body($response));
            }
            $upload = MediaUpload::decode($asset);
            $hash = hash('sha256',$upload['bytes']);
            if (!$id || get_post_meta($id,'_kiosky_content_hash',true) !== $hash) {
                $allowSvg = static fn(array $mimes): array => $mimes + ['svg'=>'image/svg+xml'];
                if ($upload['mime']==='image/svg+xml') add_filter('upload_mimes',$allowSvg);
                try { $file = wp_upload_bits($upload['name'],null,$upload['bytes']); }
                finally { if ($upload['mime']==='image/svg+xml') remove_filter('upload_mimes',$allowSvg); }
                if ($file['error']) throw new RuntimeException((string)$file['error'],422);
                $result = wp_insert_attachment(['ID'=>$id,'post_title'=>$asset['name'],'post_mime_type'=>$upload['mime'],'post_status'=>'inherit'], $file['file'],0,true);
                if (is_wp_error($result)) { wp_delete_file($file['file']); throw new RuntimeException($result->get_error_message(),422); }
                $id = (int)$result;
                require_once ABSPATH.'wp-admin/includes/image.php';
                wp_update_attachment_metadata($id,wp_generate_attachment_metadata($id,$file['file']));
                update_post_meta($id,'_kiosky_content_hash',$hash);
            }
        }
        $result = wp_update_post(['ID'=>$id,'post_title'=>$asset['name']],true);
        if (is_wp_error($result)) throw new RuntimeException($result->get_error_message(),422);
        update_post_meta($id,'_kiosky_legacy_id',$asset['id']);
        update_post_meta($id,'_kiosky_media',array_replace($asset['metadata']??[],['deletedAt'=>$asset['deletedAt']??null]));
        $assigned = wp_set_object_terms($id,empty($asset['folderId'])?[]:[(int)substr($asset['folderId'],10)],self::TAXONOMY);
        if (is_wp_error($assigned)) throw new RuntimeException($assigned->get_error_message(),422);
        if (!empty($asset['deletedAt'])) {
            if (!current_user_can('delete_post',$id) && wp_get_current_user()->ID) throw new RuntimeException('Keine Berechtigung zum Löschen dieses Mediums.',403);
            // Attachments need a real trash state even when MEDIA_TRASH is disabled.
            update_post_meta($id,'_wp_trash_meta_status','inherit');
            wp_update_post(['ID'=>$id,'post_status'=>'trash']);
        } elseif (get_post_status($id)==='trash') wp_update_post(['ID'=>$id,'post_status'=>'inherit']);
        return $this->asset($id);
    }

    public function deleteAsset(string $id): void
    {
        $uid = (int)substr($id,3);
        $this->writable($uid);
        if (wp_get_current_user()->ID && !current_user_can('delete_post',$uid)) throw new RuntimeException('Keine Berechtigung zum Löschen dieses Mediums.',403);
        if (!wp_delete_attachment($uid,true)) throw new RuntimeException('CMS-Medium konnte nicht gelöscht werden.',422);
    }
}
