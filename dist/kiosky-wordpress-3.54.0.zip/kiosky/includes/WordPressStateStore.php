<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

use Kiosky\Core\StateStore;
use Kiosky\Core\ApiAccess;
use Kiosky\Core\StateConflict;
use RuntimeException;

require_once __DIR__.'/WordPressStateMerge.php';

final class WordPressStateStore implements StateStore, \Kiosky\Core\StateSnapshotReader, \Kiosky\Core\PlayerHeartbeatStore
{
    private static function mergePlayerObservations(array $current,array $incoming):array{foreach($incoming as $id=>$value)if(strcmp((string)($value['lastSeenAt']??''),(string)($current[$id]['lastSeenAt']??''))>0)$current[$id]=$value;return $current;}
    private const OPTION = 'kiosky_application_state';
    private const RUNTIME = 'kiosky_player_status_v1';
    private const STATUS_FIELDS = ['channelId','slideId','version','cached','viewportWidth','viewportHeight','devicePixelRatio','lastSeenAt','online','playerHealth','playerConnections'];
    private bool $loaded = false;
    // The snapshot the caller actually saw/submitted. A rebase can persist
    // newer telemetry that is absent from a subsequent save by that caller.
    private ?string $loadedRaw = null;

    public function load(): array
    {
        $raw = $this->readRaw();
        $this->loaded = true;
        $this->loadedRaw = $raw;
        return $this->withHeartbeatStatus($this->decode($raw));
    }

    public function snapshot():array
    {
        return $this->withHeartbeatStatus($this->decode($this->readRaw()));
    }

    /** Store small live observations without serializing/re-writing all content.
     * Configuration changes and command acknowledgements retain normal CAS.
     */
    public function saveHeartbeat(array $before, array $after): bool
    {
        if(!$this->loaded || $this->loadedRaw===null)return false;
        $strip=static function(array $state):array{
            unset($state['updatedAt']);
            if(isset($state['displays']))$state['displays']=array_map(static fn(array $display):array=>array_diff_key($display,array_flip(self::STATUS_FIELDS)),$state['displays']);
            return $state;
        };
        if($strip($before)!==$strip($after))return false;
        $old=array_column($before['displays']??[],null,'id');$changed=[];
        foreach($after['displays']??[] as $display){
            $id=$display['id']??'';
            if(!isset($old[$id]))return false;
            if($old[$id]!==$display)$changed[$id]=$display;
        }
        if(!$changed)return true;
        if(count($changed)!==1)return false;
        // Do not let a stale authenticated request bypass the configuration CAS.
        if($this->readRaw()!==$this->loadedRaw)return false;
        $id=array_key_first($changed);$display=$changed[$id];
        if(!is_string($display['playerKey']??null)||$display['playerKey']==='')return false;
        global $wpdb;
        for($attempt=0;$attempt<10;$attempt++){
            $raw=$this->readRaw(self::RUNTIME);$runtime=$this->decode($raw);
            if(($runtime['schema']??null)!==1)$runtime=['schema'=>1,'displays'=>[]];
            // Deleted displays do not accumulate records indefinitely.
            $active=array_filter($old,static fn(array $row):bool=>empty($row['deletedAt'])&&($row['status']??'')!=='archived');
            $runtime['displays']=array_intersect_key($runtime['displays']??[],$active);
            $fields=array_intersect_key($display,array_flip(self::STATUS_FIELDS));
            $previous=$runtime['displays'][$id]??null;
            if(isset($fields['playerConnections'])||isset($previous['fields']['playerConnections']))$fields['playerConnections']=self::mergePlayerObservations($previous['fields']['playerConnections']??[],$fields['playerConnections']??[]);
            $previousTime=$this->observationTime($previous['fields']??[]);
            if($previous&&hash_equals(hash('sha256',$display['playerKey']),(string)($previous['keyHash']??''))&&$previousTime<=microtime(true)&&$previousTime>$this->observationTime($fields)){
                $observations=$fields['playerConnections']??[];
                if($observations===($previous['fields']['playerConnections']??[]))return true;
                $fields=$previous['fields'];$fields['playerConnections']=$observations;
            }
            $runtime['displays'][$id]=['keyHash'=>hash('sha256',$display['playerKey']),'fields'=>$fields];
            if($raw===null){
                $suppression=$wpdb->suppress_errors();
                try{$created=add_option(self::RUNTIME,$runtime,'',false);}finally{$wpdb->suppress_errors($suppression);}
                if($created)return true;
                if($wpdb->last_error!=='')throw $this->failure('WRITE');
                continue;
            }
            $encoded=maybe_serialize($runtime);
            if($encoded===$raw)return true;
            $validated=$wpdb->strip_invalid_text_for_column($wpdb->options,'option_value',$encoded);
            if(is_wp_error($validated))throw $this->failure('SCHEMA');
            if($validated!==$encoded)throw $this->failure('TEXT_FORMAT');
            $query=$wpdb->prepare('UPDATE %i SET option_value = FROM_BASE64(%s) WHERE option_name = %s AND SHA2(option_value, 256) = %s',$wpdb->options,base64_encode($encoded),self::RUNTIME,hash('sha256',$raw));
            $suppression=$wpdb->suppress_errors();
            try{$written=$wpdb->query($query);}finally{$wpdb->suppress_errors($suppression);}
            if($written===1){wp_cache_delete(self::RUNTIME,'options');return true;}
            if($written===false)throw $this->failure('WRITE');
        }
        throw new StateConflict();
    }

    private function withHeartbeatStatus(array $state):array
    {
        if(empty($state['displays']))return $state;
        $runtime=$this->decode($this->readRaw(self::RUNTIME));
        if(($runtime['schema']??null)!==1)return $state;
        foreach($state['displays'] as &$display){
            if(!empty($display['deletedAt'])||($display['status']??'')==='archived')continue;
            $row=$runtime['displays'][$display['id']]??null;
            // Rekeying, deleting and re-pairing can never resurrect old status.
            if(!$row||!hash_equals(hash('sha256',(string)($display['playerKey']??'')),(string)($row['keyHash']??'')))continue;
            $fields=array_intersect_key($row['fields']??[],array_flip(self::STATUS_FIELDS));
            $storedTime=$this->observationTime($display);
            // A full save may deliberately edit diagnostics at the same observation
            // time; its checkpoint wins ties over the already consumed runtime row.
            if($storedTime<=microtime(true)&&$this->observationTime($fields)<=$storedTime)continue;
            $display=array_replace($display,$fields);
        }
        unset($display);
        return $state;
    }

    private function observationTime(array $fields):float
    {
        $latest=0;
        foreach([$fields['playerHealth']['receivedAt']??null,$fields['lastSeenAt']??null] as $time){
            if(!is_string($time)||$time==='')continue;
            try{$latest=max($latest,(float)(new \DateTimeImmutable($time))->format('U.u'));}catch(\Throwable){}
        }
        return $latest;
    }

    public function save(array $state): void
    {
        global $wpdb;
        // Compare-and-swap prevents a stale request from undoing credential revocations.
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $raw = $this->readRaw();
            if ($this->loaded && $this->loadedRaw !== null && $raw === null) throw new StateConflict();
            if ($raw === null) {
                $previousSuppression = $wpdb->suppress_errors();
                try { $created = add_option(self::OPTION,$state,'',false); }
                finally { $wpdb->suppress_errors($previousSuppression); }
                if ($created) { $this->loaded = true; $this->loadedRaw = maybe_serialize($state); return; }
                if ($wpdb->last_error !== '') throw $this->failure('CREATE');
                continue;
            }
            $current = $this->decode($raw);
            $next = $this->loaded && $raw !== $this->loadedRaw
                ? WordPressStateMerge::merge($this->decode($this->loadedRaw), $state, $current)
                : $state;
            if (isset($state['apiUsers']) || isset($current['apiUsers'])) $next['apiUsers'] = ApiAccess::mergeUsers($next['apiUsers'] ?? [],$current['apiUsers'] ?? []);
            $encoded = maybe_serialize($next);
            if ($encoded === $raw) { $this->loaded = true; $this->loadedRaw = maybe_serialize($state); return; }
            // Preserve WordPress's column-specific validation, including its refusal
            // to silently truncate serialized content. No table charset conversion.
            $validated = $wpdb->strip_invalid_text_for_column($wpdb->options, 'option_value', $encoded);
            if (is_wp_error($validated)) throw $this->failure('SCHEMA');
            if ($validated !== $encoded) throw $this->failure('TEXT_FORMAT');
            // Send the state once. A digest compares the exact previous bytes, rather
            // than doubling large SQL packets or using a case-insensitive text match.
            // The ASCII transport also avoids WordPress's table-wide charset check.
            // FROM_BASE64 stores the original bytes; the option format is unchanged.
            $query = $wpdb->prepare(
                'UPDATE %i SET option_value = FROM_BASE64(%s) WHERE option_name = %s AND SHA2(option_value, 256) = %s',
                $wpdb->options, base64_encode($encoded), self::OPTION, hash('sha256', $raw),
            );
            $packetLimit = $wpdb->get_var('SELECT @@max_allowed_packet');
            if ($wpdb->last_error !== '') throw $this->failure('READ');
            if (is_numeric($packetLimit) && strlen($query) + 1 > (int)$packetLimit) throw $this->failure('PACKET_LIMIT');
            $previousSuppression = $wpdb->suppress_errors();
            try { $changed = $wpdb->query($query); }
            finally { $wpdb->suppress_errors($previousSuppression); }
            if ($changed === 1) {
                $this->loaded = true; $this->loadedRaw = maybe_serialize($state);
                wp_cache_delete(self::OPTION,'options');
                return;
            }
            if ($changed === false) throw $this->failure('WRITE');
        }
        throw new StateConflict();
    }

    private function readRaw(string $option = self::OPTION): ?string
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT option_value FROM %i WHERE option_name = %s', $wpdb->options, $option), ARRAY_A);
        if ($wpdb->last_error !== '') throw $this->failure('READ');
        return $row ? (string)$row['option_value'] : null;
    }

    private function decode(?string $raw): array
    {
        if ($raw === null) return [];
        $state = maybe_unserialize($raw);
        if (!is_array($state)) throw $this->failure('STATE_CORRUPT');
        return $state;
    }

    private function failure(string $reason): RuntimeException
    {
        global $wpdb;
        // Database messages may contain SQL, state and credentials: classify locally
        // and return only fixed, actionable text. Never expose the original error.
        $error = strtolower((string)$wpdb->last_error);
        if (str_contains($error, 'max_allowed_packet') || str_contains($error, 'packet bigger') || str_contains($error, 'packet too large')) $reason = 'PACKET_LIMIT';
        elseif (str_contains($error, 'denied') || str_contains($error, 'read only') || str_contains($error, 'read-only')) $reason = 'PERMISSION';
        elseif (str_contains($error, 'server has gone away') || str_contains($error, 'lost connection')) $reason = 'CONNECTION';
        elseif (str_contains($error, 'incorrect string') || str_contains($error, 'invalid data') || str_contains($error, 'data too long') || str_contains($error, 'illegal mix of collations')) $reason = 'TEXT_FORMAT';
        elseif (str_contains($error, 'disk full') || str_contains($error, 'table is full') || str_contains($error, 'no space left')) $reason = 'DISK_FULL';
        $hint = match ($reason) {
            'PACKET_LIMIT' => 'Der Datenbestand überschreitet das Datenbank-Paketlimit. Der Hoster muss max_allowed_packet erhöhen.',
            'PERMISSION' => 'Die Datenbank verweigert den Schreibzugriff oder ist schreibgeschützt. Bitte die Datenbankrechte beim Hoster prüfen.',
            'CONNECTION' => 'Die Datenbankverbindung wurde unterbrochen. Bitte erneut versuchen; bei Wiederholung den Hoster prüfen lassen.',
            'TEXT_FORMAT' => 'Zeichensatz oder Feldgröße von option_value unterstützen den Datenbestand nicht. Bitte die WordPress-Optionstabelle beim Hoster prüfen lassen.',
            'STATE_CORRUPT' => 'Der vorhandene Datenbestand ist nicht lesbar. Er wird zum Schutz vor Datenverlust nicht überschrieben. Bitte ein Datenbank-Backup prüfen.',
            'DISK_FULL' => 'Der Datenbankspeicher ist voll. Bitte Speicherplatz beim Hoster prüfen lassen.',
            'SCHEMA' => 'Die Datenbankspalte konnte nicht geprüft werden. Bitte die WordPress-Optionstabelle beim Hoster prüfen lassen.',
            'READ' => 'Der vorhandene Datenbestand konnte nicht aus der Datenbank gelesen werden.',
            default => 'Die Datenbank hat den Schreibzugriff abgewiesen. Bitte dem Support diese Fehlerkennung und die installierte Kiosky-Version nennen.',
        };
        return new RuntimeException('Kiosky-Daten konnten nicht in WordPress gespeichert werden. [WP_DB_'.$reason.'] '.$hint, 503);
    }
}
