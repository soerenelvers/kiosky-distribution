ALTER TABLE events ADD COLUMN ticket_links_json TEXT NOT NULL DEFAULT '[]';
