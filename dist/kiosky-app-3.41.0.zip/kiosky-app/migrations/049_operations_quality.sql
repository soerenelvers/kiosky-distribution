CREATE TABLE content_revisions (
 id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
 actor_id TEXT NOT NULL, created_at TEXT NOT NULL, action TEXT NOT NULL,
 title TEXT NOT NULL, digest TEXT NOT NULL, snapshot TEXT, fields_json TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX content_revisions_entity ON content_revisions(entity_type,entity_id,created_at DESC);
CREATE TABLE revision_dirty (
 entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, actor_id TEXT NOT NULL,
 before_json TEXT, PRIMARY KEY(entity_type,entity_id)
);
CREATE TABLE playback_receipts (
 display_id TEXT NOT NULL, receipt_id TEXT NOT NULL, play_id TEXT NOT NULL, slide_id TEXT NOT NULL,
 channel_id TEXT, slide_name TEXT NOT NULL, channel_name TEXT NOT NULL,
 started_at TEXT NOT NULL, ended_at TEXT NOT NULL, seconds REAL NOT NULL,
 received_at TEXT NOT NULL, PRIMARY KEY(display_id,receipt_id)
);
CREATE INDEX playback_receipts_period ON playback_receipts(ended_at,display_id);
CREATE UNIQUE INDEX playback_receipts_interval ON playback_receipts(display_id,started_at,ended_at);
