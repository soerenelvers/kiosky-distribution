<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

use Kiosky\Core\StateStore;
use Kiosky\Core\ApiAccess;
use Kiosky\Core\StateConflict;
use RuntimeException;

final class WordPressStateStore implements StateStore
{
    private const OPTION = 'kiosky_application_state';
    private bool $loaded = false;
    private ?string $loadedRaw = null;

    public function load(): array
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",self::OPTION),ARRAY_A);
        $this->loaded = true;
        $this->loadedRaw = $row ? (string)$row['option_value'] : null;
        $state = $row ? maybe_unserialize($row['option_value']) : [];
        return is_array($state) ? $state : [];
    }

    public function save(array $state): void
    {
        global $wpdb;
        // Compare-and-swap prevents a stale request from undoing credential revocations.
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",self::OPTION),ARRAY_A);
            if ($this->loaded && ($row ? (string)$row['option_value'] : null) !== $this->loadedRaw) throw new StateConflict();
            if (!$row) {
                if (add_option(self::OPTION,$state,'',false)) { $this->loaded = true; $this->loadedRaw = maybe_serialize($state); return; }
                continue;
            }
            $current = maybe_unserialize($row['option_value']);
            if (!is_array($current)) $current = [];
            $next = $state;
            if (isset($state['apiUsers']) || isset($current['apiUsers'])) $next['apiUsers'] = ApiAccess::mergeUsers($state['apiUsers'] ?? [],$current['apiUsers'] ?? []);
            $encoded = maybe_serialize($next);
            if ($encoded === $row['option_value']) return;
            // Validate each column through WordPress, rather than the charset of the
            // entire options table (which can retain utf8 names with utf8mb4 values).
            // Keep the previous value in WHERE so concurrent changes still conflict.
            $changed = $wpdb->update(
                $wpdb->options,
                ['option_value' => $encoded],
                ['option_name' => self::OPTION, 'option_value' => $row['option_value']],
                ['%s'],
                ['%s', '%s'],
            );
            if ($changed === 1) {
                $this->loaded = true; $this->loadedRaw = $encoded;
                wp_cache_delete(self::OPTION,'options');
                return;
            }
            if ($changed === false) throw new RuntimeException('Kiosky-Daten konnten nicht in WordPress gespeichert werden.',503);
        }
        throw new StateConflict();
    }
}
