ALTER TABLE slide_templates RENAME TO slide_templates_legacy_orientation;

CREATE TABLE slide_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  orientation TEXT NOT NULL CHECK (orientation IN ('landscape','portrait','auto')),
  document_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

INSERT INTO slide_templates (id,name,description,orientation,document_json,status,created_at,updated_at)
SELECT id,name,description,orientation,document_json,status,created_at,updated_at
FROM slide_templates_legacy_orientation;

DROP TABLE slide_templates_legacy_orientation;
