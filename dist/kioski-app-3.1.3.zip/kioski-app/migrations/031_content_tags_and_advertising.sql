ALTER TABLE slides ADD COLUMN tags_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE slides ADD COLUMN automation_key TEXT;
ALTER TABLE channels ADD COLUMN tags_json TEXT NOT NULL DEFAULT '[]';
ALTER TABLE channels ADD COLUMN automation_key TEXT;

UPDATE slides
SET tags_json=json_array('Veranstaltung','Veranstaltung:' || COALESCE(NULLIF((SELECT external_number FROM events WHERE events.id=slides.event_id),''),event_id))
WHERE event_id IS NOT NULL;

UPDATE channels
SET tags_json=json_array('Veranstaltung','Veranstaltung:' || COALESCE(NULLIF((SELECT external_number FROM events WHERE events.id=channels.event_id),''),event_id))
WHERE event_id IS NOT NULL;

CREATE UNIQUE INDEX idx_slides_automation_key ON slides(automation_key) WHERE automation_key IS NOT NULL;
CREATE UNIQUE INDEX idx_channels_automation_key ON channels(automation_key) WHERE automation_key IS NOT NULL;

INSERT OR IGNORE INTO integration_settings (setting_key,value_json,updated_at) VALUES
  ('advertising_settings','{"enabled":false,"maximumEvents":15,"eventTypes":[],"templateId":null,"durationSeconds":12,"showDate":false,"showTime":true,"showSeconds":false,"hour12":false,"channelName":"Werbung"}',CURRENT_TIMESTAMP);
