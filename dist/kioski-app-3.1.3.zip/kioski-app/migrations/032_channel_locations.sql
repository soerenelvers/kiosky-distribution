CREATE TABLE channel_locations (
  channel_id TEXT NOT NULL,
  location_id TEXT NOT NULL,
  PRIMARY KEY(channel_id,location_id),
  FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE,
  FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE CASCADE
);

CREATE INDEX idx_channel_locations_location ON channel_locations(location_id,channel_id);

UPDATE integration_settings
SET value_json=json_set(value_json,'$.locationIds',json('[]'))
WHERE setting_key='advertising_settings' AND json_type(value_json,'$.locationIds') IS NULL;
