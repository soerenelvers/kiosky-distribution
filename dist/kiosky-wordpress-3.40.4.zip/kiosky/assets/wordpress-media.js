(() => {
  'use strict';

  const rasterTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif', 'image/bmp', 'image/tiff', 'image/apng', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/heic', 'image/heif'];
  const frames = new Map();

  window.KioskyWordPressMediaPicker = Object.freeze({
    open({ type = '', title = 'WordPress-Mediathek', multiple = false } = {}) {
      return new Promise((resolve, reject) => {
        if (typeof window.wp?.media !== 'function') {
          reject(new Error('Die WordPress-Mediathek konnte nicht geladen werden. Bitte die Verwaltungsseite neu laden.'));
          return;
        }
        const mode = ['video', 'image-only', 'image','font'].includes(type) ? type : 'visual';
        const libraryType = mode==='font'?['font/woff2','font/woff','font/ttf','font/otf','application/font-woff','application/x-font-ttf','application/x-font-opentype']:mode === 'video' ? 'video' : mode === 'image-only' ? rasterTypes : mode === 'image' ? 'image' : ['image', 'video'];
        // Reuse a bounded set of native frames. Destroying a WordPress frame on
        // close races its asynchronous attachment-detail rendering on touch UIs.
        const key = `${mode}:${Boolean(multiple)}`;
        const frame = frames.get(key) || window.wp.media({
          title,
          button: { text: 'In Kiosky verwenden' },
          library: { type: libraryType },
          multiple: multiple ? 'add' : false,
        });
        frames.set(key, frame);
        let settled = false;
        const finish = (id, error) => {
          if (settled) return;
          settled = true;
          // Remove only our handlers: core frame/state listeners must survive.
          window.setTimeout(() => { frame.off('select', onSelect); frame.off('close', onClose); }, 0);
          if (error) reject(error); else resolve(id);
        };
        const onSelect = () => {
          const selection = frame.state().get('selection');
          const attachments = multiple ? selection.toArray() : [selection.first()];
          const ids = [...new Set(attachments.map(attachment => Number(attachment?.get('id'))))];
          if (!ids.length || ids.length > 100 || ids.some(id => !Number.isSafeInteger(id) || id <= 0)) {
            finish(null, new Error('Bitte ein gültiges WordPress-Medium auswählen.'));
            return;
          }
          // Resolve only an ID. The app retrieves URL, permissions and metadata
          // from the existing server-side WordPress media adapter.
          finish(multiple ? ids : ids[0]);
        };
        const onClose = () => window.setTimeout(() => finish(null), 0);
        frame.on('select', onSelect);
        frame.on('close', onClose);
        try {
          frame.open();
          frame.state().get('selection').reset?.();
          frame.state().get('library')?.props?.set('search', '');
          frame.state().set('title', title);
          frame.title.render('default');
        } catch (error) { finish(null, error); }
      });
    },
  });
})();
