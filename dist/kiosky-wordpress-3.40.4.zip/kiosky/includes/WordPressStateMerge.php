<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

use Kiosky\Core\ApiAccess;
use Kiosky\Core\StateConflict;

/** Rebase status-only writes; never merge two configuration edits. */
final class WordPressStateMerge
{
    private const DISPLAY_STATUS = ['channelId','slideId','version','cached','viewportWidth','viewportHeight','devicePixelRatio','lastSeenAt','online'];

    public static function merge(array $base, array $incoming, array $current): array
    {
        $before = self::configuration($base);
        $incomingConfiguration = self::configuration($incoming);
        $currentConfiguration = self::configuration($current);
        if ($incomingConfiguration !== $before && $currentConfiguration !== $before) throw new StateConflict();
        // Revoked/changed machine credentials must force a fresh authorization,
        // even if the request being saved only touched usage/status metadata.
        if (($currentConfiguration['apiUsers'] ?? []) !== ($before['apiUsers'] ?? [])) throw new StateConflict();
        // Do not reinterpret an arbitrary stale no-op as a status request.
        if ($currentConfiguration !== $before && self::status($incoming) === self::status($base)) throw new StateConflict();
        // A handoff was resolved against a particular schedule/target snapshot.
        if ($currentConfiguration !== $before && ($incoming['presetHandoffs'] ?? []) !== ($base['presetHandoffs'] ?? [])) throw new StateConflict();

        $baseDisplays = array_column($base['displays'] ?? [], null, 'id');
        $currentDisplays = array_column($current['displays'] ?? [], null, 'id');
        $baseDelivery = $base['deliveredPlayerCommands'] ?? [];
        $incomingDelivery = $incoming['deliveredPlayerCommands'] ?? [];
        foreach (array_unique(array_merge(array_keys($baseDelivery), array_keys($incomingDelivery))) as $id) {
            if (self::entry($baseDelivery, $id) === self::entry($incomingDelivery, $id)) continue;
            $old = $baseDisplays[$id] ?? null;
            $now = $currentDisplays[$id] ?? null;
            if ($old && (!$now || array_diff_key($old, array_flip(self::DISPLAY_STATUS)) !== array_diff_key($now, array_flip(self::DISPLAY_STATUS)))) throw new StateConflict();
        }

        $result = [];
        foreach (array_unique(array_merge(array_keys($base), array_keys($incoming), array_keys($current))) as $key) {
            if ($key === 'displays') {
                $shape = $currentConfiguration === $before ? $incoming : $current;
                $result[$key] = self::displays($base['displays'] ?? [], $incoming['displays'] ?? [], $current['displays'] ?? [], $shape['displays'] ?? []);
            } elseif ($key === 'apiUsers') {
                $result[$key] = ApiAccess::mergeUsers($incoming[$key] ?? [], $current[$key] ?? []);
            } elseif ($key === 'deliveredPlayerCommands') {
                $result[$key] = self::map($base[$key] ?? [], $incoming[$key] ?? [], $current[$key] ?? []);
            } elseif ($key === 'presetHandoffs') {
                $result[$key] = $current[$key] ?? [];
                foreach ([$base[$key] ?? [], $incoming[$key] ?? []] as $map) foreach ($map as $displayId => $tokens) foreach ($tokens as $token => $released) {
                    if ($released !== true) throw new StateConflict();
                    $result[$key][$displayId][$token] = true;
                }
            } elseif ($key === 'updatedAt' && isset($incoming[$key], $current[$key]) && is_string($incoming[$key]) && is_string($current[$key])) {
                $result[$key] = strtotime($incoming[$key]) > strtotime($current[$key]) ? $incoming[$key] : $current[$key];
            } else {
                [$exists, $value] = self::choose(self::entry($base, $key), self::entry($incoming, $key), self::entry($current, $key));
                if ($exists) $result[$key] = $value;
            }
        }
        return $result;
    }

    private static function configuration(array $state): array
    {
        unset($state['updatedAt'], $state['deliveredPlayerCommands'], $state['presetHandoffs']);
        if (isset($state['displays'])) $state['displays'] = array_map(static fn(array $row): array => array_diff_key($row, array_flip(self::DISPLAY_STATUS)), $state['displays']);
        if (isset($state['apiUsers'])) $state['apiUsers'] = array_map(static fn(array $row): array => array_diff_key($row, array_flip(['lastUsedAt','updatedAt'])), $state['apiUsers']);
        return $state;
    }

    private static function status(array $state): array
    {
        return [
            array_map(static fn(array $row): array => array_intersect_key($row, array_flip(['id', ...self::DISPLAY_STATUS])), $state['displays'] ?? []),
            array_map(static fn(array $row): array => array_intersect_key($row, array_flip(['id','lastUsedAt','updatedAt'])), $state['apiUsers'] ?? []),
            $state['deliveredPlayerCommands'] ?? [],
            $state['presetHandoffs'] ?? [],
        ];
    }

    private static function displays(array $base, array $incoming, array $current, array $shape): array
    {
        $base = array_column($base, null, 'id');
        $incoming = array_column($incoming, null, 'id');
        $current = array_column($current, null, 'id');
        $fields = array_flip(self::DISPLAY_STATUS);
        foreach ($shape as &$display) {
            $id = $display['id'];
            if (!isset($base[$id], $incoming[$id], $current[$id])) continue;
            $b = array_intersect_key($base[$id], $fields);
            $i = array_intersect_key($incoming[$id], $fields);
            $c = array_intersect_key($current[$id], $fields);
            if ($i !== $b && array_diff_key($current[$id], $fields) !== array_diff_key($base[$id], $fields)) throw new StateConflict();
            if ($i === $b) $runtime = $c;
            elseif ($c === $b || $i === $c) $runtime = $i;
            else {
                // A heartbeat is one coherent observation, not a mix of fields
                // from different player versions or currently playing slides.
                $incomingTime = strtotime((string)($i['lastSeenAt'] ?? ''));
                $currentTime = strtotime((string)($c['lastSeenAt'] ?? ''));
                if (!$incomingTime || !$currentTime || $incomingTime === $currentTime) throw new StateConflict();
                $runtime = $incomingTime > $currentTime ? $i : $c;
            }
            $display = array_replace(array_diff_key($display, $fields), $runtime);
        }
        unset($display);
        // A request from a deleted/rekeyed player must be authorized again.
        foreach ($base as $id => $display) {
            if (!isset($incoming[$id])) continue;
            $changed = array_intersect_key($incoming[$id], $fields) !== array_intersect_key($display, $fields);
            if ($changed && !isset($current[$id])) throw new StateConflict();
        }
        return $shape;
    }

    private static function map(array $base, array $incoming, array $current): array
    {
        $result = [];
        foreach (array_unique(array_merge(array_keys($base), array_keys($incoming), array_keys($current))) as $key) {
            [$exists, $value] = self::choose(self::entry($base, $key), self::entry($incoming, $key), self::entry($current, $key));
            if ($exists) $result[$key] = $value;
        }
        return $result;
    }

    private static function entry(array $map, int|string $key): array { return [array_key_exists($key, $map), $map[$key] ?? null]; }
    private static function choose(array $base, array $incoming, array $current): array
    {
        if ($incoming === $base) return $current;
        if ($current === $base || $incoming === $current) return $incoming;
        throw new StateConflict();
    }
}
