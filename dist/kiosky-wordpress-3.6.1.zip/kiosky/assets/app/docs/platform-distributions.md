# Kiosky-Plattformausgaben

Kiosky wird als ein Produkt mit gemeinsamen Oberflächen- und Domainquellen gepflegt.
`pnpm build:platforms` erzeugt aus demselben Commit und derselben Versionsnummer:

- `artifacts/kiosky-app-<version>.zip`
- `artifacts/kiosky-wordpress-<version>.zip`
- `artifacts/kiosky_<version>.zip`

## Laufzeiten

- **Standalone:** Node.js/TypeScript und SQLite.
- **WordPress:** PHP-Domainkern, WordPress REST API, WordPress-Benutzer und lokale
  Speicherung in der WordPress-Datenbank.
- **TYPO3:** derselbe PHP-Domainkern, TYPO3 Backend-/Frontend-Routen,
  TYPO3-Backendbenutzer und lokale Speicherung über Doctrine DBAL.

WordPress und TYPO3 benötigen keinen Kiosky-Standalone- oder Node.js-Server.

Der gemeinsame JavaScript-Player, Editor und API-Vertrag werden bei jedem Build in
alle Ausgaben übernommen. Der PHP-Domainkern unter `platforms/php-core` wird
automatisch in beide CMS-Pakete kopiert. Plattformspezifisch bleiben nur Routing,
Benutzeridentität und der jeweilige State Store.

## Installation

### WordPress

Das WordPress-ZIP über **Plugins → Installieren** hochladen und aktivieren. Kiosky
erscheint mit seinen Arbeitsbereichen als Untermenüs im WordPress-Administrationsmenü.
Die interne Kiosky-Seitenleiste sowie die separaten Bereiche für Medien- und
Benutzerverwaltung werden in WordPress ausgeblendet. Öffentliche Display-URLs
verwenden `/kiosky-player/`.

CrewBrain-Livetest, einmaliger Tokenabruf, Importvorschau, manueller Import und
der tägliche automatische Import laufen über WordPress-HTTP und WP-Cron. Neue externe Integrationen verwenden eigene Kiosky-API-Zugänge unter
**Schnittstellen → Externe API** und die Basisadresse
`/wp-json/kiosky/v1/control` ohne CMS-Anmeldung. Der bisherige Weg mit einem
Administrator und WordPress-Anwendungspasswort bleibt kompatibel.

### TYPO3

Das TYPO3-ZIP als Extension `kiosky` installieren und anschließend ausführen:

```sh
vendor/bin/typo3 extension:setup --extension=kiosky
```

Das Modul erscheint unter **Web → Kiosky**. Öffentliche Display-URLs verwenden
ebenfalls `/kiosky-player/`.

Für den automatischen CrewBrain-Import kann im TYPO3-Scheduler die Aufgabe
**Kiosky: automatischer CrewBrain-Import** eingerichtet werden. Alternativ steht
`vendor/bin/typo3 kiosky:crewbrain:sync` zur Verfügung.

Neue externe Integrationen verwenden eigene Kiosky-API-Zugänge unter
**Schnittstellen → Externe API** und `/kiosky-api/v1`. Bearer oder `X-API-Key`
authentifizieren ohne TYPO3-Backend-Anmeldung. Der bisherige Konfigurationsschlüssel
`externalApiKey` und Query-Einstieg bleiben kompatibel.

## Release

1. Version mit `node scripts/set-version.mjs <version>` zentral setzen und Changelog ergänzen.
2. `pnpm test` und `pnpm test:php` ausführen.
3. `pnpm build:platforms` ausführen.
4. PHP-Syntax der CMS-Pakete prüfen.
5. die drei ZIP-Dateien aus `artifacts/` ausliefern.

## Downloads über GitHub

Der Branch **main** enthält die gemeinsame aktuelle Quelle. Die CI baut und prüft die drei Plattform-Pakete. Stable-Pakete stehen dauerhaft unter **Releases**; die Distribution enthält zusätzlich `latest.json` und alle drei ZIPs. Ein Git-Server benötigt nach dem Pull einen Build und Prozessneustart, siehe [Plesk/Git-Bereitstellung](plesk.md).

Die automatische App-basierte Veröffentlichung bleibt bis zur getrennten Einrichtung deaktiviert. Für ausdrücklich beauftragte Veröffentlichungen gibt es **Kiosky owner-approved release** (`manual-release.yml`): manueller Start auf `main`, Modus `publish`, Bestätigung `PUBLISH KIOSKY`. Dieser prüft zunächst die erfolgreiche vollständige CI derselben SHA und verwendet danach den bestehenden Installations-/Upgrade-Test- und Veröffentlichungsablauf. Ein Tag-Push allein löst keine Veröffentlichung aus.

## CMS-Integration

Die fachlichen Digital-Signage-Funktionen laufen in beiden CMS-Ausgaben lokal:
Veranstaltungen, Slides, Kanäle, Displays und Gruppen, Standorte, Matrix-Displays,
Zeitpläne, Player, Warnhinweise, DWD, CrewBrain und externe
Steuerungszuweisungen. Anmeldung, Benutzerkonten und Medienverwaltung bleiben
bewusst Aufgabe des jeweiligen CMS und werden nicht als zweite Kiosky-Verwaltung
dupliziert.

## Einrichtung, CMS-Medien und Home Assistant

Die [Einrichtungsanleitung](setup-guide.md) führt durch Updates, transparente
Lauftexte, native CMS-Medien, externe API-Zugänge und die öffentliche
[HACS-Integration](https://github.com/soerenelvers/hacs-kiosky).
WordPress nutzt seine Mediathek, TYPO3 FAL; die Standalone-App behält ihre eigene
Medienbibliothek. Details zu API und Migration: [External Control API](external-api.md).

## Speisekarten

Alle drei Ausgaben enthalten Speisekarten-Slides und den geschützten Einstieg
`/speisekarten`. Rechte, Kartenzuweisung und CMS-Anmeldung beschreibt die
[Speisekarten-Anleitung](speisekarten.md).
