ALTER TABLE users ADD COLUMN location_access_mode TEXT NOT NULL DEFAULT 'all'
  CHECK (location_access_mode IN ('all','restricted'));

CREATE TABLE user_location_access (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  location_id TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, location_id)
);

CREATE INDEX idx_user_location_access_location ON user_location_access(location_id, user_id);

CREATE TABLE slide_locations (
  slide_id TEXT NOT NULL REFERENCES slides(id) ON DELETE CASCADE,
  location_id TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  PRIMARY KEY (slide_id, location_id)
);

CREATE INDEX idx_slide_locations_location ON slide_locations(location_id, slide_id);

INSERT INTO feature_settings (feature_key, enabled, updated_at) VALUES
  ('editor_text', 1, CURRENT_TIMESTAMP),
  ('editor_ticker', 1, CURRENT_TIMESTAMP),
  ('editor_weather', 1, CURRENT_TIMESTAMP),
  ('editor_qr-code', 1, CURRENT_TIMESTAMP),
  ('editor_countdown', 1, CURRENT_TIMESTAMP),
  ('editor_image', 1, CURRENT_TIMESTAMP),
  ('editor_video', 1, CURRENT_TIMESTAMP),
  ('editor_web', 1, CURRENT_TIMESTAMP),
  ('editor_event', 1, CURRENT_TIMESTAMP),
  ('editor_event-field', 1, CURRENT_TIMESTAMP),
  ('editor_wayfinding', 1, CURRENT_TIMESTAMP),
  ('editor_alert-icon', 1, CURRENT_TIMESTAMP)
ON CONFLICT(feature_key) DO NOTHING;
