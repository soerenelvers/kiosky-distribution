UPDATE slide_templates
SET document_json = json_set(
  document_json,
  '$.settings', json('{"background":{"mode":"color","color1":"#17342b","color2":"#315b49","direction":"135deg","imageSrc":"","imageFit":"cover","imageX":50,"imageY":50,"imageZoom":100},"logo":{"src":"","position":"top-left"},"clock":{"enabled":true,"position":"bottom-right"}}'),
  '$.elements[0].background', 'transparent',
  '$.elements[0].logo', json('{"src":"","position":"top-left"}'),
  '$.elements[0].clock', json('{"enabled":false,"position":"bottom-right"}')
)
WHERE id IN ('template-wayfinding-landscape','template-wayfinding-portrait');

INSERT OR IGNORE INTO media_folders (id,parent_id,name,created_at,updated_at) VALUES
('system-wayfinding',NULL,'System · Wegweisung','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('system-wayfinding-arrows','system-wayfinding','Pfeile','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z');

INSERT OR IGNORE INTO media_assets (id,folder_id,name,type,src,metadata_json,created_at,updated_at) VALUES
('arrow-up','system-wayfinding-arrows','Pfeil nach oben','icon','/media/arrows/up.svg','{"system":true,"direction":"up"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-down','system-wayfinding-arrows','Pfeil nach unten','icon','/media/arrows/down.svg','{"system":true,"direction":"down"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-left','system-wayfinding-arrows','Pfeil nach links','icon','/media/arrows/left.svg','{"system":true,"direction":"left"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-right','system-wayfinding-arrows','Pfeil nach rechts','icon','/media/arrows/right.svg','{"system":true,"direction":"right"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-up-left','system-wayfinding-arrows','Pfeil nach oben links','icon','/media/arrows/up-left.svg','{"system":true,"direction":"up-left"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-up-right','system-wayfinding-arrows','Pfeil nach oben rechts','icon','/media/arrows/up-right.svg','{"system":true,"direction":"up-right"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-down-left','system-wayfinding-arrows','Pfeil nach unten links','icon','/media/arrows/down-left.svg','{"system":true,"direction":"down-left"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-down-right','system-wayfinding-arrows','Pfeil nach unten rechts','icon','/media/arrows/down-right.svg','{"system":true,"direction":"down-right"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-stairs-up-left','system-wayfinding-arrows','Treppenpfeil nach oben links','icon','/media/arrows/stairs-up-left.svg','{"system":true,"direction":"stairs-up-left"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-stairs-up-right','system-wayfinding-arrows','Treppenpfeil nach oben rechts','icon','/media/arrows/stairs-up-right.svg','{"system":true,"direction":"stairs-up-right"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-stairs-down-left','system-wayfinding-arrows','Treppenpfeil nach unten links','icon','/media/arrows/stairs-down-left.svg','{"system":true,"direction":"stairs-down-left"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('arrow-stairs-down-right','system-wayfinding-arrows','Treppenpfeil nach unten rechts','icon','/media/arrows/stairs-down-right.svg','{"system":true,"direction":"stairs-down-right"}','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z');
