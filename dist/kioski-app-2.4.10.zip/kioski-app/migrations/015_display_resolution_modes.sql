ALTER TABLE displays ADD COLUMN resolution_mode TEXT NOT NULL DEFAULT 'fixed'
  CHECK (resolution_mode IN ('fixed','native'));

ALTER TABLE player_heartbeats ADD COLUMN viewport_width INTEGER;
ALTER TABLE player_heartbeats ADD COLUMN viewport_height INTEGER;
ALTER TABLE player_heartbeats ADD COLUMN device_pixel_ratio REAL;
