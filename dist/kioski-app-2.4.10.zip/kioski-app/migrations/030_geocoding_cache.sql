CREATE TABLE geocoding_cache (
  query_key TEXT PRIMARY KEY,
  query_json TEXT NOT NULL,
  latitude REAL,
  longitude REAL,
  found INTEGER NOT NULL DEFAULT 1,
  provider TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_used_at TEXT NOT NULL
);

CREATE INDEX idx_geocoding_cache_last_used ON geocoding_cache(last_used_at);
