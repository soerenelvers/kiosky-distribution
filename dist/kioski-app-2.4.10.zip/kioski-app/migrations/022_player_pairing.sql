CREATE TABLE IF NOT EXISTS player_pairings (
  id TEXT PRIMARY KEY,
  pairing_code TEXT NOT NULL UNIQUE,
  secret_hash TEXT NOT NULL,
  platform TEXT NOT NULL,
  display_id TEXT REFERENCES displays(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paired','claimed')),
  expires_at TEXT NOT NULL,
  paired_by TEXT,
  paired_at TEXT,
  claimed_at TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_player_pairings_code
ON player_pairings(pairing_code, status, expires_at);

CREATE INDEX IF NOT EXISTS idx_player_pairings_expiry
ON player_pairings(expires_at);
