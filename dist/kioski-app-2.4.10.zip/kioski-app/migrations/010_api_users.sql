CREATE TABLE IF NOT EXISTS api_users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  token_hash TEXT NOT NULL UNIQUE,
  token_prefix TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','revoked')),
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  last_used_at TEXT,
  revoked_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_api_users_status
  ON api_users(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_api_users_token
  ON api_users(token_hash, status);
