CREATE TABLE integration_settings (
  setting_key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

INSERT OR IGNORE INTO integration_settings (setting_key, value_json, updated_at)
SELECT 'title_exclusions', title_exclusions_json, CURRENT_TIMESTAMP
FROM crewbrain_connections
ORDER BY updated_at DESC
LIMIT 1;

INSERT OR IGNORE INTO integration_settings (setting_key, value_json, updated_at)
VALUES ('title_exclusions', '[]', CURRENT_TIMESTAMP);
