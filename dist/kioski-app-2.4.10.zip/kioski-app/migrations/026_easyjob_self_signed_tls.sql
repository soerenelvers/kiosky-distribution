ALTER TABLE easyjob_connections ADD COLUMN allow_self_signed_certificate INTEGER NOT NULL DEFAULT 0;
