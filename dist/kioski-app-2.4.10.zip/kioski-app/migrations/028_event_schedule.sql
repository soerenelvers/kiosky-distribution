CREATE TABLE event_schedule_entries (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  room_id TEXT,
  external_room_id TEXT,
  room_name TEXT,
  room_configuration TEXT,
  type TEXT NOT NULL,
  normalized_type TEXT NOT NULL,
  caption TEXT,
  display_caption TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('access','setup','rehearsal','event','break','hospitality','teardown','internal','cancelled','other')),
  starts_at TEXT NOT NULL,
  ends_at TEXT,
  is_approximate INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL CHECK (source IN ('manual','easyjob')),
  source_id TEXT,
  source_key TEXT NOT NULL,
  external_updated_at TEXT,
  metadata_json TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  missing_since TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(source, source_key)
);

CREATE INDEX idx_event_schedule_event_time
  ON event_schedule_entries(event_id, active, starts_at, sort_order, display_caption);
CREATE INDEX idx_event_schedule_filter
  ON event_schedule_entries(event_id, room_id, category, normalized_type, source);

CREATE TABLE easyjob_room_use_type_mappings (
  normalized_type TEXT PRIMARY KEY,
  original_label TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('access','setup','rehearsal','event','break','hospitality','teardown','internal','cancelled','other')),
  is_approximate INTEGER NOT NULL DEFAULT 0,
  visible INTEGER NOT NULL DEFAULT 1,
  sort_priority INTEGER NOT NULL DEFAULT 0,
  icon TEXT,
  color TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE easyjob_schedule_import_logs (
  id TEXT PRIMARY KEY,
  event_id TEXT REFERENCES events(id) ON DELETE SET NULL,
  actor_type TEXT NOT NULL,
  actor_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('completed','completed_with_errors','failed')),
  started_at TEXT NOT NULL,
  finished_at TEXT NOT NULL,
  duration_ms INTEGER NOT NULL,
  received_count INTEGER NOT NULL DEFAULT 0,
  created_count INTEGER NOT NULL DEFAULT 0,
  updated_count INTEGER NOT NULL DEFAULT 0,
  unchanged_count INTEGER NOT NULL DEFAULT 0,
  skipped_count INTEGER NOT NULL DEFAULT 0,
  invalid_count INTEGER NOT NULL DEFAULT 0,
  unknown_types_json TEXT NOT NULL DEFAULT '[]',
  warnings_json TEXT NOT NULL DEFAULT '[]',
  errors_json TEXT NOT NULL DEFAULT '[]'
);

CREATE INDEX idx_easyjob_schedule_import_started
  ON easyjob_schedule_import_logs(started_at DESC);
