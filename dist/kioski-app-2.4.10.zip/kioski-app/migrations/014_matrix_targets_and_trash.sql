ALTER TABLE schedule_entries RENAME TO schedule_entries_legacy;

CREATE TABLE schedule_entries (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK (target_type IN ('display','group','matrix')),
  target_id TEXT NOT NULL,
  channel_id TEXT NOT NULL REFERENCES channels(id),
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  recurrence TEXT NOT NULL DEFAULT 'once' CHECK (recurrence IN ('once','daily','weekly')),
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','takeover')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','disabled','trashed')),
  description TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  deleted_at TEXT,
  deleted_by TEXT,
  created_by TEXT,
  published_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (ends_at > starts_at)
);

INSERT INTO schedule_entries
  (id,target_type,target_id,channel_id,starts_at,ends_at,recurrence,priority,status,created_by,published_at,created_at,updated_at)
SELECT id,target_type,target_id,channel_id,starts_at,ends_at,recurrence,priority,status,created_by,published_at,created_at,updated_at
FROM schedule_entries_legacy;

DROP TABLE schedule_entries_legacy;
CREATE INDEX idx_schedule_window ON schedule_entries(starts_at, ends_at, status, active);
CREATE INDEX idx_schedule_target ON schedule_entries(target_type, target_id);

ALTER TABLE content_assignments RENAME TO content_assignments_legacy;

CREATE TABLE content_assignments (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK (target_type IN ('display','group','matrix','location','global')),
  target_id TEXT NOT NULL,
  content_type TEXT NOT NULL CHECK (content_type IN ('channel','slide')),
  content_id TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 100 CHECK (priority BETWEEN 0 AND 1000),
  starts_at TEXT,
  expires_at TEXT,
  source TEXT NOT NULL DEFAULT 'external_api',
  created_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (expires_at IS NULL OR starts_at IS NULL OR expires_at > starts_at)
);

INSERT INTO content_assignments SELECT * FROM content_assignments_legacy;
DROP TABLE content_assignments_legacy;
CREATE INDEX idx_content_assignments_target ON content_assignments(target_type, target_id, priority DESC, updated_at DESC);
CREATE INDEX idx_content_assignments_window ON content_assignments(starts_at, expires_at);

ALTER TABLE proof_of_play ADD COLUMN target_type TEXT NOT NULL DEFAULT 'display';
ALTER TABLE proof_of_play ADD COLUMN target_id TEXT;
ALTER TABLE proof_of_play ADD COLUMN schedule_entry_id TEXT;
ALTER TABLE proof_of_play ADD COLUMN source TEXT NOT NULL DEFAULT 'standard';
ALTER TABLE proof_of_play ADD COLUMN status TEXT NOT NULL DEFAULT 'success';
ALTER TABLE proof_of_play ADD COLUMN error_message TEXT;
ALTER TABLE proof_of_play ADD COLUMN planned_start_at TEXT;
ALTER TABLE proof_of_play ADD COLUMN deviation_seconds INTEGER;

CREATE INDEX idx_proof_filters ON proof_of_play(source, status, started_at DESC);
