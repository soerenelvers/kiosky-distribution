ALTER TABLE events ADD COLUMN deleted_at TEXT;
ALTER TABLE events ADD COLUMN deleted_by TEXT;
ALTER TABLE events ADD COLUMN deletion_reason TEXT;

CREATE INDEX IF NOT EXISTS idx_events_deleted ON events(deleted_at, updated_at);
