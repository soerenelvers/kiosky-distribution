ALTER TABLE easyjob_connections ADD COLUMN allow_insecure_http INTEGER NOT NULL DEFAULT 0;

-- Older releases marked every configured connector as enabled. Keep CrewBrain
-- as the active source when both were configured, matching the former UI.
UPDATE external_event_sources
SET enabled = 0, updated_at = CURRENT_TIMESTAMP
WHERE id = 'source-easyjob'
  AND EXISTS (
    SELECT 1
    FROM external_event_sources AS crewbrain
    WHERE crewbrain.id = 'source-crewbrain' AND crewbrain.enabled = 1
  );
