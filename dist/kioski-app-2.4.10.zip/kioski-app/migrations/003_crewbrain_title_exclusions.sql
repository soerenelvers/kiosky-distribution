ALTER TABLE crewbrain_connections ADD COLUMN title_exclusions_json TEXT NOT NULL DEFAULT '[]';
