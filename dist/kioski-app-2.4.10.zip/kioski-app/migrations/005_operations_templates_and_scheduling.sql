CREATE TABLE IF NOT EXISTS slide_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  orientation TEXT NOT NULL CHECK (orientation IN ('landscape','portrait')),
  document_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS displays (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  player_key TEXT NOT NULL UNIQUE,
  orientation TEXT NOT NULL CHECK (orientation IN ('landscape','portrait')),
  default_channel_id TEXT REFERENCES channels(id),
  location TEXT,
  timezone TEXT NOT NULL DEFAULT 'Europe/Berlin',
  status TEXT NOT NULL DEFAULT 'active',
  cache_enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS display_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS display_group_members (
  group_id TEXT NOT NULL REFERENCES display_groups(id) ON DELETE CASCADE,
  display_id TEXT NOT NULL REFERENCES displays(id) ON DELETE CASCADE,
  PRIMARY KEY (group_id, display_id)
);

CREATE TABLE IF NOT EXISTS schedule_entries (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK (target_type IN ('display','group')),
  target_id TEXT NOT NULL,
  channel_id TEXT NOT NULL REFERENCES channels(id),
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  recurrence TEXT NOT NULL DEFAULT 'once' CHECK (recurrence IN ('once','daily','weekly')),
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','takeover')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  created_by TEXT,
  published_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS emergency_alerts (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  targets_json TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  activated_by TEXT,
  activated_at TEXT NOT NULL,
  ended_by TEXT,
  ended_at TEXT
);

CREATE TABLE IF NOT EXISTS player_heartbeats (
  display_id TEXT PRIMARY KEY REFERENCES displays(id) ON DELETE CASCADE,
  current_channel_id TEXT REFERENCES channels(id),
  current_slide_id TEXT REFERENCES slides(id),
  version TEXT,
  cached INTEGER NOT NULL DEFAULT 0,
  online INTEGER NOT NULL DEFAULT 1,
  ip_address TEXT,
  last_seen_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS player_commands (
  id TEXT PRIMARY KEY,
  display_id TEXT NOT NULL REFERENCES displays(id) ON DELETE CASCADE,
  command TEXT NOT NULL CHECK (command IN ('sync','reload')),
  status TEXT NOT NULL DEFAULT 'pending',
  created_by TEXT,
  created_at TEXT NOT NULL,
  acknowledged_at TEXT
);

CREATE TABLE IF NOT EXISTS proof_of_play (
  id TEXT PRIMARY KEY,
  display_id TEXT NOT NULL REFERENCES displays(id) ON DELETE CASCADE,
  channel_id TEXT REFERENCES channels(id),
  slide_id TEXT REFERENCES slides(id),
  content_name TEXT,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  duration_seconds INTEGER,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS operational_presets (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('channel','emergency','reset')),
  channel_id TEXT REFERENCES channels(id),
  config_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_schedule_window ON schedule_entries(starts_at, ends_at, status);
CREATE INDEX IF NOT EXISTS idx_schedule_target ON schedule_entries(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_proof_display_time ON proof_of_play(display_id, started_at);
CREATE INDEX IF NOT EXISTS idx_player_commands_pending ON player_commands(display_id, status, created_at);

INSERT OR IGNORE INTO slide_templates (id,name,description,orientation,document_json,status,created_at,updated_at) VALUES
('template-event-landscape','Veranstaltung · Querformat','Titel, Saal, Einlass und Beginn werden aus der zugeordneten Veranstaltung gefüllt.','landscape','{"elements":[{"id":"template-room","type":"event-field","field":"room","fallback":"VERANSTALTUNG","locked":true,"x":8,"y":12,"width":42,"height":8,"fontSize":22,"color":"#d8e579","background":"#315b49"},{"id":"template-title","type":"event-field","field":"title","fallback":"Veranstaltungstitel","locked":true,"x":8,"y":28,"width":82,"height":28,"fontSize":64,"color":"#ffffff","background":"#315b49"},{"id":"template-admission","type":"event-field","field":"admissionStart","prefix":"Einlass ","fallback":"Zeit folgt","locked":true,"x":8,"y":70,"width":34,"height":10,"fontSize":28,"color":"#ffffff","background":"#315b49"},{"id":"template-start","type":"event-field","field":"eventStart","prefix":"Beginn ","fallback":"Zeit folgt","locked":true,"x":48,"y":70,"width":34,"height":10,"fontSize":28,"color":"#ffffff","background":"#315b49"}]}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('template-event-portrait','Veranstaltung · Hochformat','Hochformat-Vorlage für Titel, Datum, Beginn und Ticketstatus.','portrait','{"elements":[{"id":"portrait-date","type":"event-field","field":"date","fallback":"Datum folgt","locked":true,"x":10,"y":10,"width":80,"height":7,"fontSize":28,"color":"#d8e579","background":"#315b49"},{"id":"portrait-title","type":"event-field","field":"title","fallback":"Veranstaltungstitel","locked":true,"x":10,"y":25,"width":80,"height":30,"fontSize":54,"color":"#ffffff","background":"#315b49"},{"id":"portrait-start","type":"event-field","field":"eventStart","prefix":"Beginn ","fallback":"Zeit folgt","locked":true,"x":10,"y":65,"width":80,"height":9,"fontSize":30,"color":"#ffffff","background":"#315b49"},{"id":"portrait-tickets","type":"event-field","field":"remainingTickets","fallback":"Ticketinformationen folgen","locked":true,"x":10,"y":80,"width":80,"height":9,"fontSize":24,"color":"#ffffff","background":"#315b49"}]}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z');

INSERT OR IGNORE INTO operational_presets (id,name,type,config_json,status,created_at,updated_at) VALUES
('preset-reset','Reset / Standard','reset','{}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('preset-restaurant','Restaurant','channel','{}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('preset-evacuation','Evakuierung','emergency','{"type":"evacuation","title":"Gebäude bitte verlassen","message":"Bitte folgen Sie den ausgeschilderten Fluchtwegen und den Anweisungen des Personals."}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z');
