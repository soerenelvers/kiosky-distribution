ALTER TABLE player_commands RENAME TO player_commands_legacy;

CREATE TABLE player_commands (
  id TEXT PRIMARY KEY,
  display_id TEXT NOT NULL REFERENCES displays(id) ON DELETE CASCADE,
  command TEXT NOT NULL CHECK (command IN ('sync','reload','identify')),
  status TEXT NOT NULL DEFAULT 'pending',
  created_by TEXT,
  created_at TEXT NOT NULL,
  acknowledged_at TEXT
);

INSERT INTO player_commands (id,display_id,command,status,created_by,created_at,acknowledged_at)
SELECT id,display_id,command,status,created_by,created_at,acknowledged_at
FROM player_commands_legacy;

DROP TABLE player_commands_legacy;

CREATE INDEX idx_player_commands_pending
ON player_commands(display_id, status, created_at);
