ALTER TABLE crewbrain_connections ADD COLUMN auto_import_time TEXT NOT NULL DEFAULT '03:00';
