ALTER TABLE user_invitations
  ADD COLUMN status TEXT NOT NULL DEFAULT 'active'
  CHECK (status IN ('active','disabled'));

CREATE INDEX IF NOT EXISTS idx_user_invitations_active
  ON user_invitations(status, accepted_at, expires_at);
