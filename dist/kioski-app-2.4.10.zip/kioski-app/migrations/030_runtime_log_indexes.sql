-- The audit view reads only the newest operational entries.
CREATE INDEX IF NOT EXISTS idx_audit_created_at
  ON audit_logs(created_at DESC);
