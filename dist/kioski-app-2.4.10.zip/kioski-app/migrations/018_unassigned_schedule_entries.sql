ALTER TABLE schedule_entries RENAME TO schedule_entries_legacy;

CREATE TABLE schedule_entries (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK (target_type IN ('display','group','matrix','unassigned')),
  target_id TEXT NOT NULL,
  channel_id TEXT NOT NULL REFERENCES channels(id),
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  recurrence TEXT NOT NULL DEFAULT 'once' CHECK (recurrence IN ('once','daily','weekly')),
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','takeover')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','disabled','trashed')),
  description TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  deleted_at TEXT,
  deleted_by TEXT,
  created_by TEXT,
  published_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (ends_at > starts_at),
  CHECK (target_type != 'unassigned' OR target_id = '')
);

INSERT INTO schedule_entries
  (id,target_type,target_id,channel_id,starts_at,ends_at,recurrence,priority,status,description,active,deleted_at,deleted_by,created_by,published_at,created_at,updated_at)
SELECT
  id,target_type,target_id,channel_id,starts_at,ends_at,recurrence,priority,status,description,active,deleted_at,deleted_by,created_by,published_at,created_at,updated_at
FROM schedule_entries_legacy;

DROP TABLE schedule_entries_legacy;
CREATE INDEX idx_schedule_window ON schedule_entries(starts_at, ends_at, status, active);
CREATE INDEX idx_schedule_target ON schedule_entries(target_type, target_id);
