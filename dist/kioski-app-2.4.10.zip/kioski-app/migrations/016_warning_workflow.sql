INSERT OR IGNORE INTO warning_templates
  (id,name,warning_type,description,document_json,priority,status,created_at,updated_at)
VALUES
  ('warning-template-security','Sicherheitslage','security','Anpassbarer Hinweis für eine allgemeine Sicherheitslage.','{"backgroundColor":"#26364a","textColor":"#ffffff","title":"Sicherheitshinweis","description":"Im Gebäude besteht eine besondere Sicherheitslage.","instructions":"Bleiben Sie ruhig und folgen Sie den Anweisungen des Personals.","symbol":"security","ticker":"","logo":"","image":"","qrCode":"","audio":""}',950,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z');
