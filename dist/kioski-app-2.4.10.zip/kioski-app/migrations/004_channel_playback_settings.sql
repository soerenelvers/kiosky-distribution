ALTER TABLE channels ADD COLUMN default_transition TEXT NOT NULL DEFAULT 'fade';
ALTER TABLE channels ADD COLUMN repeat_enabled INTEGER NOT NULL DEFAULT 1;
