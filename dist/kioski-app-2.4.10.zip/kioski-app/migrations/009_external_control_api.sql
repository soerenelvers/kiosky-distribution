CREATE TABLE IF NOT EXISTS content_assignments (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK (target_type IN ('display','group')),
  target_id TEXT NOT NULL,
  content_type TEXT NOT NULL CHECK (content_type IN ('channel','slide')),
  content_id TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 100 CHECK (priority BETWEEN 0 AND 1000),
  starts_at TEXT,
  expires_at TEXT,
  source TEXT NOT NULL DEFAULT 'external_api',
  created_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (expires_at IS NULL OR starts_at IS NULL OR expires_at > starts_at)
);

CREATE INDEX IF NOT EXISTS idx_content_assignments_target
  ON content_assignments(target_type, target_id, priority DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_content_assignments_window
  ON content_assignments(starts_at, expires_at);

CREATE TABLE IF NOT EXISTS preset_executions (
  id TEXT PRIMARY KEY,
  preset_id TEXT NOT NULL REFERENCES operational_presets(id),
  targets_json TEXT NOT NULL,
  result_json TEXT NOT NULL,
  executed_by TEXT,
  executed_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_preset_executions_preset_time
  ON preset_executions(preset_id, executed_at DESC);
