ALTER TABLE displays ADD COLUMN location_id TEXT REFERENCES locations(id);
ALTER TABLE displays ADD COLUMN display_type TEXT NOT NULL DEFAULT 'standard';
ALTER TABLE displays ADD COLUMN width INTEGER NOT NULL DEFAULT 1920;
ALTER TABLE displays ADD COLUMN height INTEGER NOT NULL DEFAULT 1080;
ALTER TABLE displays ADD COLUMN deleted_at TEXT;
ALTER TABLE displays ADD COLUMN deleted_by TEXT;

ALTER TABLE display_groups ADD COLUMN status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE display_groups ADD COLUMN deleted_at TEXT;
ALTER TABLE display_groups ADD COLUMN deleted_by TEXT;

ALTER TABLE slides ADD COLUMN deleted_at TEXT;
ALTER TABLE slides ADD COLUMN deleted_by TEXT;
ALTER TABLE slides ADD COLUMN deletion_reason TEXT;

ALTER TABLE channels ADD COLUMN deleted_at TEXT;
ALTER TABLE channels ADD COLUMN deleted_by TEXT;
ALTER TABLE channels ADD COLUMN deletion_reason TEXT;

CREATE TABLE IF NOT EXISTS locations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  street TEXT,
  house_number TEXT,
  postal_code TEXT,
  city TEXT,
  country TEXT NOT NULL DEFAULT 'Deutschland',
  description TEXT,
  building_part TEXT,
  floor TEXT,
  room TEXT,
  latitude REAL,
  longitude REAL,
  warning_area_code TEXT,
  timezone TEXT NOT NULL DEFAULT 'Europe/Berlin',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  deleted_at TEXT,
  deleted_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
  CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);

CREATE TABLE IF NOT EXISTS matrix_displays (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  rows INTEGER NOT NULL CHECK (rows BETWEEN 1 AND 50),
  columns INTEGER NOT NULL CHECK (columns BETWEEN 1 AND 50),
  default_channel_id TEXT REFERENCES channels(id),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  deleted_at TEXT,
  deleted_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS matrix_display_members (
  matrix_id TEXT NOT NULL REFERENCES matrix_displays(id) ON DELETE CASCADE,
  display_id TEXT NOT NULL REFERENCES displays(id),
  row_index INTEGER NOT NULL CHECK (row_index >= 0),
  column_index INTEGER NOT NULL CHECK (column_index >= 0),
  orientation TEXT NOT NULL CHECK (orientation IN ('landscape','portrait')),
  physical_width INTEGER NOT NULL CHECK (physical_width > 0),
  physical_height INTEGER NOT NULL CHECK (physical_height > 0),
  bezel_top REAL NOT NULL DEFAULT 0,
  bezel_right REAL NOT NULL DEFAULT 0,
  bezel_bottom REAL NOT NULL DEFAULT 0,
  bezel_left REAL NOT NULL DEFAULT 0,
  crop_json TEXT NOT NULL DEFAULT '{}',
  offset_x REAL NOT NULL DEFAULT 0,
  offset_y REAL NOT NULL DEFAULT 0,
  scale REAL NOT NULL DEFAULT 1 CHECK (scale > 0),
  PRIMARY KEY (matrix_id, display_id),
  UNIQUE (matrix_id, row_index, column_index)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_matrix_active_display
  ON matrix_display_members(display_id);
CREATE INDEX IF NOT EXISTS idx_displays_location ON displays(location_id, status, name);
CREATE INDEX IF NOT EXISTS idx_displays_deleted ON displays(deleted_at, updated_at);
CREATE INDEX IF NOT EXISTS idx_groups_deleted ON display_groups(deleted_at, updated_at);
CREATE INDEX IF NOT EXISTS idx_locations_search ON locations(status, city, name);
CREATE INDEX IF NOT EXISTS idx_locations_deleted ON locations(deleted_at, updated_at);
CREATE INDEX IF NOT EXISTS idx_matrices_deleted ON matrix_displays(deleted_at, updated_at);
CREATE INDEX IF NOT EXISTS idx_slides_deleted ON slides(deleted_at, updated_at);
CREATE INDEX IF NOT EXISTS idx_channels_deleted ON channels(deleted_at, updated_at);

CREATE TABLE IF NOT EXISTS warning_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  warning_type TEXT NOT NULL,
  description TEXT,
  document_json TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 900 CHECK (priority BETWEEN 0 AND 1000),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS warning_providers (
  id TEXT PRIMARY KEY,
  provider_type TEXT NOT NULL CHECK (provider_type IN ('dwd','nina','webhook','manual','internal')),
  name TEXT NOT NULL,
  location_id TEXT REFERENCES locations(id),
  config_json TEXT NOT NULL DEFAULT '{}',
  enabled INTEGER NOT NULL DEFAULT 1,
  confirmation_required INTEGER NOT NULL DEFAULT 1,
  last_checked_at TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS warnings (
  id TEXT PRIMARY KEY,
  provider_id TEXT REFERENCES warning_providers(id),
  external_id TEXT,
  source TEXT NOT NULL,
  warning_type TEXT NOT NULL,
  severity INTEGER NOT NULL DEFAULT 1 CHECK (severity BETWEEN 0 AND 5),
  title TEXT NOT NULL,
  description TEXT,
  instructions TEXT,
  area_name TEXT,
  location_id TEXT REFERENCES locations(id),
  starts_at TEXT,
  ends_at TEXT,
  published_at TEXT,
  ended_at TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','active','ended','dismissed')),
  priority INTEGER NOT NULL DEFAULT 900 CHECK (priority BETWEEN 0 AND 1000),
  targets_json TEXT NOT NULL DEFAULT '[]',
  document_json TEXT NOT NULL DEFAULT '{}',
  return_behavior TEXT NOT NULL DEFAULT 'resume_current_schedule'
    CHECK (return_behavior IN ('resume_previous','resume_current_schedule','standard_content')),
  created_by TEXT,
  ended_by TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(provider_id, external_id)
);

CREATE INDEX IF NOT EXISTS idx_warnings_active ON warnings(status, starts_at, ends_at, priority DESC);
CREATE INDEX IF NOT EXISTS idx_warnings_location ON warnings(location_id, status, updated_at);

CREATE TABLE IF NOT EXISTS permission_grants (
  role TEXT NOT NULL CHECK (role IN ('admin','editor','viewer')),
  permission TEXT NOT NULL,
  allowed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (role, permission)
);

CREATE TABLE IF NOT EXISTS api_request_log (
  id TEXT PRIMARY KEY,
  api_user_id TEXT,
  route TEXT NOT NULL,
  method TEXT NOT NULL,
  status_code INTEGER NOT NULL,
  ip_address TEXT,
  created_at TEXT NOT NULL
);

INSERT OR IGNORE INTO permission_grants (role,permission,allowed) VALUES
('admin','displays.view',1),('admin','displays.edit',1),
('admin','locations.manage',1),('admin','matrices.manage',1),
('admin','schedules.edit',1),('admin','slides.delete',1),
('admin','channels.delete',1),('admin','trash.manage',1),
('admin','presets.api.execute',1),('admin','warnings.create',1),
('admin','warnings.activate',1),('admin','warnings.activate.global',1),
('admin','warning_providers.manage',1),('admin','proof.view',1),
('admin','proof.export',1),
('editor','displays.view',1),('editor','displays.edit',1),
('editor','locations.manage',1),('editor','matrices.manage',1),
('editor','schedules.edit',1),('editor','slides.delete',1),
('editor','channels.delete',1),('editor','warnings.create',1),
('editor','warnings.activate',1),('editor','proof.view',1),
('editor','proof.export',1),
('viewer','displays.view',1),('viewer','proof.view',1);

INSERT OR IGNORE INTO warning_templates
  (id,name,warning_type,description,document_json,priority,status,created_at,updated_at)
VALUES
('warning-template-evacuation','Evakuierung','evacuation','Gebäude oder Bereich geordnet verlassen.','{"backgroundColor":"#9f1d20","textColor":"#ffffff","title":"Gebäude bitte verlassen","instructions":"Folgen Sie den ausgeschilderten Fluchtwegen und den Anweisungen des Personals.","symbol":"evacuation"}',1000,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-technical','Technische Störung','technical','Hinweis auf eine technische Betriebsstörung.','{"backgroundColor":"#6a4b16","textColor":"#ffffff","title":"Technische Störung","instructions":"Bitte beachten Sie die Hinweise des Personals.","symbol":"technical"}',850,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-power','Stromausfall','power_outage','Verhalten bei Ausfall der Stromversorgung.','{"backgroundColor":"#161b22","textColor":"#ffffff","title":"Stromausfall","instructions":"Bleiben Sie ruhig und folgen Sie der Sicherheitsbeleuchtung.","symbol":"power"}',950,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-fire','Brandalarm','fire','Sofortige Räumung bei Brandalarm.','{"backgroundColor":"#c62828","textColor":"#ffffff","title":"Brandalarm","instructions":"Verlassen Sie das Gebäude über die gekennzeichneten Fluchtwege. Benutzen Sie keine Aufzüge.","symbol":"fire"}',1000,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-weather','Unwetterwarnung','severe_weather','Standortbezogene Warnung vor Unwetter.','{"backgroundColor":"#392f78","textColor":"#ffffff","title":"Unwetterwarnung","instructions":"Meiden Sie Außenbereiche und beachten Sie weitere Durchsagen.","symbol":"weather"}',900,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-interruption','Veranstaltungsunterbrechung','event_interruption','Hinweis auf eine vorübergehende Unterbrechung.','{"backgroundColor":"#285078","textColor":"#ffffff","title":"Veranstaltung unterbrochen","instructions":"Bitte bleiben Sie an Ihrem Platz und warten Sie auf weitere Informationen.","symbol":"pause"}',800,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-medical','Medizinischer Notfall','medical','Sicherheitsinformation bei einem medizinischen Notfall.','{"backgroundColor":"#0c6b58","textColor":"#ffffff","title":"Medizinischer Notfall","instructions":"Halten Sie die Rettungswege frei und folgen Sie den Anweisungen des Personals.","symbol":"medical"}',950,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-area-clearance','Räumung eines Bereichs','area_clearance','Gezielte Räumung eines Gebäudebereichs.','{"backgroundColor":"#9f1d20","textColor":"#ffffff","title":"Bereich bitte räumen","instructions":"Verlassen Sie den angegebenen Bereich und folgen Sie der Beschilderung.","symbol":"clearance"}',950,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-all-clear','Entwarnung','all_clear','Aufhebung eines vorherigen Warnhinweises.','{"backgroundColor":"#176b4d","textColor":"#ffffff","title":"Entwarnung","instructions":"Die Warnlage ist beendet. Der reguläre Betrieb wird fortgesetzt.","symbol":"all-clear"}',900,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z'),
('warning-template-information','Allgemeine Sicherheitsinformation','safety_information','Allgemeiner, frei editierbarer Sicherheitshinweis.','{"backgroundColor":"#315b49","textColor":"#ffffff","title":"Sicherheitsinformation","instructions":"Bitte beachten Sie die folgenden Hinweise.","symbol":"information"}',700,'active','2026-07-23T00:00:00.000Z','2026-07-23T00:00:00.000Z');
