CREATE TABLE easyjob_connections (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES external_event_sources(id),
  base_url TEXT NOT NULL,
  encrypted_credentials TEXT,
  sync_enabled INTEGER NOT NULL DEFAULT 0,
  auto_import_time TEXT NOT NULL DEFAULT '03:00',
  lookback_days INTEGER NOT NULL DEFAULT 30,
  lookahead_days INTEGER NOT NULL DEFAULT 365,
  page_size INTEGER NOT NULL DEFAULT 100,
  import_mode TEXT NOT NULL DEFAULT 'projects_with_jobs',
  auto_create_channels INTEGER NOT NULL DEFAULT 1,
  last_success_at TEXT,
  last_sync_at TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE feature_settings (
  feature_key TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);

INSERT INTO feature_settings (feature_key, enabled, updated_at) VALUES
  ('events', 1, CURRENT_TIMESTAMP),
  ('displays', 1, CURRENT_TIMESTAMP),
  ('content', 1, CURRENT_TIMESTAMP),
  ('schedule', 1, CURRENT_TIMESTAMP),
  ('integrations', 1, CURRENT_TIMESTAMP),
  ('presets_warnings', 1, CURRENT_TIMESTAMP)
ON CONFLICT(feature_key) DO NOTHING;

ALTER TABLE schedule_entries RENAME TO schedule_entries_v1;

CREATE TABLE schedule_entries (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK (target_type IN ('display','group','matrix','unassigned')),
  target_id TEXT NOT NULL,
  content_type TEXT NOT NULL DEFAULT 'channel' CHECK (content_type IN ('channel','slide')),
  channel_id TEXT REFERENCES channels(id),
  slide_id TEXT REFERENCES slides(id),
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  recurrence TEXT NOT NULL DEFAULT 'once' CHECK (recurrence IN ('once','daily','weekly','interval')),
  recurrence_starts_at TEXT,
  recurrence_ends_at TEXT,
  recurrence_interval INTEGER NOT NULL DEFAULT 1,
  recurrence_weekdays_json TEXT NOT NULL DEFAULT '[]',
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','takeover')),
  stack_order INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','disabled','trashed')),
  description TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  deleted_at TEXT,
  deleted_by TEXT,
  created_by TEXT,
  published_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (ends_at > starts_at),
  CHECK (target_type != 'unassigned' OR target_id = ''),
  CHECK (
    (content_type = 'channel' AND channel_id IS NOT NULL AND slide_id IS NULL) OR
    (content_type = 'slide' AND slide_id IS NOT NULL AND channel_id IS NULL)
  )
);

INSERT INTO schedule_entries (
  id,target_type,target_id,content_type,channel_id,slide_id,starts_at,ends_at,
  recurrence,priority,stack_order,status,description,active,deleted_at,deleted_by,
  created_by,published_at,created_at,updated_at
)
SELECT
  id,target_type,target_id,'channel',channel_id,NULL,starts_at,ends_at,
  recurrence,priority,CAST(strftime('%s', created_at) AS INTEGER),status,description,
  active,deleted_at,deleted_by,created_by,published_at,created_at,updated_at
FROM schedule_entries_v1;

DROP TABLE schedule_entries_v1;
CREATE INDEX idx_schedule_window ON schedule_entries(starts_at, ends_at, status, active);
CREATE INDEX idx_schedule_target ON schedule_entries(target_type, target_id);
CREATE INDEX idx_schedule_stack ON schedule_entries(target_type, target_id, stack_order);
