PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS external_event_sources (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  name TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crewbrain_connections (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES external_event_sources(id),
  base_url TEXT NOT NULL,
  documentation_url TEXT NOT NULL,
  auth_type TEXT NOT NULL CHECK (auth_type IN ('oauth2','api_key','bearer','basic')),
  encrypted_credentials TEXT,
  sync_enabled INTEGER NOT NULL DEFAULT 1,
  sync_interval_minutes INTEGER NOT NULL DEFAULT 15,
  lookback_days INTEGER NOT NULL DEFAULT 30,
  lookahead_days INTEGER NOT NULL DEFAULT 365,
  page_size INTEGER NOT NULL DEFAULT 100,
  import_strategy TEXT NOT NULL DEFAULT 'project',
  auto_create_channels INTEGER NOT NULL DEFAULT 1,
  auto_create_slides INTEGER NOT NULL DEFAULT 1,
  last_api_version TEXT,
  last_success_at TEXT,
  last_sync_at TEXT,
  next_sync_at TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_field_mappings (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES external_event_sources(id),
  name TEXT NOT NULL,
  mapping_json TEXT NOT NULL,
  is_default INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  source_id TEXT REFERENCES external_event_sources(id),
  external_id TEXT,
  external_parent_id TEXT,
  external_object_type TEXT,
  external_number TEXT,
  title TEXT NOT NULL,
  subtitle TEXT,
  description TEXT,
  organizer TEXT,
  customer TEXT,
  date TEXT,
  setup_start TEXT,
  admission_start TEXT,
  event_start TEXT,
  break_start TEXT,
  break_end TEXT,
  event_end TEXT,
  teardown_end TEXT,
  venue TEXT,
  room TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  category TEXT,
  tags_json TEXT NOT NULL DEFAULT '[]',
  public_notes TEXT,
  internal_notes TEXT,
  image_url TEXT,
  logo_url TEXT,
  ticket_url TEXT,
  remaining_tickets TEXT,
  box_office_available INTEGER,
  box_office_open_at TEXT,
  source_created_at TEXT,
  source_updated_at TEXT,
  last_synced_at TEXT,
  sync_status TEXT NOT NULL DEFAULT 'review_required',
  import_hash TEXT,
  locked_fields_json TEXT NOT NULL DEFAULT '[]',
  source_payload_json TEXT,
  published_at TEXT,
  archived_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(source_id, external_id, external_object_type)
);

CREATE TABLE IF NOT EXISTS channels (
  id TEXT PRIMARY KEY,
  event_id TEXT REFERENCES events(id),
  name TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  priority INTEGER NOT NULL DEFAULT 0,
  starts_at TEXT,
  ends_at TEXT,
  published_at TEXT,
  archived_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS playlists (
  id TEXT PRIMARY KEY,
  channel_id TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  orientation TEXT NOT NULL CHECK (orientation IN ('landscape','portrait','auto')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS slides (
  id TEXT PRIMARY KEY,
  event_id TEXT REFERENCES events(id),
  template_id TEXT,
  name TEXT NOT NULL,
  width INTEGER NOT NULL,
  height INTEGER NOT NULL,
  orientation TEXT NOT NULL,
  schema_version INTEGER NOT NULL DEFAULT 1,
  document_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  current_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS slide_versions (
  id TEXT PRIMARY KEY,
  slide_id TEXT NOT NULL REFERENCES slides(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  document_json TEXT NOT NULL,
  change_note TEXT,
  created_by TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(slide_id, version)
);

CREATE TABLE IF NOT EXISTS playlist_items (
  id TEXT PRIMARY KEY,
  playlist_id TEXT NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
  slide_id TEXT REFERENCES slides(id),
  item_type TEXT NOT NULL,
  position INTEGER NOT NULL,
  duration_seconds INTEGER,
  transition TEXT,
  starts_at TEXT,
  ends_at TEXT,
  priority INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS crewbrain_sync_logs (
  id TEXT PRIMARY KEY,
  connection_id TEXT NOT NULL REFERENCES crewbrain_connections(id),
  status TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  examined_count INTEGER NOT NULL DEFAULT 0,
  created_count INTEGER NOT NULL DEFAULT 0,
  updated_count INTEGER NOT NULL DEFAULT 0,
  conflict_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  details_json TEXT
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_type TEXT NOT NULL,
  actor_id TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  request_id TEXT,
  ip_address TEXT,
  metadata_json TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_source ON events(source_id, external_id);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(date, event_start);
CREATE INDEX IF NOT EXISTS idx_sync_logs_connection ON crewbrain_sync_logs(connection_id, started_at);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id, created_at);
