ALTER TABLE media_assets ADD COLUMN deleted_at TEXT;
CREATE INDEX IF NOT EXISTS idx_media_assets_deleted ON media_assets(deleted_at, updated_at);
