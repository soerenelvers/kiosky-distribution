CREATE TABLE IF NOT EXISTS media_folders (
  id TEXT PRIMARY KEY,
  parent_id TEXT REFERENCES media_folders(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS media_assets (
  id TEXT PRIMARY KEY,
  folder_id TEXT REFERENCES media_folders(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('image','icon','video')),
  src TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_media_folders_parent ON media_folders(parent_id, name);
CREATE INDEX IF NOT EXISTS idx_media_assets_folder ON media_assets(folder_id, name);

INSERT OR IGNORE INTO slide_templates (id,name,description,orientation,document_json,status,created_at,updated_at) VALUES
('template-wayfinding-landscape','Beschilderung / Wegweisung','Flexibles ¼–½–¼-Layout mit Zeilen, Pfeilen, Logo und Uhrzeit.','landscape','{"elements":[{"id":"wayfinding-layout","type":"wayfinding","x":0,"y":0,"width":100,"height":100,"background":"#17342b","color":"#ffffff","rotation":0,"opacity":100,"padding":0,"radius":0,"logo":{"src":"","position":"top-left"},"clock":{"enabled":true,"position":"bottom-right"},"rows":[{"id":"row-main","separator":false,"expandCenter":false,"left":{"kind":"arrow","direction":"right"},"center":{"kind":"text","text":"Großer Saal","textStyle":"heading","align":"left"},"right":{"kind":"text","text":"1. OG","textStyle":"label","align":"right"}},{"id":"row-foyer","separator":true,"expandCenter":false,"left":{"kind":"empty"},"center":{"kind":"text","text":"Foyer & Garderobe","textStyle":"subheading","align":"left"},"right":{"kind":"empty"}},{"id":"row-spacer","separator":false,"expandCenter":false,"left":{"kind":"empty"},"center":{"kind":"empty"},"right":{"kind":"empty"}}]}]}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z'),
('template-wayfinding-portrait','Beschilderung / Wegweisung · Hochformat','Responsive Hochformatvariante des flexiblen Wegweisungs-Layouts.','portrait','{"elements":[{"id":"wayfinding-layout-portrait","type":"wayfinding","x":0,"y":0,"width":100,"height":100,"background":"#17342b","color":"#ffffff","rotation":0,"opacity":100,"padding":0,"radius":0,"logo":{"src":"","position":"top-right"},"clock":{"enabled":true,"position":"bottom-right"},"rows":[{"id":"row-main","separator":false,"expandCenter":false,"left":{"kind":"arrow","direction":"up-right"},"center":{"kind":"text","text":"Großer Saal","textStyle":"heading","align":"left"},"right":{"kind":"text","text":"1. OG","textStyle":"label","align":"right"}},{"id":"row-second","separator":true,"expandCenter":false,"left":{"kind":"arrow","direction":"stairs-up-left"},"center":{"kind":"text","text":"Foyer","textStyle":"subheading","align":"left"},"right":{"kind":"empty"}},{"id":"row-spacer","separator":false,"expandCenter":false,"left":{"kind":"empty"},"center":{"kind":"empty"},"right":{"kind":"empty"}}]}]}','active','2026-07-22T00:00:00.000Z','2026-07-22T00:00:00.000Z');
