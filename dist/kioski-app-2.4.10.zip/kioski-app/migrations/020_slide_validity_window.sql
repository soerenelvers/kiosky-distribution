ALTER TABLE slides ADD COLUMN starts_at TEXT;
ALTER TABLE slides ADD COLUMN ends_at TEXT;

CREATE INDEX IF NOT EXISTS idx_slides_validity
ON slides(starts_at, ends_at, status);
