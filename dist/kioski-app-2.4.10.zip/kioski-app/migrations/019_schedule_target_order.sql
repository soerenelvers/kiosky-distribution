CREATE TABLE IF NOT EXISTS schedule_target_order (
  target_key TEXT PRIMARY KEY,
  position INTEGER NOT NULL CHECK (position >= 0),
  updated_at TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_schedule_target_order_position
ON schedule_target_order(position);
