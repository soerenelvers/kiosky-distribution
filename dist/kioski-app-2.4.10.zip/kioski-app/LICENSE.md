# Kiosky license notice

Copyright © 2026 Sören Elvers. All rights reserved.

Sören Elvers is the original author and copyright holder of Kiosky, except
for third-party components and materials identified separately.

## Proprietary Kiosky software

Unless a file or distribution is expressly identified as open-source
software below, the Kiosky source code, executable files, documentation,
designs, and other materials are proprietary.

No permission to use, reproduce, modify, distribute, sublicense, publish,
sell, or otherwise make this proprietary material available to third
parties is granted without a separate written license agreement from
Sören Elvers.

## WordPress and TYPO3 distributions

The Kiosky packages built specifically for WordPress and TYPO3 are
distributed under the GNU General Public License, version 2 or any later
version (`GPL-2.0-or-later`).

Components owned by Sören Elvers that are shared with the proprietary
Kiosky software are additionally made available under
`GPL-2.0-or-later` when they form part of a Kiosky WordPress or TYPO3
distribution. This additional permission applies only to the respective
GPL distribution and does not change the license of the same components
in the proprietary Kiosky distribution.

The GPL license does not transfer copyright ownership. Recipients receive
the freedoms granted by the GPL while Sören Elvers remains the copyright
holder of his contributions.

## Third-party software

Third-party software and generated materials remain subject to their
respective copyright notices and license terms. Nothing in this notice
grants rights that Kiosky is not entitled to grant.

## Name and branding

The licenses applying to the software do not grant permission to use the
name `Kiosky`, its logos, or associated branding as a trademark or to
imply endorsement by Sören Elvers.
