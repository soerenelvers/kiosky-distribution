// Plesk startup file. The TypeScript application is compiled before activation.
import './dist/server/index.js';
