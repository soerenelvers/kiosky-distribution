<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

final class Updater
{
    private const CACHE_KEY = 'kiosky_update_manifest_v1';
    private const CACHE_TTL = 21600;
    private const LICENSE_OPTION = 'kiosky_update_license_key';
    private static string $pluginFile;
    private static string $manifestUrl;
    private static string $currentVersion;

    public static function register(string $pluginFile, string $manifestUrl, string $currentVersion): void
    {
        self::$pluginFile = $pluginFile;
        self::$manifestUrl = $manifestUrl;
        self::$currentVersion = $currentVersion;
        add_filter('site_transient_update_plugins', [self::class, 'injectUpdate']);
        add_filter('plugins_api', [self::class, 'pluginInformation'], 20, 3);
        add_action('upgrader_process_complete', [self::class, 'clearCache'], 10, 2);
        add_action('delete_site_transient_update_plugins', [self::class, 'clearCache']);
        add_action('admin_init', [self::class, 'registerSettings']);
        add_action('admin_menu', [self::class, 'registerSettingsPage']);
        add_action('update_option_' . self::LICENSE_OPTION, [self::class, 'clearCache']);
        add_filter('upgrader_pre_download', [self::class, 'downloadPrivatePackage'], 10, 4);
    }

    public static function clearCache(): void
    {
        delete_site_transient(self::CACHE_KEY);
    }

    public static function registerSettings(): void
    {
        register_setting('kiosky_updates', self::LICENSE_OPTION, [
            'type' => 'string',
            'sanitize_callback' => static fn(mixed $value): string => trim((string) $value),
            'default' => '',
        ]);
    }

    public static function registerSettingsPage(): void
    {
        add_options_page(
            __('Kiosky Updates', 'kiosky'),
            __('Kiosky Updates', 'kiosky'),
            'manage_options',
            'kiosky-updates',
            [self::class, 'renderSettingsPage']
        );
    }

    public static function renderSettingsPage(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $configuredByConstant = self::constantAccessToken() !== '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Kiosky Updates', 'kiosky'); ?></h1>
            <p><?php echo esc_html__('Der Zugangstoken authentifiziert diese Installation am privaten Kiosky-Distributionsrepository.', 'kiosky'); ?></p>
            <?php if ($configuredByConstant): ?>
                <div class="notice notice-info inline"><p><?php echo esc_html__('Der Zugangstoken wird über KIOSKY_UPDATE_ACCESS_TOKEN in wp-config.php bereitgestellt.', 'kiosky'); ?></p></div>
            <?php else: ?>
                <form method="post" action="options.php">
                    <?php settings_fields('kiosky_updates'); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="kiosky-update-license-key"><?php echo esc_html__('GitHub-Zugangstoken', 'kiosky'); ?></label></th>
                            <td>
                                <input
                                    id="kiosky-update-license-key"
                                    name="<?php echo esc_attr(self::LICENSE_OPTION); ?>"
                                    type="password"
                                    class="regular-text"
                                    value="<?php echo esc_attr((string) get_option(self::LICENSE_OPTION, '')); ?>"
                                    autocomplete="off"
                                >
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function injectUpdate(mixed $transient): mixed
    {
        if (!is_object($transient)) {
            return $transient;
        }
        $manifest = self::manifest();
        $component = $manifest['components']['wordpress'] ?? null;
        if (!is_array($component) || !self::compatible($manifest, $component)) {
            return $transient;
        }
        if (version_compare((string) $component['version'], self::$currentVersion, '<=')) {
            return $transient;
        }
        $plugin = plugin_basename(self::$pluginFile);
        $transient->response[$plugin] = (object) [
            'id' => self::$manifestUrl,
            'slug' => dirname($plugin),
            'plugin' => $plugin,
            'new_version' => (string) $component['version'],
            'url' => (string) ($manifest['release_notes_url'] ?? ''),
            'package' => (string) $component['download_url'],
            'requires' => (string) ($component['requires_wordpress'] ?? ''),
            'requires_php' => (string) ($component['requires_php'] ?? ''),
            'tested' => (string) ($component['tested_up_to'] ?? ''),
        ];
        return $transient;
    }

    public static function pluginInformation(mixed $result, string $action, object $args): mixed
    {
        if ($action !== 'plugin_information' || ($args->slug ?? '') !== dirname(plugin_basename(self::$pluginFile))) {
            return $result;
        }
        $manifest = self::manifest();
        $component = $manifest['components']['wordpress'] ?? null;
        if (!is_array($component)) {
            return $result;
        }
        return (object) [
            'name' => 'Kiosky',
            'slug' => 'kioski',
            'version' => (string) $component['version'],
            'author' => '<a href="https://github.com/soerenelvers/kiosky">Kiosky</a>',
            'homepage' => (string) ($manifest['release_notes_url'] ?? ''),
            'requires' => (string) ($component['requires_wordpress'] ?? ''),
            'requires_php' => (string) ($component['requires_php'] ?? ''),
            'tested' => (string) ($component['tested_up_to'] ?? ''),
            'last_updated' => (string) ($manifest['released_at'] ?? ''),
            'download_link' => (string) ($component['download_url'] ?? ''),
            'sections' => [
                'description' => 'Eigenständiges Digital-Signage-System für WordPress.',
                'changelog' => sprintf(
                    '<p>Release %s – <a href="%s">vollständige Release-Hinweise</a></p>',
                    esc_html((string) $component['version']),
                    esc_url((string) ($manifest['release_notes_url'] ?? ''))
                ),
            ],
        ];
    }

    private static function manifest(): ?array
    {
        $cached = get_site_transient(self::CACHE_KEY);
        if (is_array($cached)) {
            return $cached;
        }
        if (!str_starts_with(self::$manifestUrl, 'https://')) {
            return null;
        }
        $headers = self::requestHeaders(self::$manifestUrl, 'application/json');
        $response = wp_safe_remote_get(self::$manifestUrl, [
            'timeout' => 5,
            'redirection' => 2,
            'headers' => $headers,
        ]);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!self::validManifest($data)) {
            return null;
        }
        set_site_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
        return $data;
    }

    private static function licenseKey(): string
    {
        $constant = self::constantAccessToken();
        if ($constant !== '') return $constant;
        return trim((string) get_option(self::LICENSE_OPTION, ''));
    }

    private static function constantAccessToken(): string
    {
        if (defined('KIOSKY_UPDATE_ACCESS_TOKEN')) {
            return trim((string) constant('KIOSKY_UPDATE_ACCESS_TOKEN'));
        }
        if (defined('KIOSKY_UPDATE_LICENSE_KEY')) {
            return trim((string) constant('KIOSKY_UPDATE_LICENSE_KEY'));
        }
        return '';
    }

    /** @return array<string,string> */
    private static function requestHeaders(string $url, string $accept): array
    {
        $headers = ['Accept' => $accept];
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $token = self::licenseKey();
        if ($host === 'api.github.com' && $token !== '') {
            $headers['Accept'] = 'application/vnd.github.raw+json';
            $headers['Authorization'] = 'Bearer ' . $token;
            $headers['X-GitHub-Api-Version'] = '2022-11-28';
        } elseif ($token !== '') {
            $headers['X-Kiosky-License'] = $token;
        }
        return $headers;
    }

    public static function downloadPrivatePackage(
        mixed $reply,
        string $package,
        mixed $upgrader = null,
        array $hookExtra = []
    ): mixed {
        if ($reply !== false || !self::isPrivateGitHubPackageUrl($package)) {
            return $reply;
        }
        $token = self::licenseKey();
        if ($token === '') {
            return new \WP_Error(
                'kiosky_update_token_missing',
                __('Der Kiosky-Update-Zugangstoken fehlt.', 'kiosky')
            );
        }
        $temporary = wp_tempnam($package);
        if (!$temporary) {
            return new \WP_Error(
                'kiosky_update_temp_file',
                __('Für das Kiosky-Update konnte keine temporäre Datei angelegt werden.', 'kiosky')
            );
        }
        $response = wp_safe_remote_get($package, [
            'timeout' => 300,
            'redirection' => 2,
            'headers' => self::requestHeaders($package, 'application/vnd.github.raw+json'),
            'stream' => true,
            'filename' => $temporary,
        ]);
        if (is_wp_error($response)) {
            @unlink($temporary);
            return $response;
        }
        if (wp_remote_retrieve_response_code($response) !== 200) {
            @unlink($temporary);
            return new \WP_Error(
                'kiosky_update_download_failed',
                __('Das private Kiosky-Update konnte nicht heruntergeladen werden.', 'kiosky')
            );
        }
        return $temporary;
    }

    private static function isPrivateGitHubPackageUrl(string $url): bool
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $path = (string) parse_url($url, PHP_URL_PATH);
        return $host === 'api.github.com'
            && preg_match('#^/repos/[^/]+/[^/]+/contents/dist/kioski-wordpress-[^/]+\.zip$#', $path) === 1;
    }

    private static function validManifest(mixed $data): bool
    {
        if (!is_array($data) || ($data['schema_version'] ?? null) !== 1 || ($data['product'] ?? null) !== 'kioski') {
            return false;
        }
        if (($data['channel'] ?? null) !== 'stable' || !preg_match('/^\d+\.\d+\.\d+$/', (string) ($data['version'] ?? ''))) {
            return false;
        }
        $component = $data['components']['wordpress'] ?? null;
        return is_array($component)
            && ($component['version'] ?? null) === $data['version']
            && str_starts_with((string) ($component['download_url'] ?? ''), 'https://')
            && preg_match('/^[a-f0-9]{64}$/', (string) ($component['sha256'] ?? '')) === 1;
    }

    private static function compatible(array $manifest, array $component): bool
    {
        if (($manifest['compatibility']['api_version'] ?? '') !== '1') {
            return false;
        }
        if (isset($component['requires_php']) && version_compare(PHP_VERSION, (string) $component['requires_php'], '<')) {
            return false;
        }
        global $wp_version;
        return !isset($component['requires_wordpress'])
            || version_compare((string) $wp_version, (string) $component['requires_wordpress'], '>=');
    }
}
