-- Preserve generic CMS attachments (for example PDFs) in content packages.
CREATE TABLE media_assets_portable (
  id TEXT PRIMARY KEY,
  folder_id TEXT REFERENCES media_folders(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('image','icon','video','file')),
  src TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
INSERT INTO media_assets_portable (id,folder_id,name,type,src,metadata_json,created_at,updated_at,deleted_at)
SELECT id,folder_id,name,type,src,metadata_json,created_at,updated_at,deleted_at FROM media_assets;
DROP TABLE media_assets;
ALTER TABLE media_assets_portable RENAME TO media_assets;
CREATE INDEX idx_media_assets_folder ON media_assets(folder_id,name);
CREATE INDEX idx_media_assets_deleted ON media_assets(deleted_at,updated_at);
