CREATE TABLE zugangswerk_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  enabled INTEGER NOT NULL DEFAULT 0,
  revision INTEGER NOT NULL DEFAULT 1,
  client_id TEXT NOT NULL,
  secret_encrypted TEXT NOT NULL,
  redirect_uri TEXT NOT NULL
);
CREATE TABLE zugangswerk_identities (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL UNIQUE,
  verified_revision INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE zugangswerk_flows (
  token_hash TEXT PRIMARY KEY,
  payload_encrypted TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
ALTER TABLE user_sessions ADD COLUMN auth_provider TEXT NOT NULL DEFAULT 'local';
ALTER TABLE user_sessions ADD COLUMN auth_revision INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_sessions ADD COLUMN auth_subject TEXT;
