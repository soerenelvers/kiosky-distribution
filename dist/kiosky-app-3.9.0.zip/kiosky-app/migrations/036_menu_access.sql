-- Separate interactive menu permission and explicit slide assignments.
CREATE TABLE menu_access (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
  slide_ids_json TEXT NOT NULL DEFAULT '[]'
);
