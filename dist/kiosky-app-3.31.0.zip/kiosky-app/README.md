# Kiosky 3.31.0

Webbasiertes Digital-Signage-System für Veranstaltungen, Displays, Displaygruppen, Standorte, Matrix-Displays, Kanäle, Slides, Zeitpläne und Warnhinweise.

Copyright © 2026 Sören Elvers. Lizenzzuordnung und Nutzungsbedingungen:
[LICENSE.md](LICENSE.md).

Die Architektur und API für Veranstaltungsabläufe und easyjob-Raumnutzungen ist in [docs/event-schedule.md](docs/event-schedule.md) beschrieben.

## Enthalten

- Dashboard für den täglichen Veranstaltungsbetrieb
- zentrale Lizenzverwaltung mit Modulfreigaben, Instanzregister, Offlinefreigaben und bestätigter Player-Sperre in allen drei Ausgaben ([Einrichtung](docs/licensing.md))
- Veranstaltungsübersicht mit importierter Datenquelle
- Displayverwaltung mit festen Display-URLs, Standardkanal oder Standardslide und automatischem Rückfall bei leeren Zeitplankanälen ([Displaysteuerung](docs/player-control.md))
- Displays anlegen und bearbeiten, Player-URL kopieren, direkt öffnen oder als Vollbild-Player für Windows (64 Bit), Ubuntu/Debian (64 Bit) und macOS (Apple Silicon/Intel) installieren; der Windows-Player richtet Autostart nach der Benutzeranmeldung ein
- eigenständige Vollbild-Playeransicht je Display-URL
- Display-Gruppen anlegen, bearbeiten und löschen
- Slide-Bibliothek mit Veranstaltung, Text, Bild, Video, Website und PDF als Inhaltstypen
- Bulk-Medienimport mit Tag-Auswahl und automatischen Werbekanälen für Querformat und Hochkant, sieben Tagen Standardlaufzeit und konfigurierbarer Slidezahl ([Anleitung](docs/tag-advertising.md))
- Speisekarten-Modul mit zentralem Ein-/Ausschalter, konfigurierbaren Vorgaben, drei Vorlagen, PDF-Weblink-Abonnements mit automatischem Kanal-/Seitenabgleich, geschütztem `/speisekarten`-Editor und eigenen Rechten/Kartenzuweisungen in allen drei Ausgaben ([Anleitung](docs/speisekarten.md))
- automatische Event-Daten und Event-/Ablauf-Countdowns mit Minuten-/Sekunden-Offset ([Anleitung](docs/dynamic-event-slides.md))
- direkte HTTPS-Website-Slides und virtuelle Tag-Ordner in der Slide-/Kanalbibliothek
- visueller Slide-Editor mit frei positionierbaren Text-, Bild-, Video-, Website- und Eventelementen, Medienzuschnitt/Zoom und automatischem Einrasten ([Anleitung](docs/editor-media-placement.md))
- Bild- und Video-Upload sowie Einbindung externer Medien- und Website-URLs
- Kanal-Builder mit Drag-and-drop-Reihenfolge, individueller Slide-Dauer und echter zeitgesteuerter [Kanalvorschau](docs/channel-preview.md)
- Standardübergang pro Kanal und abweichender Übergang zwischen einzelnen Slides
- umschaltbarer Tages-, Wochen- und Monatsplan mit Drag-and-drop-Zeitsteuerung
- direkte Planung von Kanälen und einzelnen Slides, einschließlich Stapelung und Verschieben zwischen Zielzeilen
- gleichzeitige Zuweisung an mehrere Displays und Display-Gruppen
- Vorbereitete Zeitzuweisungen in Presets per Oberfläche, API oder Companion auslösen ([Anleitung](docs/preset-schedules.md))
- Prioritäten, Laufzeiten und tägliche oder wöchentliche Wiederholungen im Zeitplan
- Konfliktschutz: höher priorisierte Ausspielungen werden nicht versehentlich überschrieben
- Betriebszentrale mit Player-Heartbeat, Online-/Offline-Zustand und Cache-Bereitschaft
- automatische Inhaltsaktualisierung ohne Seitennavigation und Fernaktionen zum Synchronisieren bzw. Browser-Refresh direkt in der Displayverwaltung ([Anleitung](docs/player-refresh.md))
- gezielte Warnhinweise für Display-Gruppen oder einzelne Displays
- automatische Rückkehr zum regulären Kanal nach Ende einer Notfallmeldung
- schlankes strukturiertes Betriebslog für Serverstart, Fehler und langsame Anfragen
- normalisierte Standortverwaltung und Matrix-Displays
- zentraler Papierkorb mit Wiederherstellung
- providerunabhängige Warnhinweise und zehn editierbare Vorlagen
- Website-Kalender in WordPress und TYPO3 mit fünf Ansichten, Agenda als Vorgabe, Theme-/Einzelfarben und konfigurierbaren Spalten je Einbettung ([Anleitung](docs/calendar.md))
- Korrigierte Easyjob-Einstellungs-/Importaufrufe und CMS-Routen für DWD-Suche und Veranstaltungsablauf ([Details](docs/easyjob-cms.md))
- CrewBrain und easyjob parallel als auswählbare Veranstaltungsdatenquellen mit eigener Feldzuordnung, Importvorschau sowie manuellem und automatischem Import
- easyjob-Veranstaltungsbilder aus Job- oder Projektanhängen mit automatischer Ablage unter Werbung/Jahr/Monat/Veranstaltung ([Details](docs/easyjob-advertising-images.md))
- Webkonfiguration für CrewBrain-Verbindung, manuelle Token-Eingabe oder einmaligen Token-Abruf per CrewBrain-Login, Sync-Regeln, Feldzuordnung, Verbindungstest und Importvorschau
- sicherer Admin-Login, einmalige Ersteinrichtung, Benutzerverwaltung und Rollen für Administratoren, Redakteure und Betrachter
- optional exklusive Zugangswerk-Anmeldung über OpenID Connect in Standalone ([Einrichtung](docs/zugangswerk.md)); CMS-Anmeldungen bleiben beim jeweiligen CMS
- Einladungs-E-Mails direkt über eine HTTPS-API, ohne eigenen SMTP-Server
- responsive Darstellung für Desktop, Tablet und Smartphone
- additives Node.js-/TypeScript-Backend mit SQLite-Migrationen
- serverseitiger, aus der offiziellen OpenAPI typisierter CrewBrain-v2-Client
- konfigurierbare CrewBrain-Basis-URL und Authentifizierungsart
- verschlüsselte Speicherung von CrewBrain-Zugangsdaten
- Verbindungstest mit unterscheidbaren Fehlerzuständen
- read-only Importvorschau mit Zeitraum-, Status- und Suchfiltern
- providerunabhängige Veranstaltungsquellen-Abstraktion
- Audit-Log für CrewBrain-Konfiguration, Tests und Vorschauen

Mehrere Displays an einem Windows-/Linux-PC: [Player-Instanzen](docs/player-instances.md).
Zeitplanung über Companion/API: [Externe Steuerung](docs/external-api.md#zeitplanung-über-api-und-companion-ab-3220).

## Einrichtung und Home Assistant

Die [Einrichtungsanleitung](docs/setup-guide.md) beschreibt CMS-Updates einschließlich
GitHub-Token und manueller Prüfung, transparente Lauftexte, native CMS-Medien und
externe API-Zugänge.

Die eigenständige [Home-Assistant-Integration über HACS](https://github.com/soerenelvers/hacs-kiosky)
ist öffentlich verfügbar: als benutzerdefiniertes Repository vom Typ **Integration**
hinzufügen, herunterladen, Home Assistant neu starten und unter Geräte & Dienste
**Kiosky** mit externer API-Adresse und Kiosky-API-Schlüssel einrichten.
Voraussetzungen: Kiosky ab 3.3.1 und Home Assistant ab 2026.3.0.

## Lokale Entwicklung

Für die reine Frontend-Vorschau kann `index.html` weiterhin direkt geöffnet werden. Für Backend, Datenbank und CrewBrain-Integration:

```sh
pnpm install
cp .env.example .env
pnpm db:migrate
pnpm dev
```

Anschließend ist Kiosky standardmäßig unter `http://127.0.0.1:8080` erreichbar. Beim ersten Aufruf führt die Oberfläche durch das Anlegen des ersten Administrators. `KIOSKY_ENCRYPTION_KEY` muss für externe Zugangsdaten sicher gesetzt werden; `KIOSKY_ADMIN_API_KEY` ist nur noch für optionale Maschinenzugriffe erforderlich. Weitere Hinweise stehen in [docs/development.md](docs/development.md).

## Plesk

Für Plesk wird Node.js 24 LTS empfohlen. Als Anwendungsstamm dient das Repository, als Dokumentenstamm dessen Unterordner `public` und als Anwendungsstartdatei `server.js`. Nach der NPM-Installation muss einmal das Skript `build` ausgeführt werden. Kiosky übernimmt automatisch den von Plesk bereitgestellten `PORT`; dieser darf nicht als eigene Umgebungsvariable überschrieben werden. Die vollständige Einrichtung steht in [docs/plesk.md](docs/plesk.md).

## Standalone aus Git aktualisieren

Für Server den Branch **main** verwenden. Ein Pull allein reicht nicht:

```sh
git pull --ff-only origin main
pnpm deploy:standalone
```

Danach die App in Plesk beziehungsweise den zuständigen Prozessmanager neu starten.
`pnpm verify:standalone` prüft Version, Commit und ausgelieferte Dateien;
`/api/health` zeigt die tatsächlich laufende Version. Details und Plesk/npm-Alternative:
[Standalone-Bereitstellung](docs/plesk.md#aktualisierung-aus-git).

## Standalone, WordPress und TYPO3

Kiosky wird weiterhin einmal als Standalone-Kern entwickelt. Ein gemeinsamer
Plattform-Build erzeugt daraus versionierte Pakete für Standalone, WordPress und
TYPO3:

```sh
pnpm build:platforms
```

Die ZIP-Dateien werden unter `artifacts/` ausgegeben. WordPress und TYPO3 enthalten
jeweils eine eigenständige CMS-Laufzeit mit lokaler Datenhaltung, CMS-Anmeldung,
API und Player. Oberfläche und PHP-Domainkern werden aus gemeinsamen Quellen gebaut.
Architektur, Installation und Grenzen sind in
[docs/platform-distributions.md](docs/platform-distributions.md) beschrieben.

Die TYPO3-Extension wird aus der privaten, automatisch versionierten Distribution
installiert. Der nur lesende GitHub-Token darf ausschließlich auf dieses Repository
zugreifen und gehört in Composers geschützte Authentifizierung, nicht in das Projekt:

```sh
composer config repositories.kiosky vcs https://github.com/soerenelvers/kiosky-distribution.git
composer config --global --auth github-oauth.github.com GITHUB_TOKEN
composer require casesound/kiosky
vendor/bin/typo3 extension:setup
vendor/bin/typo3 cache:flush
```

TYPO3 13.4 LTS ist die bevorzugte Zielversion. Architektur, Migration, Rechte,
Display-API und Releases sind unter [Documentation](Documentation/) dokumentiert.

## Player Center

[Automatische Playerupdates](docs/player-updates.md) aktualisieren die neuen
Windows-, Linux-/Mint-, macOS- und Pi-Player über den verbundenen Kiosky-Server.
Bisherige Downloads benötigen einmalig die neue Installation.

[Countdowns](docs/countdowns.md) bieten wählbare Zeitformate sowie Ausblenden,
positives Hochzählen oder Stehenbleiben nach Erreichen der Zielzeit.

Die [Raspberry-Pi-Images](docs/raspberry-pi-player.md) für Zero 2 W und Pi 3/4/5
stehen unter `/player` als Vorabversion zum Download bereit: WLAN, Chromium im
Vollbild und dauerhaft gespeicherte Kopplung ohne Desktop.

Die laufende Kiosky-Instanz stellt unter `/player` ein öffentliches Player
Center bereit. Dort können Browser-, Windows-, Linux- und macOS-Universal-Player
gestartet beziehungsweise heruntergeladen werden. Beim ersten Start erscheint
ein kurzlebiger sechsstelliger Code, mit dem der Player im Backend einem Display
zugeordnet wird. Alternativ kann am gewünschten Display direkt ein bereits
zugeordneter Windows-, Linux- oder macOS-Player heruntergeladen werden. Der
macOS-Download enthält eine `.app` in einem ZIP-Archiv. Da die Display-URL
individuell in die App eingebettet wird, ist sie nicht mit einem Apple-
Entwicklerzertifikat signiert und muss beim ersten Start gegebenenfalls über
**Rechtsklick → Öffnen** bestätigt werden.

Die Player-Center-URLs lauten:

- Standalone: `/player`
- WordPress: `/player` (compatibility alias: `/kiosky-player-center/`)
- TYPO3: `/player` (compatibility alias: `/kiosky-player-center/`)

Der jeweilige Browser-Player ist unter `/player/browser.html` (Standalone)
beziehungsweise `/kiosky-player-browser/` (WordPress und TYPO3) erreichbar.

Ab 3.13.4 binden auch die CMS-Downloads die Adresse dieser Installation ein.
Nach dem Update zuvor heruntergeladene Dateien erneut herunterladen; alte
Dateien mit dem URL-Platzhalter können sich nicht selbst reparieren.
Ab 3.14.0 wird die Windows-32-Bit-Variante nicht mehr angeboten. Der neue
Windows-64-Bit-Player kopiert sich beim ersten Start ins Benutzerprofil und
registriert dort seinen Autostart. Nach der Windows-Anmeldung wartet er auf
die Serververbindung und öffnet den Player im Vollbild mit dauerhaftem eigenem
Browserprofil. Eine bestehende Kopplung dieses Profils bleibt erhalten.
Einrichtung, Autostart entfernen und Build: [Windows-Player](docs/windows-player.md).
Ab 3.19.0 bieten Linux- und Mint-Downloads ebenfalls Autostart nach der grafischen
Anmeldung, ein dauerhaftes eigenes Profil und Unterstützung für Firefox/Chromium/Chrome.
Unter Linux die Datei vor dem Start ausführbar machen, etwa mit `chmod +x DATEINAME`.
Installation, Kopplung und Autostart verwalten: [Linux-/Mint-Player](docs/linux-player.md).
Native Windows-Launcher sind derzeit nicht Authenticode-signiert.
Prüfumfang und Grenzen: [Player-Downloads 3.13.4](docs/player-downloads-3.13.4.md).

Die Universal-Binary-Vorlage für Apple Silicon und Intel lässt sich auf macOS
mit installierten Command Line Tools neu erzeugen:

```sh
pnpm build:player:macos
```

## CrewBrain API v2

Die Swagger-Seite der Entwicklungsinstanz lädt eine OpenAPI-3.0-Spezifikation der Version 2.339. Kiosky erzeugt daraus TypeScript-Typen. Details zu Endpunkten, Authentifizierung, Pagination, Feldern und Einschränkungen stehen in [docs/crewbrain-api-analysis.md](docs/crewbrain-api-analysis.md). Die aktuelle Admin-API ist in [docs/api.md](docs/api.md) beschrieben.

## Aktueller Stand

Standalone, WordPress und TYPO3 besitzen jeweils eine serverseitige, dauerhafte
Datenhaltung. Die CMS-Pakete laufen ohne Standalone-Server und übernehmen Anmeldung,
Benutzer- und Medienverwaltung aus dem jeweiligen CMS. CrewBrain- und easyjob-Livetest,
Tokenabruf, Vorschau, manueller und automatischer Import, DWD-Warnungen,
Zeitplanung, Matrix-Wiedergabe und externe Steuerung sind auch in
den CMS-Ausgaben integriert. Der gemeinsame Release-Workflow prüft TypeScript und
PHP und erzeugt drei installierbare ZIP-Dateien.

### Medien in CMS-Installationen (ab 3.3.0)

WordPress verwendet ausschließlich seine Mediathek (Attachments), TYPO3 seine native Dateiverwaltung (FAL). Bereits vorhandene CMS-Dateien können direkt gewählt werden; neue Uploads erscheinen auch im CMS. Kiosky speichert keinen zusätzlichen Medienkatalog. Die Standalone-App behält ihre eigene Medienbibliothek.

Beim ersten Zugriff eines Benutzers mit Bearbeitungsberechtigung werden bisherige Kiosky-Medien übernommen und Verweise angepasst. In TYPO3 muss dafür ein öffentlicher, beschreibbarer Dateispeicher innerhalb der erlaubten Dateifreigaben vorhanden sein. Bei fehlenden Rechten oder ungültigen Dateien bleibt der alte Datenbestand erhalten und die Übernahme meldet einen Fehler. Der TYPO3-Papierkorbstatus wird als Metadatum an der FAL-Datei geführt; erst endgültiges Löschen entfernt die Datei. WordPress nutzt den Attachment-Papierkorb.

Im Slide-Editor lässt sich unter „Element-Hintergrund“ zwischen „Farbe“ und „Transparent“ wählen. Bei Lauftexten bleibt nur der laufende Inhalt sichtbar, ohne die darunterliegenden Ebenen zu verdecken.

### Externe API in allen Varianten (ab 3.3.1)

Unter **Schnittstellen → Externe API** können Administratoren eigene Zugänge für Gebäudeautomation und externe Integrationen erstellen und widerrufen. Die angezeigte externe Basisadresse ist in Standalone, WordPress und TYPO3 ohne CMS-Anmeldung mit `Authorization: Bearer <Schlüssel>` oder `X-API-Key` nutzbar. Neue WordPress-Clients verwenden `/wp-json/kiosky/v1/control`, TYPO3-Clients `/kiosky-api/v1`. Details und Beispiele stehen in [docs/external-api.md](docs/external-api.md).

Einzelne Inhalte zwischen Installationen übertragen: [Slides, Kanäle und Vorlagen importieren/exportieren](docs/content-packages.md).

## Vorgeschlagener automatisierter CI/CD-Prozess

[Architektur, Freigabesperren, GitHub-Berechtigungen und Secrets](docs/ci-cd.md).
Die Automatisierung bleibt bis zur ausdrücklichen Freigabe deaktiviert.

Uhr-Overlay: [Standort-Zeitzone und Zoom konfigurieren](docs/clock-overlay.md).

Ab 3.20.0 verwendet der Windows-Player ein eigenes WebView2-Fenster: [Einrichtung und Updates](docs/windows-player.md).

Preset-Abläufe lassen sich unter **Zeitplanung → Preset-Termine** zeitgesteuert auslösen; siehe [Preset-Termine und Hintergrundbetrieb](docs/preset-triggers.md).
