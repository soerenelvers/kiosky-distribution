ALTER TABLE player_pairings ADD COLUMN credential_version INTEGER NOT NULL DEFAULT 0;
ALTER TABLE player_pairings ADD COLUMN display_key_hash TEXT;
ALTER TABLE player_pairings ADD COLUMN revoked_at TEXT;
ALTER TABLE player_pairings ADD COLUMN last_seen_at TEXT;
CREATE INDEX idx_player_connections_display ON player_pairings(display_id,revoked_at,credential_version);
CREATE TABLE player_command_deliveries (
 command_id TEXT NOT NULL REFERENCES player_commands(id) ON DELETE CASCADE,
 player_id TEXT NOT NULL REFERENCES player_pairings(id) ON DELETE CASCADE,
 acknowledged_at TEXT,
 delivered_at TEXT,
 PRIMARY KEY(command_id,player_id)
);
CREATE INDEX idx_player_deliveries_pending ON player_command_deliveries(player_id,acknowledged_at,command_id);
