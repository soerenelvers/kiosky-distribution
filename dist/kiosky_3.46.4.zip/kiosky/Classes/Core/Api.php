<?php

declare(strict_types=1);

namespace Kiosky\Core;
require_once __DIR__.'/QualityClock.php';

use RuntimeException;
use Throwable;

require_once __DIR__.'/LicenseClient.php';
require_once __DIR__.'/TicketLinks.php';
require_once __DIR__.'/ContentHistory.php';
require_once __DIR__.'/PlaybackProof.php';
require_once __DIR__.'/PlayerHealth.php';
require_once __DIR__.'/CustomerContent.php';
require_once __DIR__.'/DisplaySimulation.php';
require_once __DIR__.'/PublicationCheck.php';
require_once __DIR__.'/SlideEventSelection.php';
require_once __DIR__.'/MediaSlides.php';
require_once __DIR__.'/ScheduleBlock.php';
require_once __DIR__.'/ExternalSchedule.php';
require_once __DIR__.'/PresetHandoff.php';
require_once __DIR__.'/PresetTriggers.php';
require_once __DIR__.'/EventAutomation.php';
require_once __DIR__.'/PresetTimerActions.php';
require_once __DIR__.'/EventEditorSettings.php';
require_once __DIR__.'/EventReuse.php';
require_once __DIR__.'/EventImageEdit.php';
require_once __DIR__.'/AdvertisingVideo.php';
require_once __DIR__.'/EventLifecycle.php';
require_once __DIR__.'/ContentAccess.php';
require_once __DIR__.'/FontStorage.php';
require_once __DIR__.'/SensitiveData.php';
require_once __DIR__.'/SystemMigration.php';

final class Api
{
    /** @param array{id:string,name:string,email:string,role:string} $identity */
    public function __construct(
        private readonly StateStore $store,
        private readonly array $identity,
        private readonly string $version,
        private readonly ?CrewBrainService $crewBrain = null,
        private readonly ?DwdService $dwd = null,
        private readonly ?EasyJobService $easyJob = null,
        /** @var list<array<string,mixed>> */
        private readonly array $platformUsers = [],
        private readonly string $platform = 'cms',
        private readonly ?MenuSubscriptions $menuSubscriptions = null,
        private readonly ?LicenseClient $licenseClient = null,
        private readonly ?FontStorage $fontStorage = null,
        private readonly bool $canReadFonts = false,
        private readonly bool $canManageFonts = false,
        private readonly ?PlaybackProofStore $proofStore = null,
        private readonly string $proofSecret = '',
        private readonly ?CustomerVault $customerVault = null,
    ) {
    }

    /** @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>} */
    public function handle(string $method, string $path, array $body = [], string $playerKey = '', int $attempt = 0): array
    {
        $migrationLock=null;$customerLock=null;
        try {
            $method = strtoupper($method);
            $query = [];
            parse_str((string)(parse_url($path, PHP_URL_QUERY) ?: ''), $query);
            $body = array_merge($query, $body);
            $path = '/' . ltrim((string)(parse_url($path, PHP_URL_PATH) ?: ''), '/');
            if($path==='/api/content-transfer/migration/import'&&$method==='POST'&&($this->identity['role'] ?? '')==='admin')$migrationLock=SystemMigration::lock();
            if(preg_match('#^/api/customer-(portal|content)(/|$)#',$path)){if(str_starts_with($path,'/api/customer-content')&&!$this->canManageCustomerContent())throw new RuntimeException('Für Kundenfreigaben fehlen Verwaltungsrechte.',403);if(!$this->customerVault)throw new RuntimeException('Privater Kundenupload-Speicher ist nicht eingerichtet.',503);$customerLock=$this->customerVault->lock();if(str_starts_with($path,'/api/customer-portal'))$this->customerVault->rate((string)($this->identity['ipAddress']??'unknown'));}
            $state = $this->state(str_starts_with($path,'/api/content-transfer/migration/'));
            // Active installations also renew due grants when Cron/Scheduler is unavailable.
            // Authenticate before allowing an incoming request to cause outbound work.
            if($method==='GET'&&$path==='/api/settings/features'){
                $this->assertRolePermission($method,$path);$this->refreshLicenseState($state);
            }elseif($method==='GET'&&preg_match('#^/api/player/([^/]+)/state$#',$path,$licensePlayer)){
                $display=$this->first($state['displays'],static fn(array $item):bool=>($item['slug'] ?? '')===rawurldecode($licensePlayer[1])&&empty($item['deletedAt'])&&($item['status'] ?? '')!=='archived');
                if($display&&$playerKey!==''&&hash_equals((string)($display['playerKey'] ?? ''),$playerKey))$this->refreshLicenseState($state);
            }
            $lifecycleChanged=!str_starts_with($path,'/api/content-transfer/migration/')&&!preg_match('#^/api/displays/[^/]+/simulate$#',$path)&&EventLifecycle::synchronize($state);
            $historyBefore=$state;
            $result = $this->route($state, $method, $path, $body, $playerKey);
            if(preg_match('#^/api/player/[^/]+/state$#',$path)&&$method==='GET')$result[1]=$this->license()->playback($state,$result[1]);
            if ($result[2] && preg_match('#^/api/(events|slides|templates|trash|integrations/(easyjob|crewbrain)/import)(?:/|$)#',$path) && !empty($state['advertisingSettings']['enabled'])) $this->synchronizeAdvertising($state);
            if($result[2]&&$method!=='GET'&&!str_starts_with($path,'/api/player/')&&!str_starts_with($path,'/api/content-transfer/'))ContentHistory::capture($state,$historyBefore,(string)($this->identity['name']??$this->identity['id']));
            if ($result[2] || $lifecycleChanged) {
                $state['updatedAt'] = $this->now();
                $migrationSaving=!empty($state['_migrationSaving']);unset($state['_migrationSaving']);
                if($this->store instanceof CmsMediaStateStore&&($migrationSaving||($method==='POST'&&preg_match('#^/api/customer-content/[^/]+/approve$#',$path))))$this->store->saveMigration($state);else $this->store->save($state);
                if(isset($state['customerContent'])&&preg_match('#^/api/customer-(portal|content)(/|$)#',$path))try{$this->customerVault?->clean($state['customerContent']['uploads']);}catch(\Throwable){}
                if ($this->store instanceof CmsMediaStateStore) $result[1] = $this->store->resolveReferences($result[1]);
            }
            if(!$this->canReadPlayerKeys()&&!str_starts_with($path,'/api/player/')&&!str_starts_with($path,'/api/player-pairings'))$result[1]=$this->withoutPlayerKeys($result[1]);
            return [$result[0], $result[1]];
        } catch (Throwable $error) {
            if ($error instanceof StateConflict && $attempt < 2 && ($this->identity['actorType'] ?? '') !== 'api_key' && !preg_match('#^/api/(media|integrations|content-transfer|content-packages)(?:/|$)#',$path)){if(is_resource($customerLock)){flock($customerLock,LOCK_UN);fclose($customerLock);$customerLock=null;}return $this->handle($method,$path,$body,$playerKey,$attempt+1);}
            $status = $error instanceof RuntimeException ? max(400, min(599, $error->getCode() ?: 422)) : 500;
            return [$status, ['error' => [
                'code' => $status === 409 && $path === '/api/schedules/block' ? 'SCHEDULE_CONFLICT' : ($status === 404 ? 'NOT_FOUND' : ($status === 403 ? 'FORBIDDEN' : ($error instanceof StateConflict ? 'STATE_CONFLICT' : 'INVALID_REQUEST'))),
                'message' => SensitiveData::text($error->getMessage() ?: 'Die Anfrage konnte nicht verarbeitet werden.'),
            ]]];
        } finally {if(is_resource($customerLock??null)){flock($customerLock,LOCK_UN);fclose($customerLock);}if(is_resource($migrationLock)){flock($migrationLock,LOCK_UN);fclose($migrationLock);}}
    }

    /** Only the External Control API is exposed to machine credentials. */
    public function handleExternal(string $method, string $path, array $body, string $token, string $legacyKey = '', string $requestId = '', string $ipAddress = '', int $attempt = 0): array
    {
        $normalized = (string)(parse_url($path, PHP_URL_PATH) ?: '');
        if ($normalized !== '/api/v1' && !str_starts_with($normalized,'/api/v1/')) return [403,['error'=>['code'=>'API_SCOPE_FORBIDDEN','message'=>'Dieser API-Zugang darf ausschließlich die External Control API unter /api/v1 verwenden.']]];
        if ($token === '' || strlen($token) > 512 || (!str_starts_with($token,'kiosky_') && ($legacyKey === '' || !hash_equals($legacyKey,$token)))) return [401,['error'=>['code'=>'UNAUTHORIZED','message'=>'Der API-Schlüssel fehlt oder ist ungültig.']]];
        try {
            $state = $this->state();
            $previousUsers=$state['apiUsers'] ?? [];
            $user = ApiAccess::authenticate($state,$token);
            $legacy = !$user && $legacyKey !== '' && $token !== '' && hash_equals($legacyKey,$token);
            if (!$user && !$legacy) return [401,['error'=>['code'=>'UNAUTHORIZED','message'=>'Der API-Schlüssel fehlt, ist ungültig oder wurde widerrufen.']]];
            if ($user && ($state['apiUsers'] ?? [])!==$previousUsers) $this->store->save($state);
            $identity = ['id'=>$user['id'] ?? 'cms:legacy-api','name'=>$user['name'] ?? 'Externe API','email'=>'','role'=>'admin','actorType'=>'api_key','requestId'=>$requestId,'ipAddress'=>$ipAddress];
            $api = new self($this->store,$identity,$this->version,$this->crewBrain,$this->dwd,$this->easyJob,$this->platformUsers,$this->platform,$this->menuSubscriptions,$this->licenseClient);
            $result = $api->handle($method,$path,$body);
            if ($result[0] === 503 && ($result[1]['error']['code'] ?? '') === 'STATE_CONFLICT' && $attempt < 2) return $this->handleExternal($method,$path,$body,$token,$legacyKey,$requestId,$ipAddress,$attempt+1);
            return $result;
        } catch (Throwable $error) {
            if ($error instanceof StateConflict) {
                if ($attempt < 2) return $this->handleExternal($method,$path,$body,$token,$legacyKey,$requestId,$ipAddress,$attempt+1);
                return [503,['error'=>['code'=>'API_BUSY','message'=>'Parallele Änderungen. Bitte die Anfrage wiederholen.']]];
            }
            return [500,['error'=>['code'=>'API_UNAVAILABLE','message'=>'Die externe API konnte die Anfrage nicht verarbeiten.']]];
        }
    }

    /** @return array<string,mixed> */
    public function runScheduledTasks(): array
    {
        $state = $this->state();
        $licenseChanged=$this->refreshLicenseState($state);
        $presetTriggerRuns=$this->runDuePresetTriggers($state);
        $summary = ($state['activeEventSource'] ?? null) === 'easyjob'
            ? $this->runAutomaticEasyJobImport($state)
            : $this->runAutomaticCrewBrainImport($state);
        if ($this->license()->allows($state,'advertising') && !empty($state['advertisingSettings']['enabled']) && ($summary['ran'] || strtotime((string)($state['advertisingLastSynchronizedAt'] ?? '')) < QualityClock::now() - 300)) {
            $this->synchronizeAdvertising($state);
            $summary['ran'] = true;
            $summary['advertisingSynchronized'] = true;
        }
        $menuChecks=$this->license()->allows($state,'menus')?($this->menuSubscriptions ?? new MenuSubscriptions())->runDue($state,
            function(array &$target,array $body,?string $id): array{return $this->saveSlide($target,$body,$id);},
            function(array &$target,array $body,?string $id): array{return $this->saveRecord($target,'channels',$body,$id);}):0;
        if($licenseChanged)$summary['ran']=true;
        if($presetTriggerRuns){$summary['ran']=true;$summary['presetTriggerRuns']=$presetTriggerRuns;}
        if($menuChecks){$summary['ran']=true;$summary['menuChecks']=$menuChecks;}
        if ($summary['ran']) {
            $state['updatedAt'] = $this->now();
            $this->store->save($state);
        }
        return $summary;
    }

    /** Dedicated clock tick: no imports, media migrations or outbound services. */
    public function runPresetTriggers(int $attempt=0): array
    {
        try{
            $state=$this->state();$count=$this->runDuePresetTriggers($state);
            if($count){$state['updatedAt']=$this->now();$this->store->save($state);}
            return ['ran'=>$count>0,'presetTriggerRuns'=>$count];
        }catch(StateConflict $error){if($attempt<2)return $this->runPresetTriggers($attempt+1);throw $error;}
    }

    /** Explicit CLI/Scheduler entry point; requires no browser traffic. */
    public function runMenuSubscriptions(): array
    {
        $state=$this->state();
        $licenseChanged=$this->refreshLicenseState($state);
        if(!$this->license()->allows($state,'menus')){if($licenseChanged)$this->store->save($state);return ['ran'=>false,'menuChecks'=>0];}
        $count=($this->menuSubscriptions ?? new MenuSubscriptions())->runDue($state,
            function(array &$target,array $body,?string $id): array{return $this->saveSlide($target,$body,$id);},
            function(array &$target,array $body,?string $id): array{return $this->saveRecord($target,'channels',$body,$id);});
        if($count||$licenseChanged){$state['updatedAt']=$this->now();$this->store->save($state);}
        return ['ran'=>$count>0,'menuChecks'=>$count];
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function route(array &$state, string $method, string $path, array $body, string $playerKey): array
    {
        $this->license()->assertPath($state,$path);
        if(str_starts_with($path,'/api/settings/licensing')){
            $this->assertRolePermission($method,$path);
            if(($this->identity['actorType'] ?? '')==='api_key')throw new RuntimeException('Benutzeranmeldung erforderlich.',403);
            if($path==='/api/settings/licensing'&&$method==='GET')return $this->ok($this->license()->status($state));
            if($path==='/api/settings/licensing/sync'&&$method==='POST'){
                $this->license()->initialize($state);$this->store->save($state);
                $status=$this->license()->synchronize($state,$body);$this->audit($state,'licensing.synchronized','licensing');return $this->ok($status,true);
            }
            throw new RuntimeException('Die zentrale Lizenzverwaltung steht ausschließlich in Standalone bereit.',404);
        }

        if(preg_match('#^/api/customer-(portal|content)(?:/([^/]+)(?:/([^/]+))?)?$#',$path,$m)){
            $public=$m[1]==='portal';if(!$public&&!$this->canManageCustomerContent())throw new RuntimeException('Für Kundenfreigaben fehlen Verwaltungsrechte.',403);
            if(!$this->customerVault)throw new RuntimeException('Privater Uploadspeicher ist nicht eingerichtet.',503);
            $service=new CustomerContent($state,$this->customerVault,function(string $collection,array $body,?string $id=null)use(&$state):array{return $collection==='slides'?$this->saveSlide($state,$body,$id):$this->saveRecord($state,$collection,$body,$id);},(string)$this->identity['id'],$this->store instanceof CmsMediaStateStore?fn(array $file):string=>$this->store->customerUploadData($file):null);
            $result=$public?$service->guest($method,$m[2]??null,$m[3]??null,$body,$playerKey):$service->staff($method,$m[2]??null,$m[3]??null,$body);
            return $this->ok($result,!in_array($method,['GET','HEAD'],true));
        }

        if ($path === '/api/menu-share/session' && $method === 'POST') return MenuShare::login($state,$body,(string)($this->identity['ipAddress'] ?? 'unknown'));
        if (($path === '/api/menu-share/menus' && $method === 'GET') || (preg_match('#^/api/menu-share/menus/[^/]+$#',$path) && $method === 'PUT')) {
            $ids=MenuShare::authorize($state,$playerKey);
            return $this->menus($state,$method,str_replace('/api/menu-share/menus','/api/menus',$path),$body,$ids);
        }
        if (str_starts_with($path,'/api/menu-share/')) throw new RuntimeException('Speisekarten-Endpunkt wurde nicht gefunden.',404);
        if ($path === '/api/menus' || str_starts_with($path, '/api/menus/')) return $this->menus($state,$method,$path,$body);
        if ($path === '/api/v1' || str_starts_with($path, '/api/v1/')) {
            $this->assertRolePermission($method, $path);
            return $this->externalApi($state, $method, $path, $body);
        }
        if ($path === '/api/health' && $method === 'GET') {
            return $this->ok(['status' => 'ok', 'version' => $this->version, 'buildNumber' => $this->version . '-cms', 'database' => 'cms']);
        }
        if ($path === '/api/auth/setup-status' && $method === 'GET') return $this->ok(['needsSetup' => false]);
        if ($path === '/api/auth/me' && $method === 'GET') return $this->ok(['user' => $this->user()]);
        if ($path === '/api/auth/logout' && $method === 'POST') return $this->ok(['ok' => true]);
        if ($path === '/api/auth/password' && $method === 'POST') throw new RuntimeException('Passwörter werden vom CMS verwaltet.', 409);
        if(preg_match('#^/api/public/tickets/([^/]{1,300})$#',$path,$ticketMatch)&&$method==='GET'){
            $event=$this->first($state['events'],static fn(array $row):bool=>($row['id']??'')===rawurldecode($ticketMatch[1]));
            $data=TicketLinks::publicEvent($event,($state['featureSettings']['events']??true)!==false&&($state['publicCalendarSettings']['showTickets']??true)!==false);
            if(!$data)throw new RuntimeException('Tickets sind für diese Veranstaltung nicht verfügbar.',404);
            return $this->ok(['data'=>$data]);
        }
        if ($path === '/api/public/calendar' && $method === 'GET') {
            return $this->ok([
                'data' => PublicEventCalendar::events($state),
                'settings' => PublicEventCalendar::normalizeSettings($state['publicCalendarSettings'] ?? []),
            ]);
        }
        if ($path === '/api/users' && $method === 'GET') return $this->ok(['data' => [$this->user()]]);
        if ($path === '/api/users/invitations' && $method === 'GET') return $this->ok(['data' => []]);
        if ($path === '/api/audit-logs' && $method === 'GET') return $this->ok(['data' => array_reverse($state['audit'])]);
        if ($path === '/api/player-pairings' && $method === 'POST') {
            $alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
            do {
                $code = '';
                for ($i = 0; $i < 6; $i++) $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            } while ($this->first($state['playerPairings'], fn(array $item): bool => ($item['code'] ?? '') === $code && strtotime((string)($item['expiresAt'] ?? '')) > QualityClock::now()));
            $pairing = $this->record([
                'code' => $code, 'secret' => bin2hex(random_bytes(24)), 'status' => 'pending',
                'platform' => (string)($body['platform'] ?? 'Universal Player'),
                'playerBaseUrl' => (string)($body['playerBaseUrl'] ?? ''), 'expiresAt' => gmdate('c', QualityClock::now() + 900),
            ]);
            $state['playerPairings'][] = $pairing;
            return $this->created(['id' => $pairing['id'], 'code' => $code, 'secret' => $pairing['secret'], 'status' => 'pending', 'expiresAt' => $pairing['expiresAt']]);
        }
        if (preg_match('#^/api/player-pairings/([^/]+)$#', $path, $match) && $method === 'GET') {
            $pairing = $this->required($state['playerPairings'], rawurldecode($match[1]), 'Kopplung');
            if (!hash_equals((string)$pairing['secret'], $playerKey)) throw new RuntimeException('Kopplung wurde nicht gefunden.', 404);
            if (strtotime((string)$pairing['expiresAt']) <= QualityClock::now()) return $this->ok(['id' => $pairing['id'], 'code' => $pairing['code'], 'status' => 'expired']);
            if (($pairing['status'] ?? '') !== 'paired') return $this->ok(['id' => $pairing['id'], 'code' => $pairing['code'], 'status' => 'pending']);
            $display = $this->required($state['displays'], (string)$pairing['displayId'], 'Display');
            $base = rtrim((string)($pairing['playerBaseUrl'] ?? ''), '/') . '/';
            return $this->ok(['id' => $pairing['id'], 'code' => $pairing['code'], 'status' => 'paired', 'display' => ['id' => $display['id'], 'name' => $display['name']], 'playerUrl' => $base . '?display=' . rawurlencode((string)$display['slug']) . '&key=' . rawurlencode((string)$display['playerKey'])]);
        }

        if (preg_match('#^/api/player/([^/]+)/(state|heartbeat|proof|commands)$#', $path, $match)) {
            return $this->player($state, $method, rawurldecode($match[1]), $match[2], $body, $playerKey);
        }

        $this->assertRolePermission($method, $path);
        $designer=($this->identity['role'] ?? '')==='designer';$actorId=(string)$this->identity['id'];
        if($path==='/api/settings/player-health'){
            $this->license()->assertPath($state,'/api/displays');if(!$this->user()['canManageSettings'])throw new RuntimeException('Keine Einstellungsrechte.',403);
            if($method==='GET')return $this->ok(['settings'=>PlayerHealth::settings($state['playerHealthSettings']??[])]);
            if($method==='PUT'){$previous=PlayerHealth::settings($state['playerHealthSettings']??[]);$state['playerHealthSettings']=array_replace(PlayerHealth::settings($body,true),['displays'=>$previous['displays'],'updatedAt'=>$this->now()]);$this->audit($state,'player-health.settings.updated','player_health');return $this->ok(['settings'=>$state['playerHealthSettings']],true);}
        }
        if($path==='/api/displays/health'&&$method==='GET')return $this->ok(PlayerHealth::report($this->listCollection($state,'displays'),$state['playerHealthSettings']??[],$this->version)+['canManageSettings'=>$this->user()['canManageSettings'],'canControl'=>$this->canControlPlayers()]);
        if(preg_match('#^/api/displays/([^/]+)/(monitoring|output)$#',$path,$healthMatch)){
            $display=$this->required($this->active($state['displays']),rawurldecode($healthMatch[1]),'Display');
            if($healthMatch[2]==='monitoring'&&$method==='POST'){if(!$this->canControlPlayers())throw new RuntimeException('Keine Steuerungsrechte.',403);if(!is_bool($body['paused']??null))throw new RuntimeException('Bitte einen gültigen Überwachungsstatus angeben.',422);$cfg=PlayerHealth::settings($state['playerHealthSettings']??[]);$cfg['displays'][$display['id']]=['paused'=>$body['paused'],'changedAt'=>$this->now()];$state['playerHealthSettings']=$cfg;return $this->ok(['ok'=>true],true);}
            if($healthMatch[2]==='output'&&$method==='GET'){$copy=$state;$result=$this->player($copy,'GET',$display['slug'],'state',['preview'=>1],$display['playerKey']);$result[1]=$this->license()->playback($copy,$result[1]);$result[1]=$this->withoutPlayerKeys($result[1]);return $this->ok($result[1]);}
            throw new RuntimeException('Methode nicht erlaubt.',405);
        }
        if($path==='/api/slides/publication-check'&&$method==='POST'){
            if(!is_array($body['slide']??null))throw new RuntimeException('Bitte eine Slide zur Prüfung übergeben.',422);$slide=$body['slide'];
            if($designer&&!empty($slide['id']))ContentAccess::own($state,$actorId,(string)$slide['id']);
            $linked=!empty($slide['eventId'])?$this->first($state['events'],static fn(array $e):bool=>$e['id']===$slide['eventId']):null;
            $event=SlideEventSelection::select($state['events'],$slide['document']['eventSelection']??[],$linked);
            $stored=!empty($slide['id'])?$this->first($state['slides'],static fn(array $r):bool=>$r['id']===$slide['id']):null;$doc=array_replace($stored['document']??[],$slide['document']??[]);if(isset($doc['responsiveLayouts'])){$layouts=$doc['responsiveLayouts'];$layouts[($doc['designOrientation']??'')==='portrait'?'portrait':'landscape']=$doc['elements']??[];$doc['responsiveLayouts']=$layouts;}$slide['document']=$doc;
            return $this->ok(PublicationCheck::check($slide,$state['mediaAssets'],$event));
        }
        if($path==='/api/event-automation'||str_starts_with($path,'/api/event-automation/')){
            if(!in_array($this->identity['role']??'',['admin','editor'],true)||!$this->canControlPlayers()||($this->identity['allLocations']??true)===false)throw new RuntimeException('Für globale Veranstaltungsabläufe sind Verwaltungsrechte für alle Standorte erforderlich.',403);
            $config=$state['eventAutomation']??EventAutomation::empty();$result=EventAutomation::request($config,$method,$path,$body,$state['events'],['slides'=>$state['slides'],'channels'=>$state['channels'],'displays'=>$state['displays'],'groups'=>$state['groups'],'matrices'=>$state['matrices']],QualityClock::micro());
            if($method!=='GET'){$state['eventAutomation']=$config;$this->audit($state,'event.automation.changed','event_automation');}return $this->ok($result,$method!=='GET');
        }
        if(preg_match('#^/api/displays/([^/]+)/simulate$#',$path,$simulationMatch)&&$method==='POST'){
            if(!in_array($this->identity['role']??'',['admin','editor'],true))throw new RuntimeException('Für die Simulation fehlen die erforderlichen Rechte.',403);
            $this->license()->assertPath($state,'/api/schedules');[$at,$until]=DisplaySimulation::arguments($body);$id=rawurldecode($simulationMatch[1]);$display=$this->required($state['displays'],$id,'Display');
            $copy=$state;$timeline=[];$simulatedPresets=[];$lastIdentity='';$executions=0;$realNow=time();
            $runDue=function(float $point)use(&$copy,&$executions,&$simulatedPresets,$realNow):void{
                if($point<$realNow||!$this->license()->allows($copy,'schedule','operations'))return;
                while(true){$due=array_values(array_filter($copy['presetTriggers']??[],static fn(array $t):bool=>!empty($t['enabled'])&&empty($t['deletedAt'])&&!empty($t['nextRunAt'])&&strtotime($t['nextRunAt'])<=$point));usort($due,static fn(array $a,array $b):int=>strcmp($a['nextRunAt'],$b['nextRunAt']));if(!$due)break;if(++$executions>100)throw new RuntimeException('Die Simulation umfasst mehr als 100 Preset-Auslösungen. Bitte einen näheren Zeitpunkt wählen.',422);
                    $when=max($realNow,strtotime($due[0]['nextRunAt']));QualityClock::run($when,function()use(&$copy):void{$this->runDuePresetTriggers($copy);});$simulatedPresets[]=['presetId'=>$due[0]['presetId'],'at'=>gmdate('c',$when)];
                }
            };
            $runDue((float)$at);if(!empty($body['presetId']))$this->license()->assertPath($state,'/api/presets');if(!empty($body['presetId']))QualityClock::run((float)$at,function()use(&$copy,$body):void{$this->executeStoredPreset($copy,(string)$body['presetId']);});
            $cursor=(float)$at;$output=[];$points=0;
            while($cursor<=$until){if(++$points>128)throw new RuntimeException('Zu viele Wechsel für eine Simulation. Bitte den Zeitraum verkürzen.',422);$runDue($cursor);
                $resolved=QualityClock::run($cursor,function()use(&$copy,$display):array{return $this->player($copy,'GET',$display['slug'],'state',['preview'=>'1'],(string)$display['playerKey'])[1];});unset($resolved['display']['playerKey'],$resolved['display']['deviceToken']);if($cursor===$at||!$output)$output=$resolved;
                $reason=$resolved['selectionReason'];$identity=json_encode([$reason,$resolved['warning']['id']??null,$resolved['assignment']['id']??null,$resolved['channel']['id']??null,$resolved['directSlide']['id']??null,array_column(array_column($resolved['slides'],'slide'),'id')]);
                if($identity!==$lastIdentity){$timeline[]=['at'=>gmdate('c',(int)$cursor),'kind'=>$reason['kind'],'name'=>$resolved['warning']['title']??$resolved['channel']['name']??$resolved['directSlide']['name']??'Kein gültiger Inhalt','reason'=>$reason,'slideCount'=>count($resolved['slides'])];$lastIdentity=$identity;}
                if($cursor===$until)break;$times=[];foreach(['warnings','assignments','slides'] as $collection)foreach($copy[$collection]??[] as $row){$times[]=$row['startsAt']??null;$times[]=$row['endsAt']??$row['expiresAt']??null;}foreach($copy['events']??[] as $row){$times[]=$row['eventStart']??null;$times[]=$row['eventEnd']??null;}if($this->license()->allows($copy,'operations'))foreach($copy['presetTriggers']??[] as $row)if(!empty($row['enabled']))$times[]=$row['nextRunAt']??null;
                $flowSchedules=$this->license()->allows($copy,'events','schedule','operations','channels','displays')?EventAutomation::plans($copy['eventAutomation']??[],$copy['events'])['schedules']:[];
                $cursor=DisplaySimulation::boundary($cursor,(float)$until,[...$copy['schedules'],...$flowSchedules],$times);
            }
            return $this->ok(['output'=>$output,'timeline'=>$timeline,'simulatedPresets'=>$simulatedPresets,'at'=>gmdate('c',$at),'until'=>gmdate('c',(int)$until),'readOnly'=>true,'note'=>'Berechnung mit der aktuellen Konfiguration. Künftige manuelle Warnungen und Änderungen sind nicht vorhersagbar.']);
        }
        if($path==='/api/reports/advertising'&&$method==='GET'){
            $this->assertRolePermission($method,$path);[$from,$until]=PlaybackProof::period($body['from']??null,$body['until']??null);
            $displays=$state['displays'];if(!empty($body['displayId']))$displays=array_values(array_filter($displays,static fn(array $d):bool=>$d['id']===$body['displayId']));
            $names=array_column($displays,'name','id');$rows=$this->proofStore?->report($from,$until,array_keys($names))??[];
            foreach($rows as &$row){$row['displayName']=$names[$row['displayId']]??$row['displayId'];$row['seconds']=(float)$row['seconds'];$row['plays']=(int)$row['plays'];$row['intervals']=(int)$row['intervals'];}unset($row);
            return $this->ok(['data'=>$rows,'retentionDays'=>90,'basis'=>'player_confirmed']);
        }
        if(preg_match('#^/api/history/(slide|channel|event|schedule)(?:/([^/]+))?(?:/([^/]+)/restore)?$#',$path,$historyMatch)){
            $type=$historyMatch[1];$collection=ContentHistory::COLLECTIONS[$type];$id=isset($historyMatch[2])?rawurldecode($historyMatch[2]):null;
            $permitted=function(string $target)use($state,$type,$collection,$actorId,$designer):void{$reference=$this->first($state[$collection],static fn(array $r):bool=>$r['id']===$target);if($type!=='schedule'&&(!$reference||$type==='event'&&(($reference['status']??'')==='removed'||!empty($reference['deletedAt']))))throw new RuntimeException('Dieser Inhalt ist nicht mehr verfügbar.',404);if($designer){if($type==='slide')ContentAccess::own($state,$actorId,$target);elseif($type!=='event')ContentAccess::fail();}};
            if($method==='GET'&&empty($historyMatch[3])){if($id)$permitted($id);$rows=array_values(array_filter(ContentHistory::listing($state,$type,$id),static function(array $r)use($permitted):bool{try{$permitted($r['entityId']);return true;}catch(\Throwable){return false;}}));return $this->ok(['data'=>$rows,'currentToken'=>$id?ContentHistory::token($this->first($state[$collection],static fn(array $r):bool=>$r['id']===$id)):null,'retention'=>['perEntity'=>20,'total'=>1000,'maxBytes'=>8388608]]);}
            if($method==='POST'&&$id&&!empty($historyMatch[3])){
                $permitted($id);$current=$this->first($state[$collection],static fn(array $r):bool=>$r['id']===$id);
                if(($body['expectedToken']??'')!==ContentHistory::token($current))throw new RuntimeException('Der Inhalt wurde inzwischen geändert. Bitte den Verlauf neu laden.',409);
                $snapshot=ContentHistory::revision($state,$type,$id,rawurldecode($historyMatch[3]));
                if(!$current&&$type!=='schedule')throw new RuntimeException('Endgültig gelöschter Inhalt kann nicht wiederhergestellt werden.',404);
                unset($snapshot['id'],$snapshot['ownerId'],$snapshot['createdAt'],$snapshot['updatedAt'],$snapshot['deletedAt'],$snapshot['archivedAt'],$snapshot['sourceId'],$snapshot['automationKey']);
                if($current&&!empty($current['deletedAt'])&&in_array($type,['slide','channel'],true)){$idx=$this->index($state[$collection],$id);unset($state[$collection][$idx]['deletedAt'],$state[$collection][$idx]['archivedAt']);}
                if($type==='schedule'&&!$current){$result=$this->collectionRoute($state,'POST','schedules','entry',$snapshot);$createdId=$result[1]['entry']['id'];$idx=$this->index($state['schedules'],$createdId);$state['schedules'][$idx]['id']=$id;}
                else{$result=$this->route($state,'PUT','/api/'.$collection.'/'.$id,$snapshot,'');if($result[0]>=400)throw new RuntimeException('Der Stand konnte nicht wiederhergestellt werden.',422);}
                $this->audit($state,'history.restored',$id);return $this->ok(['ok'=>true],true);
            }
            throw new RuntimeException('Methode nicht erlaubt.',405);
        }
        if($designer)ContentAccess::check($state,$actorId,$path,$body,$method);
        if(str_starts_with($path,'/api/content-access'))$this->license()->assertPath($state,'/api/channels');
        if($path==='/api/content-access'&&$method==='GET'){
            if(!in_array($this->identity['role'] ?? '',['admin','editor'],true))ContentAccess::fail();
            $users=array_values(array_map(static fn(array $user):array=>['id'=>$user['id'],'displayName'=>$user['displayName'],'channelIds'=>ContentAccess::ids($state,$user['id'])],array_filter($this->platformUsers,static fn(array $user):bool=>($user['role'] ?? '')==='designer'&&($user['status'] ?? 'active')==='active')));
            return $this->ok(['users'=>$users,'channels'=>array_values(array_map(static fn(array $channel):array=>['id'=>$channel['id'],'name'=>$channel['name']],array_filter($this->active($state['channels']),static fn(array $channel):bool=>empty($channel['automationKey']))))]);
        }
        if(preg_match('#^/api/content-access/users/([^/]+)$#',$path,$match)&&$method==='PUT'){
            if(!in_array($this->identity['role'] ?? '',['admin','editor'],true))ContentAccess::fail();
            $userId=rawurldecode($match[1]);$target=$this->first($this->platformUsers,static fn(array $user):bool=>$user['id']===$userId);
            if(($target['role'] ?? '')!=='designer'||!is_array($body['channelIds'] ?? null)||count($body['channelIds'])>1000)throw new RuntimeException('Bitte einen Mediengestalter und gültige Kanäle auswählen.',422);
            $known=array_column(array_filter($this->active($state['channels']),static fn(array $channel):bool=>empty($channel['automationKey'])),'id');
            foreach($body['channelIds'] as $id)if(!is_string($id)||!in_array($id,$known,true))ContentAccess::fail();
            $state['contentChannelAccess'][$userId]=array_values(array_unique($body['channelIds']));$this->audit($state,'content.channel-access.updated',$userId);
            return $this->ok(['ok'=>true],true);
        }
        if(preg_match('#^/api/content-access/channels/([^/]+)/slides$#',$path,$match)&&$method==='POST'){
            if(!$designer)ContentAccess::fail();$channelId=rawurldecode($match[1]);
            $channel=$this->required($this->active($state['channels']),$channelId,'Kanal');
            if(!empty($channel['automationKey'])||!in_array($channelId,ContentAccess::ids($state,$actorId),true))ContentAccess::fail();
            if(!is_array($body['slideIds'] ?? null)||!count($body['slideIds'])||count($body['slideIds'])>500)throw new RuntimeException('Bitte eigene Slides auswählen.',422);
            $existing=array_column($channel['items'] ?? [],'slideId');
            foreach(array_unique($body['slideIds']) as $id){if(!is_string($id))ContentAccess::fail();$slide=ContentAccess::own($state,$actorId,$id);if(!empty($slide['deletedAt'])||($slide['status'] ?? '')==='archived')ContentAccess::fail();if(!in_array($id,$existing,true)){$channel['items'][]=['slideId'=>$id,'durationSeconds'=>10,'transition'=>'inherit'];$existing[]=$id;}}
            $saved=$this->saveRecord($state,'channels',$channel,$channelId);$this->audit($state,'channel.slides.appended',$channelId);return $this->ok(['channel'=>$saved],true);
        }

        if($path==='/api/fonts'||preg_match('#^/api/fonts/([a-f0-9]{64})$#D',$path,$fontMatch)){
            if(!$this->canReadFonts)throw new RuntimeException('Eine gültige CMS-Benutzersitzung ist erforderlich.',401);
            if($method!=='GET')throw new RuntimeException('Methode nicht erlaubt.',405);
            return $this->ok($path==='/api/fonts'?['fonts'=>$this->fontCatalog($state)]:$this->fontFile($state,$fontMatch[1]));
        }
        if($path==='/api/settings/fonts'||preg_match('#^/api/settings/fonts/([a-f0-9]{64})$#D',$path,$fontMatch)){
            // Explicit native administrator grant, independent of the coarse shared API role.
            if(!$this->canManageFonts||!$this->canReadFonts||($this->identity['role']??'viewer')!=='admin')throw new RuntimeException('Eine native Administratorberechtigung ist erforderlich.',403);
            if(!$this->fontStorage)throw new RuntimeException('Die Schriftablage ist nicht verfügbar.',503);
            $fonts=$state['fonts'] ?? [];
            if($path==='/api/settings/fonts'&&$method==='GET')return $this->ok(['fonts'=>$this->fontCatalog($state)]);
            if($path==='/api/settings/fonts'&&$method==='POST'){
                $name=$body['name'] ?? null;if(!is_string($name)||trim($name)===''||strlen(trim($name))>100)throw new RuntimeException('Bitte einen Schriftnamen mit 1 bis 100 Zeichen eingeben.',422);
                $assetId=null;
                if(!array_key_exists('data',$body)&&in_array($this->platform,['wordpress','typo3'],true)){
                    if(!($this->store instanceof CmsMediaStateStore)||!is_string($body['assetId'] ?? null))throw new RuntimeException('Bitte die Schriftdatei im nativen CMS-Medienbrowser auswählen.',422);
                    $asset=$this->required($state['mediaAssets'],$body['assetId'],'Schriftdatei');if(!empty($asset['deletedAt']))throw new RuntimeException('Die Schriftdatei ist nicht verfügbar.',422);
                    $source=$this->store->exportAssetData($asset);$assetId=$asset['id'];
                }else $source=$body['data'] ?? null;
                $decoded=FontStorage::decode($source);$font=$decoded['font']+['name'=>trim($name)];if($assetId!==null)$font['assetId']=$assetId;$index=array_search($font['id'],array_column($fonts,'id'),true);
                if($index===false&&count($fonts)>=20)throw new RuntimeException('Es können höchstens 20 eigene Schriftdateien verwaltet werden.',422);
                $this->fontStorage->put($decoded['bytes']);if($index===false)$fonts[]=$font;else $fonts[$index]=$font;$state['fonts']=$fonts;
                $this->audit($state,'font.registered',$font['id']);return $this->created(['font'=>array_diff_key($font,['assetId'=>true]),'fonts'=>$this->fontCatalog($state)]);
            }
            if($method==='DELETE'&&!empty($fontMatch[1])){
                $id=$fontMatch[1];$this->required($fonts,$id,'Schriftart');
                foreach(['slides','templates','presets','warningTemplates'] as $collection)if(FontStorage::references($state[$collection] ?? [],$id))throw new RuntimeException('Diese Schriftart wird noch in Inhalten oder Vorlagen verwendet.',409);
                $state['fonts']=array_values(array_filter($fonts,static fn(array $font):bool=>$font['id']!==$id));return $this->ok(['fonts'=>$this->fontCatalog($state)],true);
            }
            throw new RuntimeException('Methode nicht erlaubt.',405);
        }

        if(preg_match('#^/api/events/([^/]+)/schedule(?:/([^/]+))?$#',$path,$match))return $this->eventSchedule($state,$method,rawurldecode($match[1]),isset($match[2])?rawurldecode($match[2]):null,$body);
        if($path==='/api/dwd/warncells'&&$method==='GET'){
            if(!$this->dwd)throw new RuntimeException('Der DWD-Dienst ist nicht verfügbar.',503);
            $query=trim((string)($body['q'] ?? ''));
            if(strlen($query)<2)return $this->ok(['data'=>[],'source'=>'Deutscher Wetterdienst','sourceUrl'=>DwdService::WARNCELL_INFO_URL]);
            $cached=$state['dwdWarncellCache'] ?? null;$changed=false;
            if(!$cached || strtotime($cached['loadedAt'])<QualityClock::now()-86400){try{$cached=$this->dwd->warncells();$state['dwdWarncellCache']=$cached;$changed=true;}catch(\Throwable $error){if(!$cached)throw $error;}}
            return $this->ok(['data'=>DwdService::searchWarncells($cached['data'],$query),'loadedAt'=>$cached['loadedAt'],'source'=>'Deutscher Wetterdienst','sourceUrl'=>DwdService::WARNCELL_INFO_URL],$changed);
        }

        if ($path === '/api/api-users') {
            if ($method === 'GET') return $this->ok(['data'=>array_reverse(array_map([ApiAccess::class,'publicUser'],$state['apiUsers']))]);
            if ($method === 'POST') {
                $created = ApiAccess::create($state,$body,(string)$this->identity['id']);
                $this->audit($state,'api_user.created',$created['apiUser']['id']);
                return $this->created($created);
            }
        }
        if (preg_match('#^/api/api-users/([^/]+)$#',$path,$match) && $method === 'DELETE') {
            $id = rawurldecode($match[1]);
            $user = $this->required($state['apiUsers'],$id,'API-Benutzer');
            if ($user['status'] !== 'active') throw new RuntimeException('Aktiver API-Benutzer wurde nicht gefunden.',404);
            $user['status'] = 'revoked';
            $user['revokedAt'] = $user['updatedAt'] = $this->now();
            $state['apiUsers'][$this->index($state['apiUsers'],$id)] = $user;
            $this->audit($state,'api_user.revoked',$id);
            return $this->ok(['apiUser'=>ApiAccess::publicUser($user)],true);
        }

        if ($path === '/api/content-packages/export' && $method === 'POST') {
            $exportAsset = $this->store instanceof CmsMediaStateStore ? fn(array $asset): string => $this->store->exportAssetData($asset) : null;
            $package = (new ContentPackage())->export($state,is_array($body['selection']??null)?$body['selection']:[],$this->platform,$this->version,$exportAsset);
            $this->audit($state,'content_package.exported','content');
            return $this->ok($package,true);
        }
        if ($path === '/api/content-packages/import' && $method === 'POST') {
            $result = (new ContentPackage())->import($state,$body);
            $this->audit($state,'content_package.imported','content');
            return $this->ok(['imported'=>$result],true);
        }

        if(str_starts_with($path,'/api/content-transfer/migration/')&&$method==='POST'){
            if(($this->identity['role'] ?? '')!=='admin')throw new RuntimeException('Systemumzüge sind Administratoren vorbehalten.',403);
            $action=basename($path);
            $users=array_values(array_column([$this->user(),...$this->platformUsers],null,'id'));
            if($action==='export'){
                $source=$state;$credentials=($body['includeCredentials'] ?? false)===true;
                if($credentials){
                    if(!empty($source['crewbrain']['config']['encryptedCredential']))$source['crewbrain']['config']=$this->crewBrain()->exportConfiguration($source['crewbrain']['config'],$source['crewbrain']['mapping'])['connection'];
                    if(!empty($source['easyjob']['config']['encryptedCredentials'])){if(!$this->easyJob)throw new RuntimeException('Der easyjob-Dienst ist nicht verfügbar.',503);$source['easyjob']['config']=$this->easyJob->migrationConfiguration($source['easyjob']['config']);}
                }
                if(!empty($source['fonts'])&&!$this->canReadFonts)throw new RuntimeException('Keine Berechtigung zum Export eigener Schriften.',403);
                $payload=SystemMigration::snapshot($source,$this->platform,$this->version,$users,$credentials,$this->store instanceof CmsMediaStateStore?fn(array $asset):string=>$this->store->exportAssetData($asset,SystemMigration::LIMIT):null,fn(string $id):array=>$this->fontFile($state,$id));
                $package=SystemMigration::seal($payload,$body['password'] ?? null);$this->audit($state,'system_migration.exported',$payload['id']);return $this->ok($package,true);
            }
            $payload=SystemMigration::open(is_array($body['package'] ?? null)?$body['package']:[],$body['password'] ?? null);
            if($action==='preview')return $this->ok(['preview'=>SystemMigration::preview($state,$payload,$users)]);
            if($action==='import'){
                $staged=$state;$result=SystemMigration::stage($staged,$payload,is_array($body['options'] ?? null)?$body['options']:[],$users);
                if(!empty($result['alreadyImported']))return $this->ok(['imported'=>$result]);
                if(!empty($payload['fontFiles'])&&(!$this->fontStorage||!$this->canManageFonts))throw new RuntimeException('Keine Berechtigung zum Import eigener Schriften.',403);
                foreach($payload['fontFiles'] ?? [] as $entry)$this->fontStorage->put(base64_decode($entry['data'],true));
                $crew=$staged['crewbrain']['config'] ?? [];$easy=$staged['easyjob']['config'] ?? [];
                if(!empty($crew['baseUrl']))$staged['crewbrain']['config']=$this->crewBrain()->saveConfig([],$crew);
                if(!empty($easy['baseUrl'])){if(!$this->easyJob)throw new RuntimeException('Der easyjob-Dienst ist nicht verfügbar.',503);$staged['easyjob']['config']=$this->easyJob->saveConfig([],array_replace($easy,$easy['credentials'] ?? []));}
                unset($staged['crewbrain']['config']['credential'],$staged['easyjob']['config']['credentials']);
                if(!empty($staged['menuShare']['passwordHash']))$staged['menuShare']['secret']=bin2hex(random_bytes(32));
                $staged['_migrationSaving']=true;$state=$staged;$this->audit($state,'system_migration.imported',$payload['id']);return $this->created(['imported'=>$result]);
            }
            throw new RuntimeException('Unbekannte Umzugsaktion.',404);
        }

        if ($path === '/api/content-transfer/export' && in_array($method, ['GET', 'POST'], true)) {
            $requested = is_array($body['sections'] ?? null) ? array_values(array_map('strval', $body['sections'])) : [];
            $package = (new TransferService())->export($state, $requested, $this->platform, $this->version, $this->platformUsers);
            $this->audit($state, 'content_transfer.exported', implode(',', $package['includedSections']));
            return $this->ok($package, true);
        }
        if ($path === '/api/content-transfer/import' && $method === 'POST') {
            $result = (new TransferService())->import($state, $body);
            $this->audit($state, 'content_transfer.imported', implode(',', $result['includedSections']));
            return $this->ok(['imported' => $result], true);
        }

        if($path==='/api/event-templates'){
            if($method==='GET')return $this->ok(['data'=>array_map(static fn(array $r):array=>['id'=>$r['id'],'name'=>$r['name'],'title'=>$r['input']['title'],'eventType'=>$r['input']['eventType'] ?? null,'date'=>$r['input']['date'] ?? null,'scheduleCount'=>count($r['schedule']),'updatedAt'=>$r['updatedAt']],EventReuse::templates($state))]);
            if($method==='POST'){$snapshot=$this->eventReuseSnapshot($state,(string)($body['eventId'] ?? ''),$body['input'] ?? null);$template=EventReuse::save($state,$body['name'] ?? null,$snapshot);return $this->created(['template'=>$template]);}
            throw new RuntimeException('Methode nicht erlaubt.',405);
        }
        if(preg_match('#^/api/event-templates/([^/]+)(/create-event)?$#',$path,$match)){
            $id=rawurldecode($match[1]);if(!empty($match[2])&&$method==='POST')return $this->eventReuseCreate($state,EventReuse::get($state,$id),$body);
            if(empty($match[2])){if($method==='GET')return $this->ok(['template'=>EventReuse::get($state,$id)]);if($method==='PUT')return $this->ok(['template'=>EventReuse::save($state,$body['name'] ?? null,['input'=>$body['input'] ?? [],'schedule'=>$body['schedule'] ?? []],$id)],true);if($method==='DELETE'){EventReuse::delete($state,$id);return $this->ok(['ok'=>true],true);}}
            throw new RuntimeException('Methode nicht erlaubt.',405);
        }
        if(preg_match('#^/api/events/([^/]+)/duplicate$#',$path,$match)){if($method!=='POST')throw new RuntimeException('Methode nicht erlaubt.',405);
            $snapshot=$this->eventReuseSnapshot($state,rawurldecode($match[1]),$body['input'] ?? null);$body['title']??=EventReuse::copyTitle($snapshot['input']['title']);return $this->eventReuseCreate($state,$snapshot,$body);
        }
        if ($path === '/api/events') {
            if ($method === 'GET') return $this->ok(['data' => array_values($state['events']),'fieldSettings'=>EventEditorSettings::normalize($state['eventEditorSettings'] ?? []),'serverTime'=>$this->now()]);
            if ($method === 'POST') {
                $event = $this->saveRecord($state, 'events', $this->eventEditorBody($body));
                $this->ensureEventChannel($state, $event);
                return $this->created(['event' => $event]);
            }
        }
        if ($path === '/api/events/bulk' && $method === 'POST') {
            $action = (string)($body['action'] ?? '');
            if($action==='publish'&&(!is_array($body['ids'] ?? null)||count($body['ids'])>1000||array_filter($body['ids'],static fn(mixed $id):bool=>!is_string($id)||trim($id)==='')))throw new RuntimeException('Bitte höchstens 1000 gültige Veranstaltungskennungen auswählen.',422);
            $ids = array_values(array_unique(array_map('strval', is_array($body['ids'] ?? null) ? $body['ids'] : [])));
            if (!$ids) throw new RuntimeException('Bitte mindestens eine Veranstaltung auswählen.', 422);
            if ($action === 'delete' && ($this->identity['role'] ?? '') !== 'admin') {
                throw new RuntimeException('Endgültiges Löschen ist Administratoren vorbehalten.', 403);
            }
            if ($action === 'publish') {
                $result=['count'=>0,'skipped'=>0,'missing'=>0];
                foreach($ids as $id){
                    $index=$this->index($state['events'],$id);
                    if($index===null){$result['missing']++;continue;}
                    $event=$state['events'][$index];
                    if(($event['status'] ?? '')!=='draft'||EventLifecycle::effective($event)!=='draft'){$result['skipped']++;continue;}
                    $this->saveRecord($state,'events',['status'=>'published','lockedFields'=>array_values(array_unique([...($event['lockedFields'] ?? []),'status'])),'syncStatus'=>empty($event['sourceId'])?'manual':'manually_modified'],$id);
                    $result['count']++;
                }
                return $this->ok(['ok'=>true]+$result,$result['count']>0);
            }
            if ($action === 'update') {
                $field = (string)($body['field'] ?? '');
                if (!in_array($field, ['admissionStart', 'eventStart', 'breakStart', 'eventEnd', 'imageUrl'], true)) throw new RuntimeException('Das Feld der Massenaktion ist ungültig.', 422);
                $time = (string)($body['time'] ?? ''); $breakEndTime = (string)($body['breakEndTime'] ?? ''); $imageUrl = trim((string)($body['imageUrl'] ?? ''));
                if ($field === 'imageUrl' && ($imageUrl === '' || strlen($imageUrl) > 2000)) throw new RuntimeException('Bitte ein Veranstaltungsbild auswählen.', 422);
                if ($field !== 'imageUrl' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time)) throw new RuntimeException('Bitte eine gültige Uhrzeit auswählen.', 422);
                if ($breakEndTime !== '' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $breakEndTime)) throw new RuntimeException('Das Ende der Pause ist ungültig.', 422);
                $result = ['updated' => 0, 'skippedManual' => 0, 'skippedWithoutDate' => 0, 'missing' => 0];
                foreach ($ids as $id) {
                    $index = $this->index($state['events'], $id); if ($index === null) { $result['missing']++; continue; }
                    $event = $state['events'][$index]; if (empty($event['sourceId'])) { $result['skippedManual']++; continue; }
                    $locks = is_array($event['lockedFields'] ?? null) ? $event['lockedFields'] : [];
                    if ($field === 'imageUrl') {$event['imageUrl'] = $imageUrl;$event['imageEdit']=null;}
                    else {
                        $value = $this->berlinEventTime((string)($event['date'] ?? ''), $time); if ($value === null) { $result['skippedWithoutDate']++; continue; }
                        $event[$field] = $value;
                        if ($field === 'breakStart' && $breakEndTime !== '') { $event['breakEnd'] = $this->berlinEventTime((string)($event['date'] ?? ''), $breakEndTime); $locks[] = 'breakEnd'; }
                    }
                    $locks[] = $field; $event['lockedFields'] = array_values(array_unique($locks)); $event['syncStatus'] = 'manually_modified';
                    $this->saveRecord($state, 'events', $event, $id); $result['updated']++;
                }
                return $this->ok(['ok' => true, 'count' => $result['updated']] + $result, true);
            }
            foreach ($ids as $id) {
                if ($action === 'archive') {$event=$this->required($state['events'],$id,'Veranstaltung');$this->saveRecord($state,'events',['status'=>'archived'],$id);}
                elseif ($action === 'delete') $this->purgeEvent($state, $id);
                else throw new RuntimeException('Unbekannte Sammelaktion.', 422);
            }
            return $this->ok(['ok' => true, 'count' => count($ids)], true);
        }
        if (preg_match('#^/api/events/([^/]+)$#', $path, $match)) {
            $id = rawurldecode($match[1]);
            if ($method === 'GET') return $this->ok(['event' => $this->required($state['events'], $id, 'Veranstaltung')]);
            if ($method === 'PUT') {
                $current = $this->required($state['events'], $id, 'Veranstaltung');
                $body=$this->eventEditorBody($body);
                if (($current['sourceId'] ?? '') === 'source-crewbrain') {
                    $locked = array_values(array_unique(array_merge(
                        is_array($current['lockedFields'] ?? null) ? $current['lockedFields'] : [],
                        array_keys(array_filter($body, static fn(mixed $value, string $key): bool => !in_array($key, ['id', 'sourceId', 'externalId', 'externalObjectType', 'importHash', 'lastSyncedAt', 'syncStatus'], true) && ($current[$key] ?? null) !== $value, ARRAY_FILTER_USE_BOTH))
                    )));
                    $body['lockedFields'] = $locked;
                }
                if(array_key_exists('ticketLinks',$body)&&!empty($current['sourceId'])){$body['lockedFields']=array_values(array_unique([...($body['lockedFields']??$current['lockedFields']??[]),'ticketUrl','ticketLinks']));$body['syncStatus']='manually_modified';}
                return $this->ok(['event' => $this->saveRecord($state, 'events', $body, $id)], true);
            }
            if ($method === 'DELETE') {if(($this->identity['role'] ?? '')!=='admin')throw new RuntimeException('Löschen ist Administratoren vorbehalten.',403);$this->purgeEvent($state,$id);return $this->ok(['ok'=>true],true);}
        }
        if (preg_match('#^/api/events/([^/]+)/usage$#', $path, $match) && $method === 'GET') {
            return $this->ok($this->eventUsage($state, rawurldecode($match[1])));
        }
        if (preg_match('#^/api/events/([^/]+)/permanent$#', $path, $match) && $method === 'DELETE') {
            if (($this->identity['role'] ?? '') !== 'admin') throw new RuntimeException('Endgültiges Löschen ist Administratoren vorbehalten.', 403);
            $this->purgeEvent($state, rawurldecode($match[1]));
            return $this->ok(['ok' => true], true);
        }

        if ($path === '/api/slides/from-media' && $method === 'POST') {
            $this->license()->assertPath($state,'/api/media');
            $inputs=MediaSlides::inputs($body['mediaAssetIds']??null,$state['mediaAssets']??[],is_array($body['videoDurations']??null)?$body['videoDurations']:[]);
            $tags=$body['tags'] ?? [];
            if(!is_array($tags) || count($tags)>30)throw new RuntimeException('Bitte höchstens 30 Tags auswählen.',422);
            foreach($tags as $tag)if(!is_string($tag) || strlen($tag)>320 || preg_match('//u',$tag)!==1 || preg_match_all('/./us',$tag)>80)throw new RuntimeException('Ungültiger Slide-Tag.',422);
            $inputs=array_map(static fn(array $input): array => array_replace($input,['tags'=>$tags]),$inputs);
            $slides=[];
            foreach($inputs as $input)$slides[]=$this->saveSlide($state,$input);
            return $this->created(['slides'=>$slides]);
        }
        if ($path === '/api/slides') {
            if ($method === 'GET') return $this->ok(['data' => array_values(array_filter($this->listCollection($state,'slides'),fn(array $slide):bool=>!$designer||(($slide['ownerId'] ?? '')===$actorId&&!array_key_exists('menu',$slide['document'] ?? [])&&!array_key_exists('menuPdf',$slide['document'] ?? [])&&empty($slide['automationKey'])&&empty($slide['virtual']))))]);
            if ($method === 'POST') {
                $slide = $this->saveSlide($state, $body);
                return $this->created(['slide' => $slide]);
            }
        }
        if (preg_match('#^/api/slides/([^/]+)/versions$#', $path, $match) && $method === 'GET') {
            return $this->ok(['data' => array_values(array_filter($state['slideVersions'], fn(array $v): bool => $v['slideId'] === rawurldecode($match[1])))]);
        }
        if (preg_match('#^/api/slides/([^/]+)/versions/(\d+)/restore$#', $path, $match) && $method === 'POST') {
            $id = rawurldecode($match[1]);
            $version = $this->first($state['slideVersions'], fn(array $v): bool => $v['slideId'] === $id && (int)$v['version'] === (int)$match[2]);
            if (!$version) throw new RuntimeException('Slide-Version wurde nicht gefunden.', 404);
            $current = $this->required($state['slides'], $id, 'Slide');
            return $this->ok(['slide' => $this->saveSlide($state, array_replace($current, ['document' => $version['document']]), $id)], true);
        }
        if (preg_match('#^/api/slides/([^/]+)/usage$#', $path, $match) && $method === 'GET') {
            $id = rawurldecode($match[1]);
            return $this->ok(['channels' => array_values(array_map(
                fn(array $channel): array => ['id' => $channel['id'], 'name' => $channel['name']],
                array_filter($this->active($state['channels']), fn(array $channel): bool => in_array($id, array_column($channel['items'] ?? [], 'slideId'), true))
            ))]);
        }
        if (preg_match('#^/api/slides/([^/]+)/duplicate$#', $path, $match) && $method === 'POST') {
            $source = $this->required($state['slides'], rawurldecode($match[1]), 'Slide');
            foreach($source['items'] ?? [] as &$item)unset($item['advertisingInterstitial']);unset($item);
            unset($source['id'], $source['createdAt'], $source['updatedAt'], $source['currentVersion']);
            $source['name'] .= ' (Kopie)';
            $source['status'] = 'draft';
            return $this->created(['slide' => $this->saveSlide($state, $source)]);
        }
        if (preg_match('#^/api/slides/([^/]+)(?:/permanent)?$#', $path, $match)) {
            $id = rawurldecode($match[1]);
            if ($method === 'PUT') return $this->ok(['slide' => $this->saveSlide($state, $body, $id)], true);
            if ($method === 'DELETE') {
                if (str_ends_with($path, '/permanent')) return $this->purgeRecord($state, 'slides', $id);
                return $this->trashRecord($state, 'slides', 'slide', $id);
            }
        }

        if ($path === '/api/channels') {
            if ($method === 'GET') return $this->ok(['data' => array_values(array_filter($this->listCollection($state,'channels'),fn(array $channel):bool=>!$designer||in_array($channel['id'],ContentAccess::ids($state,$actorId),true)))]);
            if ($method === 'POST') return $this->created(['channel' => $this->saveRecord($state, 'channels', $body + ['items' => []])]);
        }
        if (preg_match('#^/api/channels/([^/]+)/usage$#', $path, $match) && $method === 'GET') {
            $id = rawurldecode($match[1]);
            return $this->ok([
                'schedules' => array_values(array_filter($state['schedules'], fn(array $item): bool => ($item['channelId'] ?? '') === $id)),
                'displays' => array_values(array_map(fn(array $item): array => ['id' => $item['id'], 'name' => $item['name']], array_filter($this->active($state['displays']), fn(array $item): bool => ($item['defaultChannelId'] ?? '') === $id))),
            ]);
        }
        if (preg_match('#^/api/channels/([^/]+)/duplicate$#', $path, $match) && $method === 'POST') {
            $source = $this->required($state['channels'], rawurldecode($match[1]), 'Kanal');
            $source=AdvertisingService::channel($state,$source);
            foreach($source['items'] as &$item)if(!empty($item['slide']['virtual'])){$copy=array_diff_key($item['slide'],array_flip(['id','createdAt','updatedAt','automationKey','virtual','currentVersion']));$copy['name'].=' (Kopie)';$copy['status']='draft';$saved=$this->saveSlide($state,$copy);$item['slideId']=$saved['id'];unset($item['slide']);}unset($item);
            foreach($source['items'] ?? [] as &$item)unset($item['advertisingInterstitial']);unset($item);
            unset($source['id'], $source['createdAt'], $source['updatedAt'], $source['automationKey'], $source['deletedAt']);
            $source['name'] .= ' (Kopie)';
            $source['status'] = 'draft';
            return $this->created(['channel' => $this->saveRecord($state, 'channels', $source)]);
        }
        if (preg_match('#^/api/channels/([^/]+)(?:/permanent)?$#', $path, $match)) {
            $id = rawurldecode($match[1]);
            if ($method === 'PUT') {$record=$this->saveRecord($state,'channels',$body,$id);return $this->ok(['channel'=>AdvertisingService::channel($state,$record)],true);}
            if ($method === 'DELETE') {
                if (str_ends_with($path, '/permanent')) return $this->purgeRecord($state, 'channels', $id);
                return $this->trashRecord($state, 'channels', 'channel', $id);
            }
        }

        if (str_starts_with($path,'/api/templates/') && $method!=='GET') {
            $template=$this->required($state['templates'],rawurldecode(substr($path,15)),'Vorlage');
            if (($template['document']['menuTemplate'] ?? false)===true || !empty($body['document']['menuTemplate'])) throw new RuntimeException('Speisekarten-Vorlagen bitte im Speisekarten-Modul speichern.',403);
        }
        if ($path === '/api/templates' && $method==='POST' && !empty($body['document']['menuTemplate'])) throw new RuntimeException('Speisekarten-Vorlagen bitte im Speisekarten-Modul anlegen.',422);
        if ($path === '/api/templates') return $this->collectionRoute($state, $method, 'templates', 'template', $body);
        if (preg_match('#^/api/templates/([^/]+)$#', $path, $match)) return $this->itemRoute($state, $method, 'templates', 'template', rawurldecode($match[1]), $body);

        if ($path === '/api/media' && $method === 'GET') return $this->ok(['folders' => $this->active($state['mediaFolders']), 'assets' => $state['mediaAssets']]);
        if ($path === '/api/media/folders' && $method === 'POST') return $this->created(['folder' => $this->saveRecord($state, 'mediaFolders', $body)]);
        if (preg_match('#^/api/media/folders/([^/]+)$#', $path, $match)) return $this->itemRoute($state, $method, 'mediaFolders', 'folder', rawurldecode($match[1]), $body, false);
        if ($path === '/api/media/assets' && $method === 'POST') return $this->created(['asset' => $this->saveRecord($state, 'mediaAssets', $body)]);
        if (preg_match('#^/api/media/assets/([^/]+)/(restore|permanent)$#', $path, $match)) {
            $id = rawurldecode($match[1]);
            if ($match[2] === 'restore' && $method === 'POST') return $this->restoreRecord($state, 'mediaAssets', $id);
            if ($match[2] === 'permanent' && $method === 'DELETE') return $this->purgeRecord($state, 'mediaAssets', $id);
        }
        if (preg_match('#^/api/media/assets/([^/]+)$#', $path, $match)) {
            $id = rawurldecode($match[1]);
            if ($method === 'PUT') return $this->ok(['asset' => $this->saveRecord($state, 'mediaAssets', $body, $id)], true);
            if ($method === 'DELETE') return $this->trashRecord($state, 'mediaAssets', 'media', $id);
        }
        if (preg_match('#^/api/displays/([^/]+)/pair$#', $path, $match) && $method === 'POST') {
            $display = $this->required($state['displays'], rawurldecode($match[1]), 'Display');
            $code = strtoupper(trim((string)($body['code'] ?? '')));
            $pairing = $this->first($state['playerPairings'], fn(array $item): bool => ($item['code'] ?? '') === $code && ($item['status'] ?? '') === 'pending' && strtotime((string)($item['expiresAt'] ?? '')) > QualityClock::now());
            if (!$pairing) throw new RuntimeException('Der Kopplungscode ist ungültig oder abgelaufen.', 404);
            $index = $this->index($state['playerPairings'], (string)$pairing['id']);
            $state['playerPairings'][$index]['status'] = 'paired';
            $state['playerPairings'][$index]['displayId'] = $display['id'];
            $state['playerPairings'][$index]['pairedAt'] = $this->now();
            return $this->ok(['pairing' => ['id' => $pairing['id'], 'status' => 'paired']], true);
        }

        if ($path === '/api/schedules/block' && $method === 'PUT') {
            $available=[];
            foreach (['display'=>'displays','group'=>'groups','matrix'=>'matrices'] as $type=>$collection) $available[$type]=array_column($this->active($state[$collection]),'id');
            $plan=ScheduleBlock::plan($body,$state['schedules'],$available);
            $entries=[];
            foreach($plan['saves'] as $save) {
                $result=$save['id']?$this->itemRoute($state,'PUT','schedules','entry',$save['id'],$save['input']):$this->collectionRoute($state,'POST','schedules','entry',$save['input']);
                $entries[]=$result[1]['entry'];
            }
            foreach($plan['removeIds'] as $id)$this->itemRoute($state,'DELETE','schedules','entry',$id,[]);
            return $this->ok(['entries'=>$entries],true);
        }

        foreach ([
            '/api/presets' => ['presets', 'preset'],
            '/api/displays' => ['displays', 'display'],
            '/api/display-groups' => ['groups', 'group'],
            '/api/locations' => ['locations', 'location'],
            '/api/matrix-displays' => ['matrices', 'matrix'],
            '/api/schedules' => ['schedules', 'entry'],
            '/api/warning-templates' => ['warningTemplates', 'template'],
            '/api/warnings' => ['warnings', 'warning'],
        ] as $route => [$collection, $singular]) {
            if ($path === $route) return $this->collectionRoute($state, $method, $collection, $singular, $body);
        }

        if (preg_match('#^/api/matrix-displays/([^/]+)/duplicate$#', $path, $match) && $method === 'POST') {
            $source = $this->required($state['matrices'], rawurldecode($match[1]), 'Matrix');
            foreach($source['items'] ?? [] as &$item)unset($item['advertisingInterstitial']);unset($item);
            unset($source['id'], $source['createdAt'], $source['updatedAt']);
            $source['name'] .= ' (Kopie)';
            $source['status'] = 'disabled';
            return $this->created(['matrix' => $this->saveRecord($state, 'matrices', $source)]);
        }
        if (preg_match('#^/api/(presets|displays|display-groups|locations|matrix-displays|schedules|warning-templates)/([^/]+)$#', $path, $match)) {
            $map = [
                'presets' => ['presets', 'preset', false],
                'displays' => ['displays', 'display', true],
                'display-groups' => ['groups', 'group', true],
                'locations' => ['locations', 'location', true],
                'matrix-displays' => ['matrices', 'matrix', true],
                'schedules' => ['schedules', 'entry', false],
                'warning-templates' => ['warningTemplates', 'template', false],
            ];
            [$collection, $singular, $trash] = $map[$match[1]];
            return $this->itemRoute($state, $method, $collection, $singular, rawurldecode($match[2]), $body, $trash);
        }

        if ($path === '/api/schedule-target-order') {
            if ($method === 'GET') return $this->ok(['data' => $state['scheduleTargetOrder']]);
            if ($method === 'PUT') {
                $state['scheduleTargetOrder'] = array_values(array_map('strval', $body['targetKeys'] ?? []));
                return $this->ok(['data' => $state['scheduleTargetOrder']], true);
            }
        }
        if ($path === '/api/schedules/publish' && $method === 'POST') {
            foreach ($state['schedules'] as &$schedule) $schedule['status'] = 'published';
            unset($schedule);
            return $this->ok(['count' => count($state['schedules'])], true);
        }
        if ($path === '/api/trash' && $method === 'GET') return $this->ok(['data' => array_values(array_filter($state['trash'],fn(array $item):bool=>!$designer||(($item['type'] ?? '')==='slide'&&($this->first($state['slides'],static fn(array $slide):bool=>$slide['id']===$item['id'])['ownerId'] ?? '')===$actorId)))]);
        if (preg_match('#^/api/trash/([^/]+)/([^/]+)$#', $path, $match)) {
            $type = rawurldecode($match[1]);
            $id = rawurldecode($match[2]);
            $collection = ['event' => 'events', 'slide' => 'slides', 'channel' => 'channels', 'display' => 'displays', 'display_group' => 'groups', 'location' => 'locations', 'matrix' => 'matrices', 'media' => 'mediaAssets'][$type] ?? '';
            if (!$collection) throw new RuntimeException('Unbekannter Papierkorbtyp.');
            if ($method === 'POST') return $this->restoreTrash($state, $collection, $type, $id);
            if ($method === 'DELETE') return $this->purgeTrash($state, $collection, $type, $id);
        }

        if (preg_match('#^/api/warnings/([^/]+)/(publish|end)$#', $path, $match) && $method === 'POST') {
            $id = rawurldecode($match[1]);
            $warning = $this->required($state['warnings'], $id, 'Warnhinweis');
            $warning['status'] = $match[2] === 'publish' ? 'active' : 'ended';
            $warning[$match[2] === 'publish' ? 'publishedAt' : 'endedAt'] = $this->now();
            $warning = $this->saveRecord($state, 'warnings', $warning, $id);
            return $this->ok($match[2] === 'publish' ? ['warning' => $warning] : ['ok' => true], true);
        }
        if (preg_match('#^/api/operations/displays/([^/]+)/commands$#', $path, $match) && $method === 'POST') {
            $displayId=rawurldecode($match[1]);$this->required($this->active($state['displays']),$displayId,'Display');
            if (!in_array($body['command'] ?? '',['sync','reload','identify','fullscreen'],true)) throw new RuntimeException('Unbekannter Player-Befehl.',422);
            $command = $this->record(['displayId' => $displayId, 'command' => $body['command']]);
            $state['commands'][] = $command;
            return $this->created(['command' => $command]);
        }
        if($path==='/api/preset-triggers'){
            if($method==='GET')return $this->ok(['data'=>PresetTriggers::listing($state),'runs'=>PresetTriggers::runs($state),'serverTime'=>$this->now()]);
            if($method==='POST'){$trigger=PresetTriggers::save($state,$body);$this->audit($state,'preset.trigger.created',$trigger['id']);return $this->created(['trigger'=>$trigger]);}
        }
        if(preg_match('#^/api/preset-triggers/([^/]+)$#',$path,$match)){
            $id=rawurldecode($match[1]);
            if($method==='PUT'){$trigger=PresetTriggers::save($state,$body,$id);$this->audit($state,'preset.trigger.updated',$id);return $this->ok(['trigger'=>$trigger],true);}
            if($method==='DELETE'){PresetTriggers::delete($state,$id);$this->audit($state,'preset.trigger.deleted',$id);return $this->ok(['ok'=>true],true);}
        }
        if (preg_match('#^/api/presets/([^/]+)/execute$#', $path, $match) && $method === 'POST') return $this->executeStoredPreset($state,rawurldecode($match[1]),$body);
        if ($path === '/api/operations' && $method === 'GET') {
            $emergency = $this->first(array_reverse($state['warnings']), fn(array $item): bool => ($item['status'] ?? '') === 'active' && ($item['source'] ?? '') === 'legacy-emergency');
            return $this->ok(['displays' => $this->listCollection($state, 'displays'), 'emergency' => $emergency, 'warnings' => $state['warnings']]);
        }
        if ($path === '/api/operations/proof' && $method === 'GET') throw new RuntimeException('Proof of Play ist deaktiviert.', 410);
        if ($path === '/api/operations/emergency' && $method === 'POST') {
            $warning = $this->saveRecord($state, 'warnings', $body + [
                'source' => 'legacy-emergency',
                'warningType' => $body['type'] ?? 'emergency',
                'title' => $body['title'] ?? 'Warnhinweis',
                'description' => $body['message'] ?? '',
                'instructions' => $body['message'] ?? '',
                'severity' => 5,
                'priority' => 1000,
                'targets' => $body['targets'] ?? ['global'],
                'status' => 'active',
                'publishedAt' => $this->now(),
            ]);
            return $this->created(['alert' => $warning]);
        }
        if ($path === '/api/operations/emergency' && $method === 'DELETE') {
            foreach ($state['warnings'] as &$warning) {
                if (($warning['source'] ?? '') === 'legacy-emergency' && ($warning['status'] ?? '') === 'active') {
                    $warning['status'] = 'ended';
                    $warning['endedAt'] = $this->now();
                }
            }
            unset($warning);
            return $this->ok(['ok' => true], true);
        }

        if (preg_match('#^/api/dwd/config/([^/]+)$#', $path, $match)) {
            $locationId = rawurldecode($match[1]);
            if ($method === 'GET') return $this->ok(['configuration' => $state['dwd'][$locationId] ?? ['locationId' => $locationId, 'enabled' => true, 'confirmationRequired' => true, 'minSeverity' => 2, 'eventTypes' => [], 'targets' => ['location:' . $locationId]]]);
            if ($method === 'PUT') {
                $state['dwd'][$locationId] = array_replace($state['dwd'][$locationId] ?? [], $body, ['locationId' => $locationId, 'id' => (string)($state['dwd'][$locationId]['id'] ?? $this->uuid()), 'updatedAt' => $this->now()]);
                return $this->ok(['configuration' => $state['dwd'][$locationId]], true);
            }
        }
        if (preg_match('#^/api/dwd/(warnings|sync)/([^/]+)$#', $path, $match)) {
            if (!$this->dwd) throw new RuntimeException('Der DWD-HTTP-Dienst ist in dieser CMS-Ausgabe nicht verfügbar.', 503);
            $locationId = rawurldecode($match[2]);
            $location = $this->required($state['locations'], $locationId, 'Standort');
            $warnings = $this->dwd->warnings((string)($location['warningAreaCode'] ?? ''));
            $configuration = $state['dwd'][$locationId] ?? ['locationId' => $locationId, 'enabled' => true, 'confirmationRequired' => true, 'minSeverity' => 2, 'eventTypes' => [], 'targets' => ['location:' . $locationId]];
            $warnings = array_values(array_filter($warnings, static function (array $warning) use ($configuration): bool {
                if ((int)($warning['severity'] ?? 0) < (int)($configuration['minSeverity'] ?? 2)) return false;
                $types = is_array($configuration['eventTypes'] ?? null) ? array_filter(array_map('strval', $configuration['eventTypes'])) : [];
                return !$types || in_array((string)($warning['warningType'] ?? ''), $types, true);
            }));
            if ($match[1] === 'warnings' && $method === 'GET') return $this->ok(['data' => $warnings]);
            if ($match[1] === 'sync' && $method === 'POST') {
                $saved = [];
                foreach ($warnings as $warning) {
                    $existing = $this->first($state['warnings'], fn(array $item): bool => ($item['source'] ?? '') === 'dwd' && ($item['externalId'] ?? '') === ($warning['externalId'] ?? ''));
                    $warning = array_replace($existing ?? [], $warning, [
                        'locationId' => $locationId,
                        'priority' => 900,
                        'targets' => $configuration['targets'] ?? ['location:' . $locationId],
                        'returnBehavior' => 'resume_current_schedule',
                        'status' => empty($configuration['confirmationRequired']) ? 'active' : 'pending',
                        ...((empty($configuration['confirmationRequired'])) ? ['publishedAt' => $this->now()] : []),
                    ]);
                    $saved[] = $this->saveRecord($state, 'warnings', $warning, $existing['id'] ?? null);
                }
                $state['dwd'][$locationId] = array_replace($configuration, ['lastCheckedAt' => $this->now()]);
                $this->audit($state, 'dwd.warnings.synced', $locationId);
                return $this->ok(['data' => $saved, 'fetched' => count($warnings), 'autoPublished' => empty($configuration['confirmationRequired'])], true);
            }
            throw new RuntimeException('Methode nicht erlaubt.', 405);
        }

        if ($path === '/api/integrations/crewbrain' && $method === 'GET') {
            $service = $this->crewBrain();
            return $this->ok($service->publicConfig($state['crewbrain']['config']));
        }
        if ($path === '/api/integrations/crewbrain' && $method === 'PUT') {
            $service = $this->crewBrain();
            $state['crewbrain']['config'] = $service->saveConfig($state['crewbrain']['config'], $body);
            $this->audit($state, 'crewbrain.connection.updated', (string)$state['crewbrain']['config']['id']);
            return $this->ok($service->publicConfig($state['crewbrain']['config']), true);
        }
        if ($path === '/api/integrations/crewbrain/configuration-export' && $method === 'GET') {
            $service = $this->crewBrain();
            $export = $service->exportConfiguration($state['crewbrain']['config'], $state['crewbrain']['mapping']);
            $this->audit($state, 'crewbrain.configuration.exported', (string)($state['crewbrain']['config']['id'] ?? 'crewbrain'));
            return $this->ok($export, true);
        }
        if ($path === '/api/integrations/crewbrain/configuration-import' && $method === 'POST') {
            $service = $this->crewBrain();
            $imported = $service->importConfiguration($state['crewbrain']['config'], $body);
            $state['crewbrain']['config'] = $imported['config'];
            $state['crewbrain']['mapping'] = $imported['mapping'];
            $this->audit($state, 'crewbrain.configuration.imported', (string)$state['crewbrain']['config']['id']);
            return $this->ok([
                'config' => $service->publicConfig($state['crewbrain']['config']),
                'mapping' => $state['crewbrain']['mapping'],
            ], true);
        }
        if ($path === '/api/integrations/crewbrain/mapping' && $method === 'GET') return $this->ok($state['crewbrain']['mapping']);
        if ($path === '/api/integrations/crewbrain/mapping' && $method === 'PUT') {
            $state['crewbrain']['mapping'] = $this->crewBrain()->validateMapping($body);
            $this->audit($state, 'crewbrain.mapping.updated', 'mapping-crewbrain-default');
            return $this->ok($state['crewbrain']['mapping'], true);
        }
        if ($path === '/api/integrations/crewbrain/access-token' && $method === 'POST') {
            $service = $this->crewBrain();
            $token = $service->requestAccessToken($body);
            $state['crewbrain']['config'] = $service->saveConfig($state['crewbrain']['config'], array_replace($body, [
                'authType' => 'api_key',
                'credential' => ['apiKey' => $token],
            ]));
            unset($body['username'], $body['password']);
            $this->audit($state, 'crewbrain.access_token.created', (string)$state['crewbrain']['config']['id']);
            return $this->ok($service->publicConfig($state['crewbrain']['config']), true);
        }
        if ($path === '/api/integrations/crewbrain/test' && $method === 'POST') {
            $service = $this->crewBrain();
            $result = $service->test($state['crewbrain']['config']);
            $state['crewbrain']['config']['lastApiVersion'] = $result['apiVersion'] ?? 'API v2';
            $state['crewbrain']['config']['lastError'] = $result['ok'] ? null : ($result['error']['message'] ?? 'Verbindungstest fehlgeschlagen.');
            if ($result['ok']) $state['crewbrain']['config']['lastSuccessAt'] = $this->now();
            $this->audit($state, 'crewbrain.connection.tested', (string)($state['crewbrain']['config']['id'] ?? 'crewbrain'));
            return [$result['ok'] ? 200 : 422, $result, true];
        }
        if ($path === '/api/integrations/crewbrain/import-preview' && $method === 'POST') {
            $service = $this->crewBrain();
            $page = $service->listEvents($state['crewbrain']['config'], $body);
            $data = [];
            $excluded = 0;
            foreach ($page['data'] as $event) {
                $mapped = $service->mapEvent($event, $state['crewbrain']['mapping']);
                if ($service->titleExclusion($event, (string)$mapped['title'], $this->titleExclusions($state))) {
                    $excluded++;
                    continue;
                }
                $data[] = [
                    'crewbrain' => [
                        'id' => $event['ID'] ?? null,
                        'type' => $event['Type'] ?? null,
                        'subtype' => $event['Subtype'] ?? null,
                        'number' => $event['EventIDFormatted'] ?? $event['EventIDManual'] ?? null,
                        'changedAt' => $event['ChangedDate'] ?? null,
                    ],
                    'event' => $mapped,
                    'plannedAction' => 'review',
                ];
            }
            $this->audit($state, 'crewbrain.import.previewed', (string)($state['crewbrain']['config']['id'] ?? 'crewbrain'));
            return $this->ok(array_replace($page, ['data' => $data, 'itemCount' => count($data), 'excludedCount' => $excluded]), true);
        }
        if ($path === '/api/integrations/crewbrain/import' && $method === 'POST') {
            $ids = array_values(array_unique(array_slice(array_filter(
                array_map('strval', is_array($body['ids'] ?? null) ? $body['ids'] : []),
                static fn(string $id): bool => preg_match('/^\d+$/', $id) === 1
            ), 0, 100)));
            if (!$ids) throw new RuntimeException('Bitte mindestens eine Veranstaltung zum Import auswählen.', 422);
            $results = $this->importCrewBrainIds($state, $ids);
            $summary = [
                'created' => count(array_filter($results, fn(array $item): bool => $item['action'] === 'created')),
                'updated' => count(array_filter($results, fn(array $item): bool => $item['action'] === 'updated')),
                'unchanged' => count(array_filter($results, fn(array $item): bool => $item['action'] === 'unchanged')),
                'excluded' => count(array_filter($results, fn(array $item): bool => $item['action'] === 'excluded')),
                'errors' => count(array_filter($results, fn(array $item): bool => $item['action'] === 'error')),
            ];
            $this->audit($state, 'crewbrain.events.imported', (string)($state['crewbrain']['config']['id'] ?? 'crewbrain'));
            return [$summary['errors'] ? 207 : 200, ['summary' => $summary, 'results' => $results], true];
        }

        if ($path === '/api/integrations/sources' && $method === 'GET') {
            return $this->ok($this->integrationSources($state));
        }
        if ($path === '/api/integrations/sources' && $method === 'PUT') {
            $activeSource = $body['activeSource'] ?? null;
            if ($activeSource !== null && !in_array($activeSource, ['crewbrain', 'easyjob'], true)) throw new RuntimeException('Die ausgewählte Datenquelle ist ungültig.', 422);
            if($activeSource!==null)$this->license()->assertPath($state,'/api/integrations/'.$activeSource);
            if ($activeSource === 'crewbrain' && empty($state['crewbrain']['config']['encryptedCredential'])) throw new RuntimeException('CrewBrain muss zuerst vollständig konfiguriert werden.', 422);
            if ($activeSource === 'easyjob' && empty($state['easyjob']['config']['encryptedCredentials'])) throw new RuntimeException('easyjob muss zuerst vollständig konfiguriert werden.', 422);
            $state['activeEventSource'] = $activeSource;
            $this->audit($state, 'integration.source.activated', $activeSource ?: 'none');
            return $this->ok($this->integrationSources($state), true);
        }
        if ($path === '/api/integrations/title-exclusions' && $method === 'GET') {
            return $this->ok(['titleExclusions' => $this->titleExclusions($state)]);
        }
        if ($path === '/api/integrations/title-exclusions' && $method === 'PUT') {
            $state['titleExclusions'] = $this->normalizeTitleExclusions($body['titleExclusions'] ?? []);
            $state['crewbrain']['config']['titleExclusions'] = $state['titleExclusions'];
            $this->audit($state, 'integration.title_exclusions.updated', 'title_exclusions');
            return $this->ok(['titleExclusions' => $state['titleExclusions']], true);
        }

        if ($path === '/api/integrations/easyjob/schedule/types' && $method === 'GET') return $this->ok(['data'=>EasyJobService::roomUseTypes($state['easyjob']['roomUseTypeRules'] ?? [])]);
        if ($path === '/api/integrations/easyjob/schedule/types' && $method === 'PUT') {
            $rule=EasyJobService::roomUseType($body);
            $state['easyjob']['roomUseTypeRules'][$rule['normalizedType']]=$rule;
            $this->audit($state,'easyjob.schedule.mapping.updated',$rule['normalizedType']);
            return $this->ok(['rule'=>$rule],true);
        }
        if ($path === '/api/integrations/easyjob' && $method === 'GET') return $this->ok($this->easyJob()->publicConfig($state['easyjob']['config']));
        if ($path === '/api/integrations/easyjob' && $method === 'PUT') {
            $state['easyjob']['config'] = $this->easyJob()->saveConfig($state['easyjob']['config'], $body);
            return $this->ok($this->easyJob()->publicConfig($state['easyjob']['config']), true);
        }
        if ($path === '/api/integrations/easyjob/mapping' && $method === 'GET') return $this->ok($state['easyjob']['mapping']);
        if ($path === '/api/integrations/easyjob/mapping' && $method === 'PUT') {
            $state['easyjob']['mapping'] = $this->easyJob()->validateMapping($body);
            $this->audit($state, 'easyjob.mapping.updated', 'mapping-easyjob-default');
            return $this->ok($state['easyjob']['mapping'], true);
        }
        if ($path === '/api/integrations/easyjob/test' && $method === 'POST') {
            $result = $this->easyJob()->test($state['easyjob']['config']);
            if ($result['ok']) $state['easyjob']['config']['lastSuccessAt'] = $this->now();
            return [$result['ok'] ? 200 : 422, $result, true];
        }
        if ($path === '/api/integrations/easyjob/import-preview' && $method === 'POST') {
            $projects = $this->easyJob()->projects($state['easyjob']['config'], ['searchtext' => $body['search'] ?? '', 'style' => 'List', 'startdate' => $body['from'] ?? '', 'enddate' => $body['until'] ?? '']);
            $data = [];
            $excluded = 0;
            foreach ($projects as $project) {
                $mapped = $this->easyJob()->mapEvent($project, null, $state['easyjob']['mapping']);
                if ($this->matchingTitleExclusion((string)($mapped['title'] ?? ''), $this->titleExclusions($state))) {
                    $excluded++;
                    continue;
                }
                $projectId=(string)($project['IdProject'] ?? $project['ID'] ?? $project['Id'] ?? '');$jobs=[];$warnings=[];
                try{
                    $project=array_replace($project,$this->easyJob()->project($state['easyjob']['config'],$projectId));
                    $mapped=$this->easyJob()->mapEvent($project,null,$state['easyjob']['mapping']);
                    foreach(($project['Jobs'] ?? []) as $listedJob){
                        if(!is_array($listedJob))continue;$jobId=(string)($listedJob['IdJob'] ?? $listedJob['ID'] ?? $listedJob['Id'] ?? '');if($jobId==='')continue;
                        try{$job=$this->easyJob()->job($state['easyjob']['config'],$jobId);$jobEvent=$this->easyJob()->mapEvent($project,$job,$state['easyjob']['mapping']);
                            if($this->matchingTitleExclusion((string)$jobEvent['title'],$this->titleExclusions($state)))continue;
                            if(!empty($body['eventType'])&&stripos((string)($jobEvent['eventType'] ?? ''),(string)$body['eventType'])===false)continue;
                            $jobs[]=['easyjob'=>['projectId'=>$projectId,'jobId'=>$jobId,'number'=>$job['Number'] ?? null],'event'=>$jobEvent,'quality'=>['valid'=>true,'errors'=>[],'warnings'=>[]],'roomUses'=>[]];
                        }catch(\Throwable $error){$jobs[]=['easyjob'=>['projectId'=>$projectId,'jobId'=>$jobId],'event'=>['title'=>$listedJob['Caption'] ?? $jobId],'quality'=>['valid'=>false,'errors'=>[$error->getMessage()],'warnings'=>[]],'roomUses'=>[]];}
                    }
                }catch(\Throwable $error){$warnings[]=$error->getMessage();}
                if($this->matchingTitleExclusion((string)$mapped['title'],$this->titleExclusions($state))){$excluded++;continue;}
                if(($body['objectType'] ?? '')==='job'&&!$jobs)continue;
                $data[] = ['easyjob' => ['projectId' => $projectId, 'number' => $project['Number'] ?? $project['CustomNumber'] ?? null], 'event' => $mapped, 'jobs'=>($body['objectType'] ?? '')==='project'?[]:$jobs,'quality'=>['valid'=>true,'errors'=>[],'warnings'=>$warnings], 'plannedAction' => 'review'];
            }
            return $this->ok(['data' => $data, 'itemCount' => count($data), 'totalItems' => count($projects), 'excludedCount' => $excluded], true);
        }
        if ($path === '/api/integrations/easyjob/import' && $method === 'POST') {
            $ids = array_slice(array_values(array_unique(array_map('strval', is_array($body['ids'] ?? null) ? $body['ids'] : []))), 0, 100);
            if (!$ids) throw new RuntimeException('Bitte mindestens ein easyjob-Projekt auswählen.', 422);
            $fallbackKind=match($state['easyjob']['config']['importMode'] ?? ''){'projects'=>'project','jobs'=>'job',default=>'both'};
            $kind=in_array($body['importKind'] ?? null,['project','job','both'],true)?$body['importKind']:$fallbackKind;
            $selectedJobs=array_values(array_unique(array_map('strval',is_array($body['jobIds'] ?? null)?$body['jobIds']:[])));
            $results = [];
            foreach ($ids as $projectId) {
                try {
                    $project = $this->easyJob()->project($state['easyjob']['config'], $projectId);
                    if ($kind !== 'job') {
                        $mapped = $this->easyJob()->mapEvent($project, null, $state['easyjob']['mapping']);
                        $exclusion = $this->matchingTitleExclusion((string)($mapped['title'] ?? ''), $this->titleExclusions($state));
                        if ($exclusion) $results[] = ['action' => 'excluded', 'reason' => $exclusion, 'projectId' => $projectId];
                        else { $result = $this->upsertExternalEvent($state, $mapped); $result['projectId'] = $projectId; $result['images'] = $this->syncEasyJobAdvertisingImages($state, $result['event'], $projectId); $results[] = $result; }
                    }
                    if ($kind !== 'project') foreach (($project['Jobs'] ?? []) as $listedJob) {
                        if (!is_array($listedJob)) continue;
                        $jobId = (string)($listedJob['IdJob'] ?? $listedJob['ID'] ?? $listedJob['Id'] ?? '');
                        if($selectedJobs&&!in_array($jobId,$selectedJobs,true))continue;
                        if ($jobId !== '') {
                            $mapped = $this->easyJob()->mapEvent($project, $this->easyJob()->job($state['easyjob']['config'], $jobId), $state['easyjob']['mapping']);
                            $exclusion = $this->matchingTitleExclusion((string)($mapped['title'] ?? ''), $this->titleExclusions($state));
                            if ($exclusion) $results[] = ['action' => 'excluded', 'reason' => $exclusion, 'projectId' => $projectId, 'jobId' => $jobId];
                            else { $result = $this->upsertExternalEvent($state, $mapped); $result['projectId'] = $projectId; $result['jobId'] = $jobId; $result['images'] = $this->syncEasyJobAdvertisingImages($state, $result['event'], $projectId, $jobId); $results[] = $result; }
                        }
                    }
                } catch (Throwable $error) { $results[] = ['action' => 'error', 'reason' => $error->getMessage(), 'projectId' => $projectId]; }
            }
            $summary = ['created' => count(array_filter($results, fn(array $item): bool => ($item['action'] ?? '') === 'created')), 'updated' => count(array_filter($results, fn(array $item): bool => ($item['action'] ?? '') === 'updated')), 'unchanged' => count(array_filter($results, fn(array $item): bool => ($item['action'] ?? '') === 'unchanged')), 'excluded' => count(array_filter($results, fn(array $item): bool => ($item['action'] ?? '') === 'excluded')), 'errors' => count(array_filter($results, fn(array $item): bool => ($item['action'] ?? '') === 'error')), 'imagesImported' => array_sum(array_map(fn(array $item): int => (int)($item['images']['imported'] ?? 0), $results)), 'imagesUpdated' => array_sum(array_map(fn(array $item): int => (int)($item['images']['updated'] ?? 0), $results)), 'imagesRemoved' => array_sum(array_map(fn(array $item): int => (int)($item['images']['removed'] ?? 0), $results)), 'imageWarnings' => array_sum(array_map(fn(array $item): int => count($item['images']['warnings'] ?? []), $results))];
            return [$summary['errors'] ? 207 : 200, ['summary' => $summary, 'results' => $results], true];
        }

        if ($path === '/api/settings/advertising' && $method === 'GET') return $this->ok(AdvertisingService::status($state));
        if ($path === '/api/settings/advertising' && $method === 'PUT') {
            AdvertisingService::saveSettings($state,$body);
            $status = $this->synchronizeAdvertising($state);
            $this->audit($state,'advertising.settings.updated','advertising_settings');
            return $this->ok($status,true);
        }
        if ($path === '/api/advertising/synchronize' && $method === 'POST') return $this->ok($this->synchronizeAdvertising($state),true);

        if ($path === '/api/settings/menu-share' && $method === 'GET') return $this->ok(MenuShare::publicConfig($state));
        if ($path === '/api/settings/menu-share' && $method === 'PUT') {
            $result=MenuShare::save($state,$body);$this->audit($state,'menu.share.updated','menu_share');return $this->ok($result,true);
        }
        if ($path === '/api/settings/menus' && $method === 'GET') return $this->ok(['settings'=>MenuContent::settings($state['menuSettings'] ?? []),'enabled'=>($state['featureSettings']['menus'] ?? true) !== false]);
        if ($path === '/api/settings/menus' && $method === 'PUT') { $settings=MenuContent::settings($body);
            if (str_starts_with($settings['defaultTemplate'],'template:')) {
                $template=$this->required($this->active($state['templates']),substr($settings['defaultTemplate'],9),'Speisekarten-Vorlage');
                if (($template['document']['menuTemplate'] ?? false)!==true) throw new RuntimeException('Die Speisekarten-Vorlage ist nicht verfügbar.',422);
            }
            $state['menuSettings'] = $settings; $this->audit($state,'menu.settings.updated','menu_settings'); return $this->ok(['settings'=>$state['menuSettings'],'enabled'=>($state['featureSettings']['menus'] ?? true) !== false],true); }
        if ($path === '/api/settings/features' && $method === 'GET') return $this->ok(['data' => $this->license()->features($state),'licensedModules'=>$this->license()->grants($state), 'navigationOrder' => $this->normalizeNavigationOrder($state['navigationOrder'] ?? []),'menuAccess'=>($this->identity['role'] ?? '') === 'admin' || !empty($state['menuAccess'][$this->identity['id']]['enabled'])]);
        if ($path === '/api/settings/features' && $method === 'PUT') {
            $allowed = ['dashboard', 'events', 'displays', 'channels', 'menus', 'advertising', 'media', 'schedule', 'operations', 'integrations', 'updates', 'settings', 'users', 'content', 'presets_warnings'];
            $allowed=array_merge($allowed,array_map(static fn(string $type):string=>'editor_'.$type,['text','ticker','weather','qr-code','countdown','image','video','web','event','event-table','event-stamp','event-field','wayfinding','alert-icon']));
            foreach($allowed as $key){$module=LicenseClient::feature($key);if(($body[$key] ?? null)===true&&$module&&!$this->license()->allows($state,$module))throw new RuntimeException('Dieses Modul ist nicht lizenziert.',403);}
            foreach ($allowed as $key) if (is_bool($body[$key] ?? null)) $state['featureSettings'][$key] = $body[$key];
            if (($body['menus'] ?? null)===false && isset($state['menuShare'])) $state['menuShare']['secret']=bin2hex(random_bytes(32));
            $state['navigationOrder'] = $this->normalizeNavigationOrder($body['navigationOrder'] ?? $state['navigationOrder'] ?? []);
            return $this->ok(['data' => $this->license()->features($state),'licensedModules'=>$this->license()->grants($state), 'navigationOrder' => $state['navigationOrder']], true);
        }
        if ($path === '/api/settings/events' && $method === 'GET') return $this->ok(['settings'=>EventEditorSettings::normalize($state['eventEditorSettings'] ?? [])]);
        if ($path === '/api/settings/events' && $method === 'PUT') {
            $current=EventEditorSettings::normalize($state['eventEditorSettings'] ?? []);$patch=is_array($body['fields'] ?? null)?$body['fields']:[];
            $state['eventEditorSettings']=EventEditorSettings::normalize(['fields'=>array_replace($current['fields'],$patch)]);
            return $this->ok(['settings'=>$state['eventEditorSettings']],true);
        }
        if ($path === '/api/settings/public-calendar' && $method === 'GET') {
            return $this->ok(['settings' => PublicEventCalendar::normalizeSettings($state['publicCalendarSettings'] ?? [])]);
        }
        if ($path === '/api/settings/public-calendar' && $method === 'PUT') {
            foreach(['showAdmission'=>'showTime','showEndTime'=>'showTime','showSubtitle'=>'showDescription','showPublicNotes'=>'showDescription'] as $key=>$parent)if(array_key_exists($parent,$body)&&$body[$parent]===false&&!array_key_exists($key,$body))$body[$key]=false;
            $state['publicCalendarSettings'] = PublicEventCalendar::normalizeSettings(array_replace($state['publicCalendarSettings'] ?? [],$body));
            return $this->ok(['settings' => $state['publicCalendarSettings']], true);
        }

        throw new RuntimeException('API-Endpunkt wurde nicht gefunden.', 404);
    }

    private function synchronizeAdvertising(array &$state): array
    {
        if(!$this->license()->allows($state,'advertising'))return ['ran'=>false];
        return AdvertisingService::synchronize($state,
            function(array $body, ?string $id) use (&$state): array { return $this->saveSlide($state,$body,$id); },
            function(array $body, ?string $id) use (&$state): array { return $this->saveRecord($state,'channels',$body,$id); },
            function(array $body, ?string $id) use (&$state): array { return $this->saveRecord($state,'templates',$body,$id); });
    }

    private function crewBrain(): CrewBrainService
    {
        if (!$this->crewBrain) throw new RuntimeException('Der CrewBrain-HTTP-Dienst ist in dieser CMS-Ausgabe nicht verfügbar.', 503);
        return $this->crewBrain;
    }

    private function easyJob(): EasyJobService
    {
        if (!$this->easyJob) throw new RuntimeException('Der easyjob-HTTP-Dienst ist in dieser CMS-Ausgabe nicht verfügbar.', 503);
        return $this->easyJob;
    }

    /** Menu access is independent of broad content-editing permissions. */
    private function menus(array &$state, string $method, string $path, array $body, ?array $sharedSlideIds = null): array
    {
        if (($state['featureSettings']['menus'] ?? true) === false) throw new RuntimeException('Das Speisekarten-Modul ist ausgeschaltet. Die Administration kann es in den Einstellungen wieder aktivieren.',503);
        $id = (string)$this->identity['id'];
        if ($sharedSlideIds === null && (($this->identity['actorType'] ?? '') === 'api_key' || !preg_match('/^(wp|typo3):[1-9][0-9]*$/', $id))) throw new RuntimeException('Eine CMS-Benutzeranmeldung ist erforderlich.',403);
        $admin = $sharedSlideIds === null && ($this->identity['role'] ?? '') === 'admin';
        $access = $sharedSlideIds !== null ? ['enabled'=>true,'slideIds'=>$sharedSlideIds] : ($state['menuAccess'][$id] ?? []);
        $live = array_values(array_filter($this->active($state['slides']),static fn(array $slide): bool => (isset($slide['document']['menu']) || isset($slide['document']['menuPdf']))));
        $allowed = array_values(array_filter($live,static fn(array $slide): bool => $admin || (!empty($access['enabled']) && in_array($slide['id'],$access['slideIds'] ?? [],true))));
        if (str_starts_with($path,'/api/menus/subscriptions')) {
            if (!$admin) throw new RuntimeException('Nur Administratoren dürfen PDF-Abonnements verwalten.',403);
            return ($this->menuSubscriptions ?? new MenuSubscriptions())->handle($state,$method,$path,$body,
                function(array &$target,array $input,?string $slideId): array{return $this->saveSlide($target,$input,$slideId);},
                function(array &$target,array $input,?string $channelId): array{return $this->saveRecord($target,'channels',$input,$channelId);});
        }
        if (preg_match('#^/api/menus/templates(?:/([^/]+))?$#',$path,$templateMatch)) {
            if (!$admin) throw new RuntimeException('Nur Administratoren dürfen Vorlagen bearbeiten.',403);
            $templateId = isset($templateMatch[1]) ? rawurldecode($templateMatch[1]) : null;
            $templates = array_values(array_filter($this->active($state['templates']), static fn(array $item): bool => ($item['document']['menuTemplate'] ?? false) === true));
            if ($templateId) $this->required($templates,$templateId,'Speisekarten-Vorlage');
            if ($method === 'GET' && !$templateId) return $this->ok(['data'=>$templates]);
            if ($method === 'DELETE' && $templateId) {
                $index = $this->index($state['templates'],$templateId); $state['templates'][$index]['status'] = 'archived';
                return $this->ok(['ok'=>true],true);
            }
            if (($method === 'POST' && !$templateId) || ($method === 'PUT' && $templateId)) {
                if (!is_string($body['name'] ?? null) || trim($body['name']) === '' || strlen($body['name']) > 100 || !in_array($body['orientation'] ?? '',['portrait','landscape','auto'],true)) throw new RuntimeException('Name oder Format ist ungültig.',422);
                MenuContent::validateTemplate($body['document'] ?? null);
                $template = $this->saveRecord($state,'templates',['name'=>trim($body['name']),'orientation'=>$body['orientation'],'status'=>'active','description'=>'Speisekarten-Vorlage','document'=>array_replace($body['document'],['menuTemplate'=>true])],$templateId);
                $this->audit($state,'menu.template.saved',$template['id']);
                return [$templateId ? 200 : 201,['template'=>$template],true];
            }
            throw new RuntimeException('Methode nicht erlaubt.',405);
        }
        if ($path === '/api/menus/access') {
            if (!$admin) throw new RuntimeException('Nur Administratoren dürfen Speisekarten-Rechte vergeben.',403);
            if ($method === 'GET') return $this->ok(['data'=>array_map(static fn(array $user): array => ['id'=>$user['id'],'displayName'=>$user['displayName'],'enabled'=>(bool)($state['menuAccess'][$user['id']]['enabled'] ?? false),'slideIds'=>$state['menuAccess'][$user['id']]['slideIds'] ?? []],$this->platformUsers)]);
            if ($method === 'PUT') {
                if (!is_string($body['userId'] ?? null) || !is_bool($body['enabled'] ?? null) || !is_array($body['slideIds'] ?? null) || !in_array($body['userId'],array_column($this->platformUsers,'id'),true)) throw new RuntimeException('Ungültige Benutzerzuweisung.',422);
                foreach ($body['slideIds'] as $slideId) if (!is_string($slideId) || !in_array($slideId,array_column($live,'id'),true)) throw new RuntimeException('Ungültige Kartenzuweisung.',422);
                $state['menuAccess'][$body['userId']] = ['enabled'=>$body['enabled'],'slideIds'=>array_values(array_unique($body['slideIds']))];
                $this->audit($state,'menu.access.updated',$body['userId']);
                return $this->ok(['ok'=>true],true);
            }
        }
        if (!$admin && empty($access['enabled'])) throw new RuntimeException('Das Speisekarten-Recht fehlt. Bitte die Administration kontaktieren.',403);
        if ($path === '/api/menus' && $method === 'GET') return $this->ok(['data'=>$allowed,'admin'=>$admin,'settings'=>MenuContent::settings($state['menuSettings'] ?? []),'templates'=>$admin ? array_values(array_filter($this->active($state['templates']),static fn(array $item): bool => ($item['document']['menuTemplate'] ?? false) === true)) : []]);
        if ($path === '/api/menus/pdf' && $method === 'POST') {
            if (!$admin) throw new RuntimeException('Nur Administratoren dürfen PDF-Speisekarten importieren.',403);
            if (array_diff(array_keys($body),['name','orientation','pdfPage']) || !is_string($body['name'] ?? null) || trim($body['name'])==='' || strlen($body['name'])>100 || !in_array($body['orientation'] ?? '',['portrait','landscape'],true)) throw new RuntimeException('Ungültiger PDF-Import.',422);
            $slide=$this->saveSlide($state,['name'=>trim($body['name']),'orientation'=>$body['orientation'],'type'=>'custom','status'=>'draft','tags'=>['Speisekarte','PDF'],'document'=>MenuContent::pdfDocument($body['pdfPage'] ?? null,$body['orientation'])]);
            return $this->created(['slide'=>$slide]);
        }
        if ($path === '/api/menus' && $method === 'POST') {
            if (!$admin) throw new RuntimeException('Nur Administratoren dürfen Speisekarten anlegen.',403);
            if (!is_string($body['name'] ?? null) || trim($body['name']) === '' || strlen($body['name']) > 100 || !in_array($body['orientation'] ?? '',['portrait','landscape','auto'],true) || !is_array($body['document'] ?? null) || strlen(json_encode($body['document'])) > 80000) throw new RuntimeException('Name, Format oder Vorlage ist ungültig.',422);
            $slide = $this->saveSlide($state,['name'=>trim($body['name']),'orientation'=>$body['orientation'],'type'=>'custom','status'=>'draft','tags'=>['Speisekarte'],'document'=>MenuContent::document($body['document'],MenuContent::validate($body['menu'] ?? null))]);
            return $this->created(['slide'=>$slide]);
        }
        if(preg_match('#^/api/menus/([^/]+)/settings$#',$path,$settingsMatch)){
            if(!$admin)throw new RuntimeException('Nur Administratoren dürfen Name, Layout, Vorlage und Ausrichtung ändern oder Karten löschen.',403);
            $slide=$this->required($allowed,rawurldecode($settingsMatch[1]),'Speisekarte');
            if(($body['version'] ?? null)!==$slide['currentVersion'])throw new RuntimeException('Die Karte wurde zwischenzeitlich geändert. Bitte neu laden.',409);
            if($method==='DELETE'){
                if(array_diff(array_keys($body),['version']))throw new RuntimeException('Ungültige Löschanfrage.',422);
                foreach($state['menuSubscriptions'] ?? [] as $record)if(in_array($slide['id'],$record['slideIds'],true))throw new RuntimeException('Diese Karte gehört zu einem PDF-Abonnement. Bitte zuerst das Abonnement beenden; danach kann die Karte gelöscht werden.',409);
                return $this->trashRecord($state,'slides','slide',$slide['id']);
            }
            if($method!=='PUT')throw new RuntimeException('Methode nicht erlaubt.',405);
            if(array_diff(array_keys($body),['version','name','orientation','designOrientation','layoutDocument']) || !is_string($body['name'] ?? null) || trim($body['name'])==='' || strlen($body['name'])>100 || preg_match('/[\x00-\x1f\x7f]/',$body['name']) || !in_array($body['orientation'] ?? '',['landscape','portrait','auto'],true) || (isset($body['designOrientation']) && !in_array($body['designOrientation'],['landscape','portrait'],true)))throw new RuntimeException('Name oder Ausrichtung ist ungültig.',422);
            $document=$slide['document'];
            if(array_key_exists('layoutDocument',$body)){
                $layout=$body['layoutDocument'];if(!is_array($layout) || strlen(json_encode($layout))>(isset($document['menuPdf'])?2950000:80000))throw new RuntimeException('Ungültiges Speisekarten-Layout.',422);
                if(isset($document['menuPdf'])){
                    $original=null;foreach($document['elements'] as $element)if(!empty($element['menuPdfImage'])){$original=$element;break;}
                    if(!is_array($layout['elements'] ?? null) || !array_filter($layout['elements'],static fn($element):bool=>is_array($element) && ($element['menuPdfImage'] ?? false)===true && ($element['src'] ?? null)===($original['src'] ?? null)))throw new RuntimeException('Das PDF-Bildfeld muss im Layout erhalten bleiben.',422);
                    $document=array_replace($layout,['menuPdf'=>$document['menuPdf']]);
                }else $document=MenuContent::document($layout,MenuContent::validate($document['menu']));
            }
            $document['designOrientation']=$body['orientation']==='auto'?($body['designOrientation'] ?? $document['designOrientation'] ?? 'landscape'):$body['orientation'];
            $updated=$this->saveSlide($state,array_replace($slide,['name'=>trim($body['name']),'orientation'=>$body['orientation'],'document'=>$document]),$slide['id']);
            return $this->ok(['slide'=>$updated],true);
        }
        if (preg_match('#^/api/menus/([^/]+)$#',$path,$match) && $method === 'PUT') {
            $slide = $this->required($allowed,rawurldecode($match[1]),'Zugewiesene Speisekarte');
            if (array_diff(array_keys($body),isset($slide['document']['menuPdf'])?['pdfPage','version']:['menu','version'])) throw new RuntimeException('Nur Inhalte dürfen geändert werden.',422);
            if (($body['version'] ?? null) !== $slide['currentVersion']) throw new RuntimeException('Die Karte wurde zwischenzeitlich geändert. Bitte neu laden und Änderungen vergleichen.',409);
            $slide['document'] = isset($slide['document']['menuPdf']) ? MenuContent::pdfDocument($body['pdfPage'] ?? null,$slide['orientation']==='auto'?($slide['document']['designOrientation'] ?? 'landscape'):$slide['orientation'],$slide['document']) : MenuContent::document($slide['document'],MenuContent::validate($body['menu'] ?? null));
            $updated = $this->saveSlide($state,$slide,$slide['id']);
            $this->audit($state,'menu.content.updated',$slide['id']);
            return $this->ok(['slide'=>$updated],true);
        }
        throw new RuntimeException('Speisekarten-Endpunkt wurde nicht gefunden.',404);
    }

    private function fontCatalog(array $state,?array $content=null): array
    {
        $fonts=$state['fonts'] ?? [];if($content!==null)$fonts=array_values(array_filter($fonts,static fn(array $font):bool=>FontStorage::references($content,$font['id'])));
        return array_map(static fn(array $font):array=>array_intersect_key($font,array_flip(['id','name','format','mime','size'])),$fonts);
    }

    private function fontFile(array $state,string $id): array
    {
        if(!$this->fontStorage)throw new RuntimeException('Die Schriftablage ist nicht verfügbar.',503);
        $font=$this->required($state['fonts'] ?? [],$id,'Schriftart');
        try{$file=$this->fontStorage->file($font);}catch(RuntimeException $error){
            if($this->platform!=='wordpress'||!($this->store instanceof CmsMediaStateStore)||empty($font['assetId']))throw $error;
            $decoded=FontStorage::decode($this->store->registeredFontData($font['assetId']));
            if($decoded['font']['id']!==$id)throw new RuntimeException('Die registrierte Schriftdatei wurde verändert.',409);
            $this->fontStorage->put($decoded['bytes']);$file=$this->fontStorage->file($font);
        }
        $file['font']=array_diff_key($file['font'],['assetId'=>true]);return $file;
    }

    private function canManageCustomerContent():bool{return ($this->identity['canManageCustomerContent']??(in_array($this->identity['role']??'',['admin','editor'],true)&&$this->canControlPlayers()))===true;}
    private function canReadPlayerKeys():bool{return ($this->identity['canManageDisplays']??in_array($this->identity['role']??'',['admin','editor'],true))===true;}
    private function canControlPlayers():bool{return ($this->identity['canControlDisplays']??in_array($this->identity['role']??'',['admin','editor'],true))===true;}
    private function withoutPlayerKeys(array $value):array{foreach($value as $key=>$entry){if($key==='playerKey')unset($value[$key]);elseif(is_array($entry))$value[$key]=$this->withoutPlayerKeys($entry);}return $value;}

    private function assertRolePermission(string $method, string $path): void
    {
        $role = (string)($this->identity['role'] ?? 'viewer');
        if($path==='/api/event-automation'||str_starts_with($path,'/api/event-automation/')){if(in_array($role,['admin','editor'],true)&&$this->canControlPlayers())return;throw new RuntimeException('Für Veranstaltungsabläufe fehlen Verwaltungsrechte.',403);}
        if ($role === 'admin') return;
        if($method==='POST'&&preg_match('#^/api/displays/[^/]+/monitoring$#',$path)&&$this->canControlPlayers())return;
        if(str_starts_with($path,'/api/history/')){if($role==='editor'||$role==='designer'&&preg_match('#^/api/history/(slide|event)(?:/|$)#',$path))return;throw new RuntimeException('Für diesen Verlauf fehlen die erforderlichen Rechte.',403);}
        if(str_starts_with($path,'/api/reports/')){if($role==='editor')return;throw new RuntimeException('Für Berichte fehlen die erforderlichen Rechte.',403);}
        if ($path === '/api/settings/features' && $method === 'GET') return;

        $adminOnly = ['/api/users', '/api/api-users', '/api/audit-logs', '/api/content-transfer', '/api/integrations', '/api/settings', '/api/updates', '/api/v1'];
        if ($this->pathStartsWithAny($path, $adminOnly)) {
            throw new RuntimeException('Für diese Funktion fehlen die erforderlichen Rechte.', 403);
        }

        if ($role === 'editor') {if($method==='DELETE'&&(str_ends_with($path,'/permanent')||str_starts_with($path,'/api/trash/')))throw new RuntimeException('Endgültiges Löschen ist Administratoren vorbehalten.',403);return;}
        if ($role === 'designer') { if(!ContentAccess::allowed($method,$path))ContentAccess::fail();return; }

        $viewerBlocked = ['/api/content-packages', '/api/media', '/api/presets', '/api/preset-triggers', '/api/warning-templates', '/api/warnings', '/api/operations', '/api/dwd', '/api/trash'];
        if ($this->pathStartsWithAny($path, $viewerBlocked)) {
            throw new RuntimeException('Für diese Funktion fehlen die erforderlichen Rechte.', 403);
        }
        if (in_array($method, ['GET', 'HEAD'], true)) return;
        // Match the standalone API: viewers remain read-only outside the separately granted menu editor.
        throw new RuntimeException('Betrachter dürfen keine Daten ändern.', 403);
    }

    /** @param array<int,string> $prefixes */
    private function pathStartsWithAny(string $path, array $prefixes): bool
    {
        foreach ($prefixes as $prefix) {
            if ($path === $prefix || str_starts_with($path, $prefix . '/')) return true;
        }
        return false;
    }

    /** @param array<string,mixed> $state @return array<string,mixed> */
    private function eventUsage(array $state, string $eventId): array
    {
        $this->required($state['events'], $eventId, 'Veranstaltung');
        $slides = array_values(array_map(
            static fn(array $slide): array => ['id' => $slide['id'], 'name' => $slide['name'] ?? 'Slide'],
            array_filter($this->active($state['slides']), static fn(array $slide): bool => ($slide['eventId'] ?? '') === $eventId)
        ));
        $channels = array_values(array_map(
            static fn(array $channel): array => ['id' => $channel['id'], 'name' => $channel['name'] ?? 'Kanal'],
            array_filter($this->active($state['channels']), static fn(array $channel): bool => ($channel['eventId'] ?? '') === $eventId)
        ));
        return ['slides' => $slides, 'channels' => $channels];
    }

    /** @param array<string,mixed> $state */
    private function eventReuseSnapshot(array $state,string $eventId,mixed $override=null):array
    {
        $event=$this->required($state['events'],$eventId,'Veranstaltung');if(!empty($event['deletedAt']))throw new RuntimeException('Veranstaltung wurde nicht gefunden.',404);
        $snapshot=['input'=>EventReuse::input($event),'schedule'=>EventReuse::schedule(array_values(array_filter($state['eventSchedules'],static fn(array $entry):bool=>($entry['eventId'] ?? '')===$eventId&&($entry['active'] ?? true)!==false)))];
        if($override===null)return $snapshot;$input=EventReuse::input($override);$shifted=EventReuse::copy($snapshot,['date'=>$input['date'] ?? null]);return ['input'=>$input,'schedule'=>$shifted['schedule']];
    }
    private function eventReuseCreate(array &$state,array $snapshot,array $options):array
    {
        $prepared=EventReuse::copy($snapshot,$options);$event=$this->saveRecord($state,'events',$prepared['input']);$this->ensureEventChannel($state,$event);foreach($prepared['schedule'] as $entry)$this->eventSchedule($state,'POST',$event['id'],null,$entry);return $this->created(['event'=>$event]);
    }

    private function eventSchedule(array &$state,string $method,string $eventId,?string $id,array $body): array
    {
        $event=$this->required($state['events'],$eventId,'Veranstaltung');
        if(!empty($event['deletedAt']))throw new RuntimeException('Veranstaltung wurde nicht gefunden.',404);
        if($method==='GET'&&$id===null){
            $entries=array_values(array_filter($state['eventSchedules'],static function(array $entry)use($eventId,$body):bool{
                if(($entry['eventId'] ?? '')!==$eventId||($entry['active'] ?? true)===false)return false;
                foreach(['roomId','roomName','category','type','source'] as $key)if(!empty($body[$key])&&($entry[$key] ?? '')!==$body[$key])return false;
                return empty($body['date'])||str_starts_with($entry['startAt'] ?? '',(string)$body['date']);
            }));
            usort($entries,static fn(array $a,array $b):int=>strcmp($a['startAt'],$b['startAt']) ?: (($a['sortOrder'] ?? 0)<=>($b['sortOrder'] ?? 0)));
            return $this->ok(['data'=>$entries]);
        }
        $current=$id!==null?$this->required($state['eventSchedules'],$id,'Ablaufpunkt'):null;
        if($current&&($current['eventId'] ?? '')!==$eventId)throw new RuntimeException('Ablaufpunkt wurde nicht gefunden.',404);
        if($current&&($current['source'] ?? 'manual')!=='manual')throw new RuntimeException('Importierte Ablaufpunkte sind schreibgeschützt.',403);
        if($method==='DELETE'&&$current){$this->purge($state['eventSchedules'],$id);$this->audit($state,'event.schedule.deleted',$id);return $this->ok(['ok'=>true],true);}
        if(!(($method==='POST'&&$id===null)||($method==='PATCH'&&$current)))throw new RuntimeException('Methode nicht erlaubt.',405);
        $input=array_replace($current ?? [],$body);$type=$input['type'] ?? '';
        if(!is_string($type)||trim($type)===''||strlen($type)>1200)throw new RuntimeException('Die Ablaufart fehlt oder ist ungültig.',422);
        $normalized=EasyJobService::normalizedRoomUseType($type);$rule=$this->first(EasyJobService::roomUseTypes($state['easyjob']['roomUseTypeRules'] ?? []),static fn(array $item):bool=>$item['normalizedType']===$normalized);
        $category=$input['category'] ?? $rule['category'] ?? 'other';
        EasyJobService::roomUseType(['originalLabel'=>$type,'category'=>$category]);
        $date=static function(mixed $value,bool $required):?string{
            if(!$required&&($value===null||$value===''))return null;
            if(!is_string($value)||!preg_match('/^\d{4}-\d{2}-\d{2}T.+(?:Z|[+-]\d{2}:\d{2})$/',$value)||strtotime($value)===false)throw new RuntimeException('Ein gültiger ISO-8601-Zeitpunkt mit Zeitzone ist erforderlich.',422);
            return gmdate('Y-m-d\TH:i:s\Z',strtotime($value));
        };
        $start=$date($input['startAt'] ?? null,true);$end=$date($input['endAt'] ?? null,false);
        if($end!==null&&$end<$start)throw new RuntimeException('Das Ende liegt vor dem Beginn.',422);
        $priority=$input['sortOrder'] ?? 0;if(!is_int($priority)||abs($priority)>100000)throw new RuntimeException('Sortierpriorität ist ungültig.',422);
        $entry=array_replace($current ?? [],['id'=>$id ?? $this->uuid(),'eventId'=>$eventId,'type'=>trim($type),'normalizedType'=>$normalized,'category'=>$category,'startAt'=>$start,'endAt'=>$end,'source'=>'manual','active'=>true,'isApproximate'=>(bool)($input['isApproximate'] ?? $rule['isApproximate'] ?? false),'sortOrder'=>$priority,'createdAt'=>$current['createdAt'] ?? $this->now(),'updatedAt'=>$this->now()]);
        foreach(['caption','roomId','externalRoomId','roomName','roomConfiguration'] as $key){$value=$input[$key] ?? null;if($value!==null&&(!is_string($value)||strlen($value)>2000))throw new RuntimeException('Ablaufangabe ist ungültig.',422);$entry[$key]=$value!==null&&trim($value)!==''?trim($value):null;}
        $entry['displayCaption']=$entry['caption'] ?: $entry['type'];
        if($current)$state['eventSchedules'][$this->index($state['eventSchedules'],$id)]=$entry;else $state['eventSchedules'][]=$entry;
        $this->audit($state,$current?'event.schedule.updated':'event.schedule.created',$entry['id']);
        return [$current?200:201,['entry'=>$entry],true];
    }

    private function purgeEvent(array &$state, string $eventId): void
    {
        $index=$this->index($state['events'],$eventId);if($index===null)throw new RuntimeException('Veranstaltung wurde nicht gefunden.',404);
        $state['events'][$index]=EventLifecycle::tombstone($state['events'][$index],$this->now());EventLifecycle::synchronize($state);
        $this->audit($state,'event.purged',$eventId);
    }

    private function eventEditorBody(array $body):array
    {
        return array_intersect_key($body,array_flip(['title','subtitle','description','organizer','eventType','date','setupStart','admissionStart','eventStart','breakStart','breakEnd','eventEnd','venue','room','status','publicNotes','internalNotes','imageUrl','imageEdit','advertisingVideo','ticketUrl','ticketLinks','remainingTickets','boxOfficeAvailable','boxOfficeOpenAt']));
    }

    /**
     * @param array<string,mixed> $state
     * @param array<string,mixed> $mapped
     * @return array{event:array<string,mixed>,action:string}
     */
    private function upsertCrewBrainEvent(array &$state, array $mapped): array
    {
        $existing = $this->first($state['events'], static fn(array $event): bool =>
            ($event['sourceId'] ?? '') === 'source-crewbrain'
            && (string)($event['externalId'] ?? '') === (string)($mapped['externalId'] ?? '')
            && (string)($event['externalObjectType'] ?? '') === (string)($mapped['externalObjectType'] ?? '')
        );
        if (!$existing) {
            $event = $this->saveRecord($state, 'events', $mapped + ['status' => 'draft', 'lockedFields' => []]);
            $this->ensureEventChannel($state, $event);
            return ['event' => $event, 'action' => 'created'];
        }
        if(EventLifecycle::effective($existing)==='removed')return ['event'=>$existing,'eventId'=>$existing['id'],'action'=>'unchanged'];
        if (($existing['importHash'] ?? '') === ($mapped['importHash'] ?? '')) {
            return ['event' => $existing, 'action' => 'unchanged'];
        }
        $locked = is_array($existing['lockedFields'] ?? null) ? $existing['lockedFields'] : [];
        $updated = $existing;
        foreach ($mapped as $key => $value) {
            if (!in_array($key, $locked, true)) $updated[$key] = $value;
        }
        $updated['lockedFields'] = $locked;
        unset($updated['deletedAt']);
        $event = $this->saveRecord($state, 'events', $updated, (string)$existing['id']);
        $this->ensureEventChannel($state, $event);
        return ['event' => $event, 'action' => 'updated'];
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $mapped @return array{event:array<string,mixed>,action:string} */
    private function upsertExternalEvent(array &$state, array $mapped): array
    {
        $existing = $this->first($state['events'], static fn(array $event): bool => ($event['sourceId'] ?? '') === ($mapped['sourceId'] ?? '') && (string)($event['externalId'] ?? '') === (string)($mapped['externalId'] ?? ''));
        if (!$existing) {
            $event = $this->saveRecord($state, 'events', $mapped + ['status' => 'draft', 'lockedFields' => []]);
            $this->ensureEventChannel($state, $event);
            return ['event' => $event, 'eventId' => $event['id'], 'action' => 'created'];
        }
        if(EventLifecycle::effective($existing)==='removed')return ['event'=>$existing,'eventId'=>$existing['id'],'action'=>'unchanged'];
        if (($existing['importHash'] ?? '') === ($mapped['importHash'] ?? '')) return ['event' => $existing, 'eventId' => $existing['id'], 'action' => 'unchanged'];
        $locked = is_array($existing['lockedFields'] ?? null) ? $existing['lockedFields'] : [];
        $updated = $existing;
        foreach ($mapped as $key => $value) if ($key!=='status' && !in_array($key, $locked, true)) $updated[$key] = $value;
        $updated['lockedFields'] = $locked;
        $updated['syncStatus'] = $locked ? 'manually_modified' : ($mapped['syncStatus'] ?? 'synced');
        if (isset($mapped['importHash'])) $updated['importHash'] = $mapped['importHash'];
        $event = $this->saveRecord($state, 'events', $updated, (string)$existing['id']);
        $this->ensureEventChannel($state, $event);
        return ['event' => $event, 'eventId' => $event['id'], 'action' => 'updated'];
    }

    /** @param array<string,mixed> $source */
    private function easyJobAttachmentText(array $source, array $paths): string
    {
        foreach ($paths as $path) {
            $value = $source;
            foreach (explode('.', $path) as $key) $value = is_array($value) ? ($value[$key] ?? null) : null;
            if (is_scalar($value) && trim((string)$value) !== '') return trim((string)$value);
        }
        return '';
    }

    /** @param array<string,mixed> $attachment */
    private function easyJobDocumentType(array $attachment): string
    {
        foreach (['DocumentType','ShortCutType','AttachmentType','Type'] as $key) {
            $value = $attachment[$key] ?? null;
            if (is_string($value)) return trim($value);
            if (is_array($value)) {
                $caption = $this->easyJobAttachmentText($value, ['Caption','CaptionNew','Name','Description','Value']);
                if ($caption !== '') return $caption;
            }
        }
        return $this->easyJobAttachmentText($attachment, ['DocumentTypeCaption','DocumentTypeName','TypeCaption','TypeName']);
    }

    /** @param array<string,mixed> $state */
    private function ensureEasyJobMediaFolder(array &$state, string $name, ?string $parentId = null): string
    {
        foreach ($state['mediaFolders'] as $folder) if (($folder['name'] ?? '') === $name && (string)($folder['parentId'] ?? '') === (string)($parentId ?? '')) return (string)$folder['id'];
        return (string)$this->saveRecord($state, 'mediaFolders', ['name' => $name, 'parentId' => $parentId])['id'];
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $event @return array<string,mixed> */
    private function syncEasyJobAdvertisingImages(array &$state, array $event, string $projectId, ?string $jobId = null): array
    {
        if(EventLifecycle::effective($event)==='removed')return ['source'=>'none','found'=>0,'imported'=>0,'updated'=>0,'removed'=>0,'warnings'=>[]];
        $service = $this->easyJob();
        $config = $state['easyjob']['config'];
        $warnings = [];
        $source = 'none';
        $attachments = [];
        if ($jobId) {
            try { $attachments = $service->shortcuts($config, $jobId, 'job'); }
            catch (Throwable $error) { $warnings[] = 'Job-Anhänge konnten nicht gelesen werden: ' . $error->getMessage(); }
            $attachments = array_values(array_filter($attachments, fn(array $item): bool => strtolower(trim($this->easyJobDocumentType($item))) === 'veranstaltungsbild'));
            if ($attachments) $source = 'job';
        }
        if (!$attachments) {
            try { $attachments = $service->shortcuts($config, $projectId, 'project'); }
            catch (Throwable $error) { return ['source' => 'none', 'found' => 0, 'imported' => 0, 'updated' => 0, 'removed' => 0, 'warnings' => array_merge($warnings, ['Projektanhänge konnten nicht gelesen werden: ' . $error->getMessage()])]; }
            $attachments = array_values(array_filter($attachments, fn(array $item): bool => strtolower(trim($this->easyJobDocumentType($item))) === 'veranstaltungsbild'));
            if ($attachments) $source = 'project';
        }
        usort($attachments, fn(array $left, array $right): int => strcmp((string)($right['ChangedDate'] ?? $right['UpdatedAt'] ?? ''), (string)($left['ChangedDate'] ?? $left['UpdatedAt'] ?? '')));
        $existing = array_values(array_filter($state['mediaAssets'], fn(array $asset): bool => ($asset['metadata']['source'] ?? '') === 'easyjob' && ($asset['metadata']['easyjobDocumentType'] ?? '') === 'Veranstaltungsbild' && ($asset['metadata']['easyjobEventId'] ?? '') === ($event['id'] ?? '')));
        if (!$attachments) {
            foreach ($existing as $asset) {
                $index = $this->index($state['mediaAssets'], (string)$asset['id']);
                if ($index !== null) $state['mediaAssets'][$index]['deletedAt'] = $this->now();
            }
            if (!in_array('imageUrl', $event['lockedFields'] ?? [], true) && $existing) {
                $event['imageUrl'] = null;
                $this->saveRecord($state, 'events', $event, (string)$event['id']);
            }
            return ['source' => $source, 'found' => 0, 'imported' => 0, 'updated' => 0, 'removed' => count($existing), 'warnings' => $warnings];
        }
        $date = preg_match('/^(\d{4})(\d{2})(\d{2})/', (string)($event['date'] ?? ''), $dateMatch) ? [$dateMatch[1],$dateMatch[2],$dateMatch[3]] : [date('Y'),date('m'),date('d')];
        $rootId = $this->ensureEasyJobMediaFolder($state, 'Werbung');
        $yearId = $this->ensureEasyJobMediaFolder($state, $date[0], $rootId);
        $monthId = $this->ensureEasyJobMediaFolder($state, $date[1], $yearId);
        $safeTitle = trim(preg_replace('/[\x00-\x1F\x7F\/\\:*?"<>|]+/u', ' ', (string)($event['title'] ?? $event['id'])) ?: (string)$event['id']);
        $shortTitle = function_exists('mb_substr') ? mb_substr($safeTitle, 0, 140, 'UTF-8') : substr($safeTitle, 0, 140);
        $folderId = $this->ensureEasyJobMediaFolder($state, $date[0] . '-' . $date[1] . '-' . $date[2] . ' – ' . $shortTitle, $monthId);
        $imported = 0; $updated = 0; $activeIds = []; $imageUrl = null; $available = $existing;
        foreach ($attachments as $attachment) {
            $documentId = $this->easyJobAttachmentText($attachment, ['IdShortCut','IdShortcut','IdDocument','ID','Id','id']);
            if ($documentId === '') { $warnings[] = 'easyjob-Anhang ohne Dokument-ID wurde übersprungen.'; continue; }
            $name = $this->easyJobAttachmentText($attachment, ['FileName','Filename','OriginalFileName','Name','Caption','Description']) ?: 'Veranstaltungsbild-' . $documentId;
            try { $download = $service->downloadShortcut($config, $documentId, $this->easyJobAttachmentText($attachment, ['AccessKey','AccessKeyString','DownloadKey','access_key'])); }
            catch (Throwable $error) { $warnings[] = $name . ': ' . $error->getMessage(); continue; }
            $mime = $download['contentType'];
            $head = bin2hex(substr($download['body'], 0, 12));
            if (str_starts_with($head, 'ffd8ff')) $mime = 'image/jpeg';
            elseif (str_starts_with($head, '89504e470d0a1a0a')) $mime = 'image/png';
            elseif (str_starts_with(substr($download['body'], 0, 6), 'GIF8')) $mime = 'image/gif';
            elseif (substr($download['body'], 0, 4) === 'RIFF' && substr($download['body'], 8, 4) === 'WEBP') $mime = 'image/webp';
            if (!in_array($mime, ['image/jpeg','image/png','image/gif','image/webp','image/avif'], true)) { $warnings[] = $name . ' ist kein unterstütztes Bildformat.'; continue; }
            $hash = hash('sha256', $download['body']);
            $current = $this->first($available, fn(array $asset): bool => ($asset['metadata']['easyjobDocumentId'] ?? '') === $documentId);
            if ($current) $available = array_values(array_filter($available, fn(array $asset): bool => ($asset['id'] ?? '') !== ($current['id'] ?? '')));
            else $current = array_shift($available);
            $src = 'data:' . $mime . ';base64,' . base64_encode($download['body']);
            $metadata = ['source' => 'easyjob','easyjobDocumentType' => 'Veranstaltungsbild','easyjobDocumentId' => $documentId,'easyjobObjectType' => $source,'easyjobObjectId' => $source === 'job' ? $jobId : $projectId,'easyjobProjectId' => $projectId,'easyjobJobId' => $jobId,'easyjobEventId' => $event['id'],'contentHash' => $hash,'contentType' => $mime,'size' => strlen($download['body'])];
            $asset = $this->saveRecord($state, 'mediaAssets', ['name' => $download['fileName'] ?: $name,'folderId' => $folderId,'type' => 'image','src' => $src,'metadata' => $metadata,'deletedAt' => null], $current['id'] ?? null);
            if ($current) $updated++; else $imported++;
            $activeIds[] = $asset['id'];
            $imageUrl ??= $src;
        }
        $removed = 0;
        foreach ($existing as $asset) if (!in_array($asset['id'], $activeIds, true)) { $index = $this->index($state['mediaAssets'], (string)$asset['id']); if ($index !== null) { $state['mediaAssets'][$index]['deletedAt'] = $this->now(); $removed++; } }
        if ($imageUrl && !in_array('imageUrl', $event['lockedFields'] ?? [], true)) { $event['imageUrl'] = $imageUrl; $this->saveRecord($state, 'events', $event, (string)$event['id']); }
        return ['source' => $source, 'found' => count($attachments), 'imported' => $imported, 'updated' => $updated, 'removed' => $removed, 'imageUrl' => $imageUrl, 'warnings' => $warnings];
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $event */
    private function ensureEventChannel(array &$state, array $event): void
    {
        if ($this->first($state['channels'], fn(array $channel): bool => ($channel['eventId'] ?? '') === ($event['id'] ?? ''))) return;
        $this->saveRecord($state, 'channels', ['name' => (string)($event['title'] ?? 'Veranstaltung'), 'description' => 'Automatisch für die Veranstaltung angelegt', 'eventId' => $event['id'], 'items' => [], 'repeatEnabled' => true, 'status' => 'draft']);
    }

    /** @param array<string,mixed> $state @param array<int,string> $ids @return array<int,array<string,mixed>> */
    private function importCrewBrainIds(array &$state, array $ids): array
    {
        $service = $this->crewBrain();
        $config = $state['crewbrain']['config'];
        $mapping = $state['crewbrain']['mapping'];
        $results = [];
        foreach ($ids as $id) {
            try {
                $source = $service->event($config, $id);
                $mapped = $service->mapEvent($source, $mapping);
                $exclusion = $service->titleExclusion($source, (string)$mapped['title'], $this->titleExclusions($state));
                if ($exclusion) {
                    $results[] = ['crewbrainId' => $id, 'action' => 'excluded', 'reason' => $exclusion];
                    continue;
                }
                $result = $this->upsertCrewBrainEvent($state, $mapped);
                $results[] = ['crewbrainId' => $id, 'eventId' => $result['event']['id'], 'action' => $result['action']];
            } catch (Throwable $error) {
                $results[] = ['crewbrainId' => $id, 'action' => 'error', 'reason' => $error->getMessage() ?: 'Import fehlgeschlagen.'];
            }
        }
        return $results;
    }

    /** @param array<string,mixed> $state @return array<string,mixed> */
    private function runAutomaticCrewBrainImport(array &$state): array
    {
        if(!$this->license()->allows($state,'integrations','crewbrain'))return ['ran'=>false,'reason'=>'license'];
        if (!$this->crewBrain) return ['ran' => false, 'reason' => 'service_unavailable'];
        if (($state['activeEventSource'] ?? null) !== 'crewbrain') return ['ran' => false, 'reason' => 'source_inactive'];
        $config = $state['crewbrain']['config'];
        if (empty($config['syncEnabled']) || empty($config['encryptedCredential'])) return ['ran' => false, 'reason' => 'disabled'];
        $now = new \DateTimeImmutable('now');
        [$hour, $minute] = array_map('intval', explode(':', (string)($config['autoImportTime'] ?? '03:00')));
        $scheduled = $now->setTime($hour, $minute);
        if ($now < $scheduled) return ['ran' => false, 'reason' => 'not_due'];
        if (!empty($config['lastSyncAt']) && substr((string)$config['lastSyncAt'], 0, 10) === $now->format('Y-m-d')) {
            return ['ran' => false, 'reason' => 'already_ran'];
        }
        $summary = ['ran' => true, 'examined' => 0, 'created' => 0, 'updated' => 0, 'unchanged' => 0, 'excluded' => 0, 'errors' => 0];
        $details = [];
        try {
            $service = $this->crewBrain();
            $offset = 0;
            $limit = min(max((int)($config['pageSize'] ?? 100), 1), 100);
            $from = $now->modify('-' . (int)($config['lookbackDays'] ?? 30) . ' days')->setTime(0, 0)->format('c');
            $until = $now->modify('+' . (int)($config['lookaheadDays'] ?? 365) . ' days')->setTime(23, 59, 59)->format('c');
            while ($offset < 10_000) {
                $page = $service->listEvents($config, ['from' => $from, 'until' => $until, 'limit' => $limit, 'offset' => $offset]);
                foreach ($page['data'] as $source) {
                    $summary['examined']++;
                    try {
                        $mapped = $service->mapEvent($source, $state['crewbrain']['mapping']);
                        if ($service->titleExclusion($source, (string)$mapped['title'], $this->titleExclusions($state))) {
                            $summary['excluded']++;
                            continue;
                        }
                        $result = $this->upsertCrewBrainEvent($state, $mapped);
                        $summary[$result['action']]++;
                    } catch (Throwable $error) {
                        $summary['errors']++;
                        if (count($details) < 100) $details[] = ['crewbrainId' => $source['ID'] ?? null, 'error' => $error->getMessage()];
                    }
                }
                $offset += max((int)($page['limit'] ?? $limit), 1);
                if ($offset >= (int)($page['totalItems'] ?? 0)) break;
            }
            $config['lastSyncAt'] = $this->now();
            $config['nextSyncAt'] = $scheduled->modify('+1 day')->format('c');
            $config['lastError'] = $summary['errors'] ? 'Einzelne CrewBrain-Veranstaltungen konnten nicht importiert werden.' : null;
        } catch (Throwable $error) {
            $summary['errors']++;
            $details[] = ['error' => $error->getMessage()];
            $config['lastSyncAt'] = $this->now();
            $config['nextSyncAt'] = $scheduled->modify('+1 day')->format('c');
            $config['lastError'] = $error->getMessage();
        }
        $state['crewbrain']['config'] = $config;
        $state['crewbrain']['syncLogs'][] = ['id' => $this->uuid(), 'createdAt' => $this->now(), 'summary' => $summary, 'details' => $details];
        $state['crewbrain']['syncLogs'] = array_slice($state['crewbrain']['syncLogs'], -100);
        $this->audit($state, 'crewbrain.events.auto_imported', (string)($config['id'] ?? 'crewbrain'));
        return $summary + ['details' => $details];
    }

    /** @param array<string,mixed> $state @return array<string,mixed> */
    private function runAutomaticEasyJobImport(array &$state): array
    {
        if(!$this->license()->allows($state,'integrations','easyjob'))return ['ran'=>false,'reason'=>'license'];
        if (!$this->easyJob) return ['ran' => false, 'reason' => 'service_unavailable'];
        if (($state['activeEventSource'] ?? null) !== 'easyjob') return ['ran' => false, 'reason' => 'source_inactive'];
        $config = $state['easyjob']['config'];
        if (empty($config['syncEnabled']) || empty($config['encryptedCredentials'])) return ['ran' => false, 'reason' => 'disabled'];
        $now = new \DateTimeImmutable('now');
        [$hour, $minute] = array_map('intval', explode(':', (string)($config['autoImportTime'] ?? '03:00')));
        $scheduled = $now->setTime($hour, $minute);
        if ($now < $scheduled) return ['ran' => false, 'reason' => 'not_due'];
        if (!empty($config['lastSyncAt']) && substr((string)$config['lastSyncAt'], 0, 10) === $now->format('Y-m-d')) return ['ran' => false, 'reason' => 'already_ran'];
        $summary = ['ran' => true, 'examined' => 0, 'created' => 0, 'updated' => 0, 'unchanged' => 0, 'excluded' => 0, 'errors' => 0, 'imagesImported' => 0, 'imagesUpdated' => 0, 'imageWarnings' => 0];
        $details = [];
        try {
            $service = $this->easyJob();
            $projects = $service->projects($config, [
                'style' => 'Compact',
                'startdate' => $now->modify('-' . (int)($config['lookbackDays'] ?? 30) . ' days')->setTime(0, 0)->format('c'),
                'enddate' => $now->modify('+' . (int)($config['lookaheadDays'] ?? 365) . ' days')->setTime(23, 59, 59)->format('c'),
            ]);
            foreach (array_slice($projects, 0, 10000) as $listedProject) {
                $projectId = (string)($listedProject['IdProject'] ?? $listedProject['ID'] ?? $listedProject['Id'] ?? '');
                if ($projectId === '') { $summary['errors']++; continue; }
                $summary['examined']++;
                try {
                    $project = $service->project($config, $projectId);
                    if (($config['importMode'] ?? '') !== 'jobs') {
                        $mapped = $service->mapEvent($project, null, $state['easyjob']['mapping']);
                        if ($this->matchingTitleExclusion((string)$mapped['title'], $this->titleExclusions($state))) $summary['excluded']++;
                        else { $result = $this->upsertExternalEvent($state, $mapped); $summary[$result['action']]++; $images = $this->syncEasyJobAdvertisingImages($state, $result['event'], $projectId); $summary['imagesImported'] += $images['imported']; $summary['imagesUpdated'] += $images['updated']; $summary['imageWarnings'] += count($images['warnings']); }
                    }
                    if (($config['importMode'] ?? '') !== 'projects') foreach (($project['Jobs'] ?? []) as $listedJob) {
                        if (!is_array($listedJob)) continue;
                        $jobId = (string)($listedJob['IdJob'] ?? $listedJob['ID'] ?? $listedJob['Id'] ?? '');
                        if ($jobId === '') continue;
                        $mapped = $service->mapEvent($project, $service->job($config, $jobId), $state['easyjob']['mapping']);
                        if ($this->matchingTitleExclusion((string)$mapped['title'], $this->titleExclusions($state))) $summary['excluded']++;
                        else { $result = $this->upsertExternalEvent($state, $mapped); $summary[$result['action']]++; $images = $this->syncEasyJobAdvertisingImages($state, $result['event'], $projectId, $jobId); $summary['imagesImported'] += $images['imported']; $summary['imagesUpdated'] += $images['updated']; $summary['imageWarnings'] += count($images['warnings']); }
                    }
                } catch (Throwable $error) {
                    $summary['errors']++;
                    if (count($details) < 100) $details[] = ['projectId' => $projectId, 'error' => $error->getMessage()];
                }
            }
            $config['lastSyncAt'] = $this->now();
            $config['lastError'] = $summary['errors'] ? 'Einzelne easyjob-Datensätze konnten nicht importiert werden.' : null;
        } catch (Throwable $error) {
            $summary['errors']++;
            $details[] = ['error' => $error->getMessage()];
            $config['lastSyncAt'] = $this->now();
            $config['lastError'] = $error->getMessage();
        }
        $state['easyjob']['config'] = $config;
        $state['easyjob']['syncLogs'][] = ['id' => $this->uuid(), 'createdAt' => $this->now(), 'summary' => $summary, 'details' => $details];
        $state['easyjob']['syncLogs'] = array_slice($state['easyjob']['syncLogs'], -100);
        $this->audit($state, 'easyjob.events.auto_imported', (string)($config['id'] ?? 'easyjob'));
        return $summary + ['details' => $details];
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function externalApi(array &$state, string $method, string $path, array $body): array
    {
        if ($path === '/api/v1' && $method === 'GET') {
            return $this->ok(['name' => 'Kiosky External Control API', 'version' => '1.0.0', 'documentation' => 'docs/external-api.md', 'openapi' => 'docs/openapi.yaml']);
        }
        if ($path === '/api/v1/schedules' && $method === 'GET') return $this->ok(['data'=>$state['schedules']]);
        $scheduleMatch=[];
        if (($path === '/api/v1/schedules' && $method === 'POST') || (preg_match('#^/api/v1/schedules/([^/]+)$#',$path,$scheduleMatch) && in_array($method,['GET','PUT','DELETE'],true))) {
            $id=isset($scheduleMatch[1])?rawurldecode($scheduleMatch[1]):null;
            $current=$id?$this->required($state['schedules'],$id,'Zeitzuweisung'):null;
            if($method==='GET')return $this->ok(['entry'=>$current]);
            if($method==='DELETE'){
                $state['schedules']=array_values(array_filter($state['schedules'],static fn(array $entry):bool=>$entry['id']!==$id));
                $this->audit($state,'external.schedule.deleted',$id);return $this->ok(['ok'=>true],true);
            }
            $input=ExternalSchedule::input($body);
            $this->required($this->active($state[$input['targetType']==='display'?'displays':'groups']),$input['targetId'],'Ziel');
            $selected=$this->required($this->active($state[$input['contentType']==='slide'?'slides':'channels']),$input['contentId'],'Inhalt');
            if(($selected['status'] ?? '')==='archived')throw new RuntimeException('Inhalt ist archiviert.',422);
            $this->audit($state,$id?'external.schedule.updated':'external.schedule.created',$id ?? $input['targetId']);
            if($id)return $this->ok(['entry'=>$this->saveRecord($state,'schedules',array_replace($current,$input),$id)],true);
            return $this->collectionRoute($state,'POST','schedules','entry',$input);
        }
        if(preg_match('#^/api/v1/displays/([^/]+)/commands$#',$path,$match)&&$method==='POST'){
            $id=rawurldecode($match[1]);$this->required($this->active($state['displays']),$id,'Display');
            if(!in_array($body['command'] ?? '',['reload','identify','fullscreen','sync'],true))throw new RuntimeException('Unbekannter Player-Befehl.',422);
            $command=$this->record(['displayId'=>$id,'command'=>$body['command'],'status'=>'pending']);
            $state['commands'][]=$command;
            $this->audit($state,'external.display.command.queued',$id);
            return $this->created(['command'=>$command]);
        }
        $collections = [
            '/api/v1/displays' => 'displays',
            '/api/v1/display-groups' => 'groups',
            '/api/v1/matrix-displays' => 'matrices',
            '/api/v1/locations' => 'locations',
            '/api/v1/slides' => 'slides',
            '/api/v1/channels' => 'channels',
            '/api/v1/presets' => 'presets',
        ];
        if ($method === 'GET' && isset($collections[$path])) return $this->ok(['data' => $this->listCollection($state, $collections[$path])]);

        if (preg_match('#^/api/v1/channels/([^/]+)/slides$#', $path, $match) && $method === 'PUT') {
            $id = rawurldecode($match[1]);
            $channel = $this->required($state['channels'], $id, 'Kanal');
            $items = is_array($body['items'] ?? null) ? $body['items'] : [];
            if (count($items) > 200) throw new RuntimeException('Ein Kanal darf höchstens 200 Slides enthalten.');
            $mapped = [];
            foreach ($items as $item) {
                if (!is_array($item)) throw new RuntimeException('Playlist-Eintrag ist ungültig.');
                $slideId = trim((string)($item['slideId'] ?? ''));
                $this->required($state['slides'], $slideId, 'Slide');
                $duration = (int)($item['durationSeconds'] ?? 12);
                $transition = (string)($item['transition'] ?? 'inherit');
                if ($duration < 3 || $duration > 600) throw new RuntimeException('durationSeconds muss zwischen 3 und 600 liegen.');
                if (!in_array($transition, ['inherit', 'fade', 'slide', 'zoom', 'none'], true)) throw new RuntimeException('transition ist ungültig.');
                $mapped[] = ['slideId' => $slideId, 'durationSeconds' => $duration, 'transition' => $transition];
            }
            return $this->ok(['channel' => $this->saveRecord($state, 'channels', array_replace($channel, ['items' => $mapped]), $id)], true);
        }
        if ($path === '/api/v1/assignments' && $method === 'GET') {
            $at = !empty($body['activeAt']) ? strtotime($this->externalDate($body['activeAt'],'activeAt')) : null;
            $data = array_values(array_filter($state['assignments'], static fn(array $item): bool =>
                (empty($body['targetType']) || $item['target']['type'] === $body['targetType'])
                && (empty($body['targetId']) || $item['target']['id'] === $body['targetId'])
                && ($at === null || ((empty($item['startsAt']) || strtotime($item['startsAt']) <= $at) && (empty($item['expiresAt']) || strtotime($item['expiresAt']) > $at)))
            ));
            return $this->ok(['data'=>$data]);
        }
        if ($path === '/api/v1/assignments' && in_array($method, ['POST', 'PUT'], true)) {
            $assignment = $this->saveAssignment($state, $body);
            return $method === 'POST' ? $this->created(['assignment' => $assignment]) : $this->ok(['assignment' => $assignment], true);
        }
        if (preg_match('#^/api/v1/assignments/([^/]+)$#', $path, $match) && $method === 'DELETE') {
            $this->purge($state['assignments'], rawurldecode($match[1]));
            return $this->ok(['ok' => true], true);
        }
        if (preg_match('#^/api/v1/(displays|display-groups)/([^/]+)/(channel|slide)$#', $path, $match) && $method === 'PUT') {
            $assignment = $this->saveAssignment($state, array_replace($body, [
                'target' => ['type' => $match[1] === 'displays' ? 'display' : 'group', 'id' => rawurldecode($match[2])],
                'content' => ['type' => $match[3], 'id' => (string)($body['id'] ?? $body['contentId'] ?? '')],
            ]));
            return $this->ok(['assignment' => $assignment], true);
        }
        if ($path === '/api/v1/emergencies/active' && $method === 'GET') {
            return $this->ok(['alert' => $this->activeEmergency($state)]);
        }
        if ($path === '/api/v1/emergencies' && $method === 'POST') {
            $warning = $this->externalWarning($state, $body, 'external_api');
            return $this->created(['alert' => $warning]);
        }
        if ($path === '/api/v1/emergencies/active' && $method === 'DELETE') {
            $this->endExternalWarnings($state);
            return $this->ok(['ok' => true], true);
        }
        if (preg_match('#^/api/v1/presets/([^/]+)/execute$#', $path, $match) && $method === 'POST') {
            $preset = $this->required($state['presets'], rawurldecode($match[1]), 'Preset');
            $config = is_array($preset['config'] ?? null) ? $preset['config'] : [];
            if (($preset['type'] ?? '') !== 'emergency' && (array_key_exists('channelUpdates',$config)||array_key_exists('assignments',$config)||array_key_exists('schedules',$config)||array_key_exists('presetTimers',$config))) {
                $execution=$this->executeStatePreset($state,$preset);
                return $this->created(['execution'=>$execution]);
            }
            $storedTargets=array_map(static function($value){
                if (!is_string($value)) return $value;
                if (in_array($value,['all','global'],true)) return ['type'=>'global','id'=>'global'];
                $parts=explode(':',$value,2);return count($parts)===2?['type'=>$parts[0],'id'=>$parts[1]]:['type'=>'group','id'=>$value];
            },is_array($config['targets'] ?? null)?$config['targets']:[]);
            $targets = $this->externalTargets($body['targets'] ?? $storedTargets);
            if (!$targets) throw new RuntimeException('Mindestens ein Ziel ist erforderlich.');
            foreach ($targets as $target) $this->assertExternalTarget($state,$target);
            $type = (string)($preset['type'] ?? 'channel');
            if ($type === 'channel') {
                $channelId = (string)($body['channelId'] ?? $preset['channelId'] ?? $config['channelId'] ?? '');
                $result = ['action' => 'channel_assigned', 'assignments' => array_map(
                    fn(array $target): array => $this->saveAssignment($state, array_replace($body, ['target' => $target, 'content' => ['type' => 'channel', 'id' => $channelId]]),'preset:'.$preset['id'].':'.$this->uuid()),
                    $targets
                )];
            } elseif ($type === 'emergency') {
                $value=array_replace($config,$body);$duration=(float)($value['durationMinutes'] ?? 0);
                $this->endExternalWarnings($state,'preset');
                $warning=$this->saveRecord($state,'warnings',[
                    'source'=>'external_preset','warningType'=>$value['warningType'] ?? $value['type'] ?? 'info',
                    'title'=>$value['title'] ?? $preset['name'],'instructions'=>$value['instructions'] ?? $value['message'] ?? '',
                    'description'=>$value['description'] ?? '', 'severity'=>max(0,min(5,(int)($value['severity'] ?? 3))),
                    'priority'=>max(0,min(1000,(int)($value['priority'] ?? 900))),
                    'document'=>is_array($value['document'] ?? null)?$value['document']:[],
                    'returnBehavior'=>in_array($value['returnBehavior'] ?? '',['resume_previous','standard_content'],true)?$value['returnBehavior']:'resume_current_schedule',
                    'targets'=>array_map(static fn(array $target):string=>$target['type']==='global'?'global':$target['type'].':'.$target['id'],$targets),
                    'startsAt'=>$this->now(),'endsAt'=>$duration>0?gmdate('c',QualityClock::now()+(int)($duration*60)):null,
                    'status'=>'active','publishedAt'=>$this->now()
                ]);
                $result=['action'=>'emergency_activated','alert'=>$warning];
            } else {
                $removed = $this->clearAssignmentTargets($state, $targets);
                if (($body['endEmergency'] ?? false) === true) $this->endExternalWarnings($state);
                $result = ['action' => 'reset', 'removedAssignments' => $removed, 'emergencyEnded' => ($body['endEmergency'] ?? false) === true];
            }
            $timers=$this->queuePresetTimerActions($state,$preset);if($timers)$result['presetTimers']=$timers;
            $execution = $this->record(['presetId' => $preset['id'], 'targets' => $targets, 'result' => $result, 'executedAt' => $this->now()]);
            $state['presetExecutions'][] = $execution;
            $state['presetExecutions'] = array_slice($state['presetExecutions'], -100);
            return $this->created(['execution' => $execution]);
        }
        if ($path === '/api/v1/preset-executions' && $method === 'GET') return $this->ok(['data' => array_values(array_filter(array_reverse($state['presetExecutions']),static fn(array $item): bool => empty($body['presetId']) || $item['presetId'] === $body['presetId']))]);
        if ($path === '/api/v1/presets/status' && $method === 'GET') return $this->ok(['activeAssignments' => $this->activeAssignments($state), 'executions' => array_reverse($state['presetExecutions'])]);
        if ($path === '/api/v1/presets/stop' && $method === 'POST') {
            $targets = $this->externalTargets($body['targets'] ?? []);
            $removed = $this->clearAssignmentTargets($state, $targets);
            if (($body['endWarnings'] ?? false) === true) $this->endExternalWarnings($state);
            return $this->ok(['removedAssignments' => $removed], true);
        }
        if ($path === '/api/v1/warnings/webhook' && $method === 'POST') {
            $warning = $this->externalWarning($state, $body, (string)($body['source'] ?? 'webhook'), ($body['publish'] ?? true) !== false);
            return $this->created(['warning' => $warning]);
        }
        throw new RuntimeException('API-v1-Endpunkt wurde nicht gefunden.', 404);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $input @return array<string,mixed> */
    private function saveAssignment(array &$state, array $input, ?string $presetSource=null): array
    {
        $target = $this->externalTarget($input['target'] ?? null);
        $content = is_array($input['content'] ?? null) ? $input['content'] : [];
        $contentType = (string)($content['type'] ?? '');
        $contentId = trim((string)($content['id'] ?? ''));
        if (!in_array($contentType, ['channel', 'slide'], true)) throw new RuntimeException('Inhaltstyp muss channel oder slide sein.');
        $this->required($state[$contentType === 'channel' ? 'channels' : 'slides'], $contentId, $contentType === 'channel' ? 'Kanal' : 'Slide');
        $this->assertExternalTarget($state, $target);
        $priority = (int)($input['priority'] ?? 100);
        if ($priority < 0 || $priority > 1000) throw new RuntimeException('priority muss zwischen 0 und 1000 liegen.');
        $startsAt = $this->externalDate($input['startsAt'] ?? null, 'startsAt');
        $expiresAt = $this->externalDate($input['expiresAt'] ?? null, 'expiresAt');
        if ($startsAt && $expiresAt && strtotime($expiresAt) <= strtotime($startsAt)) throw new RuntimeException('expiresAt muss nach startsAt liegen.');
        if($presetSource===null&&(!$startsAt||strtotime($startsAt)<=QualityClock::now()))PresetHandoff::releaseTargets($state,[$target]);
        $current = $this->first($state['assignments'], static fn(array $item): bool => ($item['target'] ?? null) === $target);
        $assignment = $this->record([
            'target' => $target, 'content' => ['type' => $contentType, 'id' => $contentId], 'priority' => $priority,
            'startsAt' => $startsAt, 'expiresAt' => $expiresAt, 'source' => $presetSource ?? 'external_api', 'createdBy' => $this->identity['id'],
        ], $current['id'] ?? null);
        $assignment['updatedAt']=(new \DateTimeImmutable('@'.QualityClock::now(),new \DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.u\Z');
        if ($current) $assignment['createdAt'] = $current['createdAt'];
        $index = $current ? $this->index($state['assignments'], (string)$current['id']) : null;
        if ($index === null) $state['assignments'][] = $assignment; else $state['assignments'][$index] = $assignment;
        $this->audit($state, 'external.assignment.upserted', (string)$assignment['id']);
        return $assignment;
    }

    /** @return array{type:string,id:string} */
    private function externalTarget(mixed $value): array
    {
        if (!is_array($value)) throw new RuntimeException('Ziel fehlt oder ist ungültig.');
        $type = (string)($value['type'] ?? '');
        $id = trim((string)($value['id'] ?? ''));
        if (!in_array($type, ['display', 'group', 'matrix', 'location', 'global'], true) || $id === '') throw new RuntimeException('Ziel ist ungültig.');
        return ['type' => $type, 'id' => $id];
    }

    /** @param array<string,mixed> $state @param array{type:string,id:string} $target */
    private function assertExternalTarget(array $state, array $target): void
    {
        if ($target['type'] === 'global' && $target['id'] === 'global') return;
        $collection = ['display' => 'displays', 'group' => 'groups', 'matrix' => 'matrices', 'location' => 'locations'][$target['type']] ?? '';
        if (!$collection || !$this->first($this->active($state[$collection]), fn(array $item): bool => $item['id'] === $target['id'])) throw new RuntimeException('Das Ausspielungsziel wurde nicht gefunden.');
    }

    /** Resolve time-only slots on the trigger day, using the external schedule contract. */
    private function presetSchedules(array $config,?int $at=null): array
    {
        if (!array_key_exists('schedules',$config)) return [];
        if (!is_array($config['schedules']) || !array_is_list($config['schedules']) || count($config['schedules'])>500) throw new RuntimeException('Ein Preset darf höchstens 500 Zeitzuweisungen enthalten.',422);
        $at??=QualityClock::now();
        return array_map(static function(mixed $input) use($at): array {
            if (!is_array($input)) throw new RuntimeException('Ungültige Zeitzuweisung im Preset.',422);
            return ExternalSchedule::input($input,$at);
        },$config['schedules']);
    }

    /** Saved actions are shared by manual requests, cron and authenticated player polls. */
    private function queuePresetTimerActions(array &$state,array $preset,?float $at=null): array
    {
        $config=is_array($preset['config'] ?? null)?$preset['config']:[];
        if(!empty($config['presetTimers']))$this->license()->assertPath($state,'/api/schedules');
        return PresetTimerActions::queue($state,$preset['id'],$config,$at);
    }

    private function executeStoredPreset(array &$state,string $presetId,array $body=[]): array
    {
            $preset = $this->required($state['presets'], $presetId, 'Preset');
            $config = is_array($preset['config'] ?? null) ? $preset['config'] : [];
            if (($preset['type'] ?? '') !== 'emergency') {
                $execution = $this->executeStatePreset($state,$preset);
                return $this->ok(['result' => $execution['result']], true);
            }
            $presetTimers=$this->queuePresetTimerActions($state,$preset);
            $targets = !empty($body['targets']) ? array_values(array_map('strval', $body['targets'])) : array_values(array_map('strval', $config['targets'] ?? []));
            if (!$targets) throw new RuntimeException('Das Preset enthält keine Zielbereiche.');
            $warning = $this->saveRecord($state, 'warnings', [
                'source' => 'preset:'.$preset['id'], 'warningType' => $config['warningType'] ?? 'info',
                'startsAt'=>$this->now(),'endsAt'=>(float)($config['durationMinutes'] ?? 0)>0?gmdate('c',QualityClock::now()+(int)((float)$config['durationMinutes']*60)):null,
                'severity' => (int)($config['severity'] ?? 3), 'title' => $config['title'] ?? $preset['name'],
                'description' => $config['description'] ?? '', 'instructions' => $config['instructions'] ?? '',
                'priority' => (int)($config['priority'] ?? 900), 'targets' => $targets,
                'document' => $config['document'] ?? [], 'returnBehavior' => $config['returnBehavior'] ?? 'resume_current_schedule',
                'status' => 'active', 'publishedAt' => $this->now(),
            ]);
            return $this->created(['warning' => $warning,'presetTimers'=>$presetTimers]);
    }

    private function runDuePresetTriggers(array &$state): int
    {
        if(!$this->license()->allows($state,'schedule','operations'))return 0;
        return PresetTriggers::runDue($state,function(array &$target,string $id): array {
            $preset=$this->required($target['presets'],$id,'Preset');
            if(($preset['status'] ?? '')!=='active')throw new RuntimeException('Aktives Preset wurde nicht gefunden.',422);
            return $this->executeStoredPreset($target,$id)[1];
        },QualityClock::micro());
    }

    private function executeStatePreset(array &$state,array $preset): array
    {
        $executionAt=QualityClock::micro();
        $config=is_array($preset['config'] ?? null)?$preset['config']:[];
        $channelUpdates = is_array($config['channelUpdates'] ?? null) ? $config['channelUpdates'] : [];
        $assignmentInputs = is_array($config['assignments'] ?? null) ? $config['assignments'] : [];

        $scheduleInputs=$this->presetSchedules($config,(int)$executionAt);
        if($scheduleInputs)$this->license()->assertPath($state,'/api/schedules');
        foreach($scheduleInputs as $input){
            $this->required($this->active($state[$input['targetType']==='display'?'displays':'groups']),$input['targetId'],'Ziel');
            $this->required($this->active($state[$input['contentType']==='slide'?'slides':'channels']),$input['contentId'],'Inhalt');
        }
        $timerInputs=PresetTimerActions::inputs($config,$executionAt);
        if (!$channelUpdates && !$assignmentInputs && !$scheduleInputs && !$timerInputs) throw new RuntimeException('Das Preset enthält noch keine ausführbaren Zustände.', 422);
        $updatedChannels = [];
        foreach ($channelUpdates as $update) {
            if (!is_array($update)) continue;
            $channel = $this->required($state['channels'], (string)($update['channelId'] ?? ''), 'Kanal');
            if(str_starts_with($channel['automationKey'] ?? '','advertising:channel')){$updatedChannels[]=['id'=>$channel['id'],'name'=>$channel['name'],'itemCount'=>count(AdvertisingService::playlist($state,$channel['orientation']))];continue;}
            $slideIds = array_values(array_unique(array_map('strval', is_array($update['slideIds'] ?? null) ? $update['slideIds'] : [])));
            if (!$slideIds) throw new RuntimeException('Ein Kanalzustand enthält keine Slides.', 422);
            foreach ($slideIds as $slideId) $this->required($state['slides'], $slideId, 'Slide');
            $channel['items'] = array_map(static fn(string $slideId): array => ['slideId' => $slideId, 'durationSeconds' => 12, 'transition' => 'inherit'], $slideIds);
            $updatedChannels[] = $this->saveRecord($state, 'channels', $channel, (string)$channel['id']);
        }
        $assignments = [];
        $runSource='preset:'.$preset['id'].':'.$this->uuid();
        foreach ($assignmentInputs as $input) {
            if (!is_array($input)) continue;
            $assignments[] = $this->saveAssignment($state, ['target' => ['type' => $input['targetType'] ?? '', 'id' => $input['targetId'] ?? ''], 'content' => ['type' => $input['contentType'] ?? '', 'id' => $input['contentId'] ?? ''], 'priority' => 500],$runSource);
        }
        $schedules=[];
        foreach($scheduleInputs as $input)$schedules[]=$this->collectionRoute($state,'POST','schedules','entry',$input)[1]['entry'];
        $presetTimers=$this->queuePresetTimerActions($state,$preset,$executionAt);
        $targets=array_merge(array_map(static fn(array $item): array=>$item['target'],$assignments),array_map(static fn(array $item): array=>['type'=>$item['targetType'],'id'=>$item['targetId']],$scheduleInputs));
        $targets=array_values(array_unique($targets,SORT_REGULAR));
        $execution = $this->record(['presetId' => $preset['id'], 'targets' => $targets, 'result' => ['action' => 'state_applied', 'presetTimers'=>$presetTimers, 'schedules'=>$schedules, 'channelUpdates' => $updatedChannels, 'assignments' => $assignments], 'executedAt' => $this->now()]);
        $state['presetExecutions'][] = $execution;
        $state['presetExecutions'] = array_slice($state['presetExecutions'], -100);
        return $execution;
    }

    private function externalTargets(mixed $value): array
    {
        if (!is_array($value)) return [];
        $targets = [];
        foreach ($value as $item) {
            $target = $this->externalTarget($item);
            $targets[$target['type'] . ':' . $target['id']] = $target;
        }
        if (count($targets) > 500) throw new RuntimeException('Höchstens 500 Ziele sind erlaubt.');
        return array_values($targets);
    }

    private function externalDate(mixed $value, string $field): ?string
    {
        if ($value === null || $value === '') return null;
        $time = strtotime((string)$value);
        if ($time === false) throw new RuntimeException($field . ' muss ein gültiger ISO-8601-Zeitpunkt sein.');
        return gmdate('c', $time);
    }

    /** @param array<string,mixed> $state @return array<int,array<string,mixed>> */
    private function activeAssignments(array $state): array
    {
        $now = QualityClock::now();
        return array_values(array_filter($state['assignments'], static function (array $item) use ($now): bool {
            $start = !empty($item['startsAt']) ? strtotime((string)$item['startsAt']) : false;
            $end = !empty($item['expiresAt']) ? strtotime((string)$item['expiresAt']) : false;
            return ($start === false || $start <= $now) && ($end === false || $end > $now);
        }));
    }

    /** @param array<string,mixed> $state @param array<int,array{type:string,id:string}> $targets */
    private function clearAssignmentTargets(array &$state, array $targets): int
    {
        $keys = array_map(static fn(array $target): string => $target['type'] . ':' . $target['id'], $targets);
        $before = count($state['assignments']);
        $state['assignments'] = array_values(array_filter($state['assignments'], static fn(array $item): bool => !in_array(($item['target']['type'] ?? '') . ':' . ($item['target']['id'] ?? ''), $keys, true)));
        return $before - count($state['assignments']);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $input @return array<string,mixed> */
    private function externalWarning(array &$state, array $input, string $source, bool $publish = true): array
    {
        $targets = $this->externalTargets($input['targets'] ?? []);
        if (!$targets) throw new RuntimeException('Mindestens ein Ziel ist erforderlich.');
        foreach ($targets as $target) $this->assertExternalTarget($state, $target);
        $title = trim((string)($input['title'] ?? ''));
        $instructions = trim((string)($input['instructions'] ?? $input['message'] ?? ''));
        if ($title === '' || $instructions === '') throw new RuntimeException('Titel und Anweisungen sind erforderlich.');
        $start = $this->externalDate($input['startsAt'] ?? null,'startsAt');
        $end = $this->externalDate($input['endsAt'] ?? null,'endsAt');
        if ($start && $end && strtotime($end) <= strtotime($start)) throw new RuntimeException('endsAt muss nach startsAt liegen.',422);
        if ($publish && in_array($source,['external_api','external_preset'],true)) $this->endExternalWarnings($state,$source==='external_preset'?'preset':'warning');
        return $this->saveRecord($state, 'warnings', [
            'source' => $source, 'startsAt' => $start, 'endsAt' => $end,
            'warningType' => (string)($input['warningType'] ?? $input['type'] ?? 'custom'),
            'severity' => (int)($input['severity'] ?? 5),
            'title' => $title, 'description' => (string)($input['description'] ?? ''),
            'instructions' => $instructions, 'priority' => (int)($input['priority'] ?? 900),
            'targets' => array_map(static fn(array $target): string => $target['type'] === 'global' ? 'global' : $target['type'] . ':' . $target['id'], $targets),
            'document' => is_array($input['document'] ?? null) ? $input['document'] : [],
            'returnBehavior' => 'resume_current_schedule',
            'status' => $publish ? 'active' : 'pending',
            ...($publish ? ['publishedAt' => $this->now()] : []),
        ]);
    }

    /** @param array<string,mixed> $state @return array<string,mixed>|null */
    private function activeEmergency(array $state): ?array
    {
        $alerts=array_values(array_filter(array_reverse($state['warnings']),static fn(array $item):bool=>($item['status'] ?? '')==='active'&&(in_array($item['source'] ?? '',['external_api','external_preset'],true)||self::presetWarning($item))&&(empty($item['startsAt'])||strtotime($item['startsAt'])<=QualityClock::now())&&(empty($item['endsAt'])||strtotime($item['endsAt'])>QualityClock::now())));
        usort($alerts,static fn(array $a,array $b):int=>self::compareWarnings($a,$b));return $alerts[0] ?? null;
    }

    /** @param array<string,mixed> $state */
    private function endExternalWarnings(array &$state,string $layer='all'): void
    {
        foreach ($state['warnings'] as &$warning) {
            if (($warning['status'] ?? '') === 'active' && ($layer==='preset'?($warning['source'] ?? '')==='external_preset':($layer==='warning'?($warning['source'] ?? '')==='external_api':(in_array($warning['source'] ?? '',['external_api','external_preset'],true)||self::presetWarning($warning))))) {
                $warning['status'] = 'ended';
                $warning['endedAt'] = $this->now();
            }
        }
        unset($warning);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function player(array &$state, string $method, string $slug, string $action, array $body, string $playerKey): array
    {
        $rawDisplay = $this->first($state['displays'], fn(array $item): bool => ($item['slug'] ?? '') === $slug && empty($item['deletedAt']) && ($item['status'] ?? '') !== 'archived');
        $display = $rawDisplay ? $this->listCollection(array_replace($state, ['displays' => [$rawDisplay]]), 'displays')[0] : null;
        if (!$display || !hash_equals((string)($display['playerKey'] ?? ''), $playerKey)) throw new RuntimeException('Display wurde nicht gefunden.', 404);
        $preview=($body['preview'] ?? '')==='1'||($body['preview'] ?? null)===1;
        $deliveryChanged=false;
        if (!$preview && in_array($action,['state','commands'],true) && $method==='GET') {
            $pending=array_values(array_filter($state['commands'],fn(array $item): bool => ($item['displayId'] ?? '')===$display['id']));
            $ids=array_column($pending,'id');$deliveryChanged=($state['deliveredPlayerCommands'][$display['id']] ?? [])!==$ids;
            $state['deliveredPlayerCommands'][$display['id']]=$ids;
            if ($action==='commands') return $this->ok(['commands'=>$pending],$deliveryChanged);
        }
        if ($action === 'heartbeat' && $method === 'POST') {
            $proofAccepted=[];$receipts=[];
            if($this->proofStore&&$this->license()->allows($state,'advertising')&&is_array($body['proofReceipts']??null)&&count($body['proofReceipts'])<=20){foreach($body['proofReceipts'] as $receipt){if(!is_array($receipt))continue;$row=PlaybackProof::receipt((string)$display['id'],$receipt,$this->proofSecret);if($row)$receipts[]=$row;if(is_string($receipt['id']??null))$proofAccepted[]=$receipt['id'];}try{if($receipts)$this->proofStore->insert($receipts);}catch(\Throwable){$proofAccepted=[];error_log('Kiosky: Ausspielnachweise vorübergehend nicht gespeichert; Player wird weiter bedient.');}}
            $body['lastSeenAt'] = $this->now();
            $body['online'] = true;
            $ids=array_key_exists('acknowledgedCommandIds',$body)?(is_array($body['acknowledgedCommandIds'])?array_slice($body['acknowledgedCommandIds'],0,100):[]):($state['deliveredPlayerCommands'][$display['id']] ?? []);
            // Heartbeat metadata may never overwrite credentials, routing or display configuration.
            $fields=PlayerHealth::metadata($body);$fields['lastSeenAt']=$this->now();$fields['playerHealth']=PlayerHealth::normalize($body['diagnostics']??null,is_array($rawDisplay['playerHealth']??null)?$rawDisplay['playerHealth']:null);
            // Persist status into the raw record: $display contains read-only projections.
            $index=$this->index($state['displays'],$display['id']);$state['displays'][$index]=array_replace($state['displays'][$index],$fields);
            $state['commands'] = array_values(array_filter($state['commands'], fn(array $item): bool => ($item['displayId'] ?? '') !== $display['id'] || ($ids!==null && !in_array($item['id'],$ids,true))));
            return $this->ok(['ok' => true,'proofAccepted'=>$proofAccepted], true);
        }
        if ($action === 'proof' && $method === 'POST') {
            return $this->ok(['disabled' => true]);
        }
        if ($action !== 'state' || $method !== 'GET') throw new RuntimeException('Methode nicht erlaubt.', 405);

        $presetTriggerChanged=$this->runDuePresetTriggers($state)>0;
        $matrixLayout = $this->matrixLayout($state, (string)$display['id']);
        $flowSchedules=$this->license()->allows($state,'events','schedule','operations','channels','displays')?EventAutomation::plans($state['eventAutomation']??[], $state['events'])['schedules']:[];
        $selectionState=$state;$selectionState['schedules']=[...$state['schedules'],...$flowSchedules];
        $beforeHandoffs=$state['presetHandoffs'] ?? [];
        $releasedPresets=PresetHandoff::released($selectionState,$display,$this->license()->allows($state,'schedule'));$state['presetHandoffs']=$selectionState['presetHandoffs']??[];
        $handoffChanged=$beforeHandoffs!==($state['presetHandoffs'] ?? []);
        $assignment = $this->license()->allows($state,'schedule') ? $this->resolveAssignment($state, $display, $matrixLayout,$releasedPresets) : null;
        $selection = $this->resolvedChannelSelection($selectionState, $display, $matrixLayout);
        $channel = $selection['channel'];
        $directSlide = $selection['directSlide'] ?? null;
        if ($assignment) {
            $content=is_array($assignment['content'] ?? null)?$assignment['content']:[];
            $override=$this->playbackContent($state,$display,(string)($content['type'] ?? ''),(string)($content['id'] ?? ''),$this->now());
            if($override){$selection=array_replace($selection,$override);$channel=$override['channel'];$directSlide=$override['directSlide'];}
            else $assignment=null;
        }
        $available=$selection['available'] ?? [];
        $slides = [];
        $playableSlidesById=array_column($this->active($state['slides']),null,'id');
        $projectOverview=AdvertisingService::overviewProjector($this->license()->allows($state,'events')?$this->active($state['events']):[],QualityClock::now());
        foreach ($directSlide ? [['slideId' => $directSlide['id'], 'durationSeconds' => 12, 'transition' => 'none']] : $available as $item) {
            $slide = $item['slide'] ?? $playableSlidesById[$item['slideId'] ?? ''] ?? null;
            if (!$slide || (!empty($slide['startsAt']) && strtotime($slide['startsAt'])>QualityClock::now()) || (!empty($slide['endsAt']) && strtotime($slide['endsAt'])<=QualityClock::now())) continue;
            $eventId=$slide['eventId'] ?? $channel['eventId'] ?? (!$assignment?($selection['eventContextId']??null):null);
            $event = $eventId ? $this->first($state['events'], fn(array $candidate): bool => $candidate['id'] === $eventId) : null;
            if($event&&!EventLifecycle::visible($event)&&!(!$assignment&&$event['id']===($selection['eventContextId']??null)&&!empty($event['autoArchived'])))$event=null;
            $event=SlideEventSelection::select($this->license()->allows($state,'events')?$this->active($state['events']):[],is_array($slide['document']['eventSelection'] ?? null)?$slide['document']['eventSelection']:[],$event);
            if($event){
                unset($event['internalNotes'],$event['lockedFields']);
                $scheduleRules=[];foreach(EasyJobService::roomUseTypes($state['easyjob']['roomUseTypeRules'] ?? []) as $rule)$scheduleRules[$rule['normalizedType']]=$rule;
                $event['scheduleEntries']=array_values(array_map(static fn(array $entry):array=>array_intersect_key($entry,array_flip(['id','displayCaption','category','startAt','endAt','roomName'])),array_filter($state['eventSchedules'],static fn(array $entry):bool=>($entry['eventId'] ?? '')===$event['id']&&($entry['active'] ?? true)!==false&&!in_array($entry['category'] ?? '',['internal','cancelled'],true)&&($entry['visible'] ?? true)!==false&&($scheduleRules[EasyJobService::normalizedRoomUseType((string)($entry['type'] ?? ''))]['visible'] ?? true)!==false)));
            }
            $slide=$projectOverview($slide);
            $slides[] = array_replace($item,['slide' => $slide, 'event' => $event]);
        }
        if($channel)$channel['items']=array_map(static fn(array $item):array=>array_diff_key($item,['slide'=>true]),$channel['items'] ?? []);
        $targets = ['global','all', 'display:' . $display['id']];
        foreach ($display['groupIds'] ?? [] as $groupId){$targets[]='group:'.$groupId;$targets[]=$groupId;}
        if (!empty($display['locationId'])) $targets[] = 'location:' . $display['locationId'];
        if ($matrixLayout) $targets[] = 'matrix:' . $matrixLayout['id'];
        $warningCandidates=array_values(array_filter(array_reverse($state['warnings']),fn(array $item):bool=>($item['status'] ?? '')==='active'&&(empty($item['startsAt'])||strtotime($item['startsAt'])<=QualityClock::now())&&(empty($item['endsAt'])||strtotime($item['endsAt'])>QualityClock::now())&&count(array_intersect($targets,$item['targets'] ?? []))>0&&empty($releasedPresets[PresetHandoff::key('warning',$item)])));
        usort($warningCandidates,static fn(array $a,array $b):int=>self::compareWarnings($a,$b));
        $warning=$warningCandidates[0] ?? null;
        $emergency = $warning ? [
            'id' => $warning['id'], 'type' => $warning['warningType'] ?? 'info', 'title' => $warning['title'] ?? '',
            'message' => $warning['instructions'] ?? ($warning['description'] ?? ''), 'description' => $warning['description'] ?? '',
            'targets' => $warning['targets'] ?? [], 'active' => true, 'source' => $warning['source'] ?? 'manual',
            'severity' => $warning['severity'] ?? 1, 'endsAt' => $warning['endsAt'] ?? null, 'document' => $warning['document'] ?? [],
        ] : null;
        $commands = array_values(array_filter($state['commands'], fn(array $item): bool => ($item['displayId'] ?? '') === $display['id']));
        $serverTime = $this->now();
        $matrixMode = $matrixLayout && ($assignment ? ($assignment['target']['type'] ?? '')==='matrix' : !empty($selection['matrixMode']));
        $playbackSync = [
            'scope' => $matrixMode ? 'matrix' : 'content',
            'key' => ($matrixMode ? $matrixLayout['id'] . ':' : $display['id'] . ':') . $selection['sourceKey'],
            'epochMs' => $this->milliseconds((string)$selection['epoch'], $serverTime),
            'serverTimeMs' => $this->milliseconds($serverTime, $serverTime),
        ];
        $scope=$matrixMode?'matrix:'.$matrixLayout['id']:'display:'.$display['id'];
        if ($assignment) $playbackSync['epochMs']=$this->milliseconds((string)($assignment['startsAt'] ?? $assignment['updatedAt'] ?? $serverTime),$serverTime);
        $revision=hash('sha256',json_encode(['source'=>$assignment?('assignment:'.$assignment['id']):$selection['sourceKey'],'channel'=>$channel,'assignment'=>$assignment,'slides'=>$slides],JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES));
        $previous=$state['playbackRevisions'][$scope] ?? null;$changed=($previous['revision'] ?? null)!==$revision;
        if ($changed) $state['playbackRevisions'][$scope]=['revision'=>$revision,'epochMs'=>$previous?$this->milliseconds($serverTime,$serverTime):$playbackSync['epochMs']];
        $playbackSync['key']=$scope.':'.$revision;$playbackSync['epochMs']=$state['playbackRevisions'][$scope]['epochMs'];
        $fontContent=$this->license()->playback($state,['slides'=>$slides,'warning'=>$emergency,'emergency'=>$emergency]);
        $fonts=$this->fontCatalog($state,$fontContent);
        if(array_key_exists('fontId',$body)){
            $id=is_string($body['fontId'])?$body['fontId']:'';
            if(!in_array($id,array_column($fonts,'id'),true))throw new RuntimeException('Diese Schrift ist dem Display nicht zugewiesen.',404);
            return $this->ok($this->fontFile($state,$id),$changed||$deliveryChanged||$handoffChanged||$presetTriggerChanged);
        }
        $output=[
            'fonts'=>$fonts, 'display' => $display, 'channel' => $channel, 'directSlide' => $directSlide, 'assignment' => $assignment,
            'slides' => $slides, 'emergency' => $emergency, 'warning' => $emergency,
            'matrix' => $matrixLayout ? array_replace($matrixLayout, ['mode' => $matrixMode ? 'matrix' : 'individual']) : null,
            'selectionReason'=>['kind'=>$emergency?'warning':($assignment?'assignment':(str_starts_with($selection['sourceKey'],'schedule:')?'schedule':'default')),'scheduleId'=>str_starts_with($selection['sourceKey'],'schedule:')?substr($selection['sourceKey'],9):null,'targetType'=>$assignment['target']['type']??null,'candidates'=>$selection['candidateSchedules']??[],'emptyFallback'=>!$assignment&&!str_starts_with($selection['sourceKey'],'schedule:')&&!empty($selection['candidateSchedules'])],
            'playbackProof'=>['grants'=>!$preview&&$this->proofStore&&$this->license()->allows($state,'advertising')?PlaybackProof::grants((string)$display['id'],$channel,$slides,$this->proofSecret):new \stdClass()],
            'playbackSync' => $playbackSync, 'contentRevision'=>$revision, 'commands' => $preview?[]:$commands, 'serverTime' => $serverTime,
        ];
        $flowChanged=false;if(!$preview&&($flowSchedules||!empty($state['eventAutomation']['observations'][$display['id']]))&&$this->license()->allows($state,'events','schedule','operations','channels','displays')){$state['eventAutomation']??=EventAutomation::empty();$flowChanged=EventAutomation::observe($state['eventAutomation'],$flowSchedules,array_replace($display,['matrixId'=>$matrixLayout['id']??null]),$output,QualityClock::micro());}
        return $this->ok($output,$changed||$deliveryChanged||$handoffChanged||$presetTriggerChanged||$flowChanged);
    }

    /** @param array<string,mixed> $state @param array<string,mixed>|null $matrix @return array<string,mixed>|null */
    private function resolveAssignment(array $state, array $display, ?array $matrix, array $released=[]): ?array
    {
        $now = QualityClock::now();
        $candidates = array_values(array_filter($state['assignments'], function (array $item) use ($display, $matrix, $now,$released): bool {
            if(!empty($released[PresetHandoff::key('assignment',$item)]))return false;
            $startsAt = !empty($item['startsAt']) ? strtotime((string)$item['startsAt']) : false;
            $expiresAt = !empty($item['expiresAt']) ? strtotime((string)$item['expiresAt']) : false;
            if (($startsAt !== false && $startsAt > $now) || ($expiresAt !== false && $expiresAt <= $now)) return false;
            $target = is_array($item['target'] ?? null) ? $item['target'] : [];
            return (($target['type'] ?? '') === 'display' && ($target['id'] ?? '') === $display['id'])
                || (($target['type'] ?? '') === 'group' && in_array($target['id'] ?? '', $display['groupIds'] ?? [], true))
                || (($target['type'] ?? '') === 'matrix' && $matrix && ($target['id'] ?? '') === $matrix['id'])
                || (($target['type'] ?? '') === 'location' && ($target['id'] ?? '') === ($display['locationId'] ?? ''))
                || (($target['type'] ?? '') === 'global' && ($target['id'] ?? '') === 'global');
        }));
        $specificity = ['global' => 1, 'location' => 2, 'group' => 3, 'matrix' => 4, 'display' => 5];
        usort($candidates, static function (array $left, array $right) use ($specificity): int {
            $leftType = (string)($left['target']['type'] ?? 'global');
            $rightType = (string)($right['target']['type'] ?? 'global');
            return ($specificity[$rightType] ?? 0) <=> ($specificity[$leftType] ?? 0)
                ?: (int)($right['priority'] ?? 100) <=> (int)($left['priority'] ?? 100)
                ?: strcmp((string)($right['updatedAt'] ?? ''), (string)($left['updatedAt'] ?? ''));
        });
        return $candidates[0] ?? null;
    }

    /**
     * @param array<string,mixed> $state
     * @param array<string,mixed> $display
     * @param array<string,mixed>|null $matrix
     * @return array{channel:array<string,mixed>|null,directSlide:array<string,mixed>|null,sourceKey:string,epoch:string,matrixMode:bool}
     */
    private function playableChannelItems(array $state,?array $channel,array $display,string $at): array
    {
        if(!$channel)return [];
        $location=(string)($display['locationId'] ?? '');
        if(!empty($channel['locationIds'])&&!in_array($location,$channel['locationIds'],true))return [];
        $slides=array_column($this->active($state['slides']),null,'id');$time=strtotime($at);
        return array_values(array_filter($channel['items'] ?? [],static function(array $item)use($slides,$time,$location):bool{
            $slide=$item['slide'] ?? $slides[$item['slideId'] ?? ''] ?? null;
            return $slide && (empty($slide['startsAt'])||strtotime($slide['startsAt'])<=$time) && (empty($slide['endsAt'])||strtotime($slide['endsAt'])>$time) && (empty($slide['locationIds'])||in_array($location,$slide['locationIds'],true));
        }));
    }

    private function resolvedChannelSelection(array $state, array $display, ?array $matrix): array
    {
        $now = $this->now();
        $licensedSchedules=$this->license()->allows($state,'schedule') ? $state['schedules'] : [];
        $schedules = array_values(array_filter($licensedSchedules, function (array $item) use ($display, $now): bool {
            if (($item['status'] ?? '') !== 'published' || (empty($item['channelId']) && empty($item['slideId']) && empty($item['contentId'])) || !$this->scheduleActive($item, $now)) return false;
            return (($item['targetType'] ?? '') === 'display' && ($item['targetId'] ?? '') === $display['id'])
                || (($item['targetType'] ?? '') === 'group' && in_array($item['targetId'] ?? '', $display['groupIds'] ?? [], true));
        }));
        if ($matrix) {
            foreach ($licensedSchedules as $schedule) {
                if (($schedule['status'] ?? '') === 'published' && ($schedule['targetType'] ?? '') === 'matrix' && ($schedule['targetId'] ?? '') === $matrix['id'] && $this->scheduleActive($schedule, $now)) {
                    $schedules[] = $schedule;
                }
            }
        }
        usort($schedules, static function (array $a, array $b): int {
            $stack = (int)($b['stackOrder'] ?? 0) <=> (int)($a['stackOrder'] ?? 0);
            if ($stack !== 0) return $stack;
            $created = strcmp((string)($b['createdAt'] ?? ''), (string)($a['createdAt'] ?? ''));
            if ($created !== 0) return $created;
            $ranks = ['normal' => 1, 'high' => 2, 'takeover' => 3];
            return (($ranks[$b['priority'] ?? 'normal'] ?? 0) <=> ($ranks[$a['priority'] ?? 'normal'] ?? 0)) ?: (['display'=>3,'matrix'=>2,'group'=>1][$b['targetType'] ?? ''] ?? 0) <=> (['display'=>3,'matrix'=>2,'group'=>1][$a['targetType'] ?? ''] ?? 0);
        });
        $schedule = $schedules[0] ?? null;
        $candidateSchedules=array_map(static fn(array $s):array=>array_intersect_key($s,array_flip(['id','contentId','targetType','targetId','ruleName','contentName'])),$schedules);
        $candidates=[];
        if($schedule){$type=$schedule['contentType'] ?? (!empty($schedule['slideId'])?'slide':'channel');$id=$schedule['contentId'] ?? $schedule[$type.'Id'] ?? ''; $candidates[]=['type'=>$type,'id'=>$id,'sourceKey'=>'schedule:'.$schedule['id'],'eventContextId'=>$schedule['eventId']??null,'epoch'=>$schedule['startsAt'],'matrixMode'=>$matrix&&($schedule['targetType'] ?? '')==='matrix'];}
        if(!empty($matrix['defaultChannelId']))$candidates[]=['type'=>'channel','id'=>$matrix['defaultChannelId'],'matrixMode'=>true];
        $type=($display['defaultContentType'] ?? 'channel')==='slide'?'slide':'channel';
        $id=$display[$type==='slide'?'defaultSlideId':'defaultChannelId'] ?? '';
        if($id)$candidates[]=['type'=>$type,'id'=>$id,'matrixMode'=>false];
        foreach($candidates as $candidate){
            $selected=$this->playbackContent($state,$display,(string)$candidate['type'],(string)$candidate['id'],$now);
            if(!$selected)continue;
            $record=$selected['directSlide'] ?? $selected['channel'];
            return $selected+['eventContextId'=>$candidate['eventContextId']??null,'candidateSchedules'=>$candidateSchedules,'sourceKey'=>$candidate['sourceKey'] ?? 'default:'.$candidate['id'].':'.($record['updatedAt'] ?? ''),'epoch'=>$candidate['epoch'] ?? $record['updatedAt'] ?? $now,'matrixMode'=>(bool)$candidate['matrixMode']];
        }
        return ['channel'=>null,'directSlide'=>null,'available'=>[],'candidateSchedules'=>$candidateSchedules,'sourceKey'=>'default:empty','epoch'=>$now,'matrixMode'=>false];
    }

    private function playbackContent(array $state,array $display,string $type,string $id,string $at): ?array
    {
        if(!$id||!in_array($type,['channel','slide'],true))return null;
        $record=$this->first($this->active($state[$type==='slide'?'slides':'channels']),static fn(array $item):bool=>$item['id']===$id);
        if(!$record)return null;
        if($type==='channel'&&str_starts_with($record['automationKey'] ?? '','advertising:channel')&&!AdvertisingService::settings($state)['enabled'])return null;
        $channel=$type==='channel'?AdvertisingService::channel($state,$record):null;$direct=$type==='slide'?$record:null;
        $items=$this->playableChannelItems($state,$channel ?? ['items'=>[['slideId'=>$id,'durationSeconds'=>12,'transition'=>'none']]],$display,$at);
        return $items?['channel'=>$channel,'directSlide'=>$direct,'available'=>$items]:null;
    }

    private static function presetWarning(array $warning): bool
    {
        return ($warning['source'] ?? '')==='external_preset'||str_starts_with((string)($warning['source'] ?? ''),'preset:');
    }
    private static function compareWarnings(array $a,array $b): int
    {
        return (int)self::presetWarning($a)<=>(int)self::presetWarning($b)
            ?: (int)($b['priority'] ?? 0)<=>(int)($a['priority'] ?? 0)
            ?: strcmp((string)($b['publishedAt'] ?? $b['createdAt'] ?? ''),(string)($a['publishedAt'] ?? $a['createdAt'] ?? ''));
    }

    /** @param array<string,mixed> $state @return array<string,mixed>|null */
    private function matrixLayout(array $state, string $displayId): ?array
    {
        $matrix = $this->first($this->active($state['matrices']), static fn(array $candidate): bool =>
            ($candidate['status'] ?? '') === 'active'
            && in_array($displayId, array_column(is_array($candidate['members'] ?? null) ? $candidate['members'] : [], 'displayId'), true)
        );
        if (!$matrix) return null;
        $members = is_array($matrix['members'] ?? null) ? $matrix['members'] : [];
        $member = $this->first($members, static fn(array $candidate): bool => ($candidate['displayId'] ?? '') === $displayId);
        if (!$member) return null;
        $columns = max(1, (int)($matrix['columns'] ?? 1));
        $rows = max(1, (int)($matrix['rows'] ?? 1));
        $widthFor = static fn(array $item): int => (int)(($item['orientation'] ?? '') === 'portrait' ? ($item['physicalHeight'] ?? 1920) : ($item['physicalWidth'] ?? 1920));
        $heightFor = static fn(array $item): int => (int)(($item['orientation'] ?? '') === 'portrait' ? ($item['physicalWidth'] ?? 1080) : ($item['physicalHeight'] ?? 1080));
        $columnWidths = [];
        for ($column = 0; $column < $columns; $column++) {
            $columnWidths[] = max([0, ...array_map($widthFor, array_filter($members, static fn(array $item): bool => (int)($item['column'] ?? 0) === $column))]);
        }
        $rowHeights = [];
        for ($row = 0; $row < $rows; $row++) {
            $rowHeights[] = max([0, ...array_map($heightFor, array_filter($members, static fn(array $item): bool => (int)($item['row'] ?? 0) === $row))]);
        }
        $crop = is_array($member['crop'] ?? null) ? $member['crop'] : [];
        $memberColumn = (int)($member['column'] ?? 0);
        $memberRow = (int)($member['row'] ?? 0);
        return [
            'id' => $matrix['id'],
            'name' => $matrix['name'] ?? 'Matrix',
            'rows' => $rows,
            'columns' => $columns,
            'defaultChannelId' => $matrix['defaultChannelId'] ?? null,
            'totalResolution' => ['width' => array_sum($columnWidths), 'height' => array_sum($rowHeights)],
            'viewport' => [
                'x' => is_numeric($crop['x'] ?? null) ? (float)$crop['x'] : array_sum(array_slice($columnWidths, 0, $memberColumn)) + (float)($member['offsetX'] ?? 0),
                'y' => is_numeric($crop['y'] ?? null) ? (float)$crop['y'] : array_sum(array_slice($rowHeights, 0, $memberRow)) + (float)($member['offsetY'] ?? 0),
                'width' => is_numeric($crop['width'] ?? null) ? (float)$crop['width'] : $widthFor($member),
                'height' => is_numeric($crop['height'] ?? null) ? (float)$crop['height'] : $heightFor($member),
                'scale' => (float)($member['scale'] ?? 1),
                'row' => $memberRow,
                'column' => $memberColumn,
            ],
        ];
    }

    /** @param array<string,mixed> $schedule */
    private function scheduleActive(array $schedule, string $nowValue): bool
    {
        return ExternalSchedule::active($schedule,$nowValue);
    }

    private function milliseconds(string $value, string $fallback): int
    {
        $timestamp = strtotime($value);
        if ($timestamp === false) $timestamp = strtotime($fallback);
        return (int)($timestamp !== false ? $timestamp * 1000 : QualityClock::now() * 1000);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function displayDefaults(array $state,array $body): array
    {
        $type=$body['defaultContentType'] ?? 'channel';
        if(!in_array($type,['channel','slide'],true))throw new RuntimeException('Ungültiger Standardinhalt.',422);
        $body['defaultContentType']=$type;
        if($type==='slide'){
            $id=$body['defaultSlideId'] ?? null;
            if($id!==null&&(!is_string($id)||strlen($id)>100))throw new RuntimeException('Ungültige Standardslide.',422);
            if($id)$this->required($this->active($state['slides']),(string)$id,'Standardslide');
            $body['defaultSlideId']=$id;$body['defaultChannelId']=null;
        }else{$body['defaultSlideId']=null;}
        return $body;
    }

    private function collectionRoute(array &$state, string $method, string $collection, string $singular, array $body): array
    {
        if ($method === 'GET') return $this->ok(['data' => $this->listCollection($state, $collection)]);
        if ($method === 'POST') {
            if ($collection === 'displays' && empty($body['playerKey'])) $body['playerKey'] = bin2hex(random_bytes(24));
            if ($collection === 'displays') $body=$this->displayDefaults($state,$body);
            if ($collection === 'displays') $body += ['groupIds' => [], 'online' => false, 'cached' => false, 'channel' => 'Kein Standardkanal'];
            if ($collection === 'warnings') $body += ['status' => 'draft', 'source' => 'manual', 'targets' => []];
            if ($collection === 'schedules') {
                $contentType = ($body['contentType'] ?? 'channel') === 'slide' ? 'slide' : 'channel';
                $contentId = (string)($body['contentId'] ?? $body[$contentType . 'Id'] ?? '');
                $body['contentType'] = $contentType;
                $body['contentId'] = $contentId;
                $body['channelId'] = $contentType === 'channel' ? $contentId : null;
                $body['slideId'] = $contentType === 'slide' ? $contentId : null;
                if (!isset($body['stackOrder'])) {
                    $highest = max([0, ...array_map(static fn(array $schedule): int =>
                        ($schedule['targetType'] ?? '') === ($body['targetType'] ?? '')
                        && ($schedule['targetId'] ?? '') === ($body['targetId'] ?? '')
                            ? (int)($schedule['stackOrder'] ?? 0)
                            : 0, $state['schedules'])]);
                    $body['stackOrder'] = max((int)floor(QualityClock::micro() * 1000), $highest + 1);
                }
            }
            if ($collection === 'matrices') $this->validateMatrix($state, $body);
            $record = $this->saveRecord($state, $collection, $body);
            if ($collection === 'groups') $this->syncGroupMembers($state, $record);
            return $this->created([$singular => $record]);
        }
        throw new RuntimeException('Methode nicht erlaubt.', 405);
    }

    /** @param array<string,mixed> $state @return array<int,array<string,mixed>> */
    private function listCollection(array $state, string $collection): array
    {
        $items = $this->active($state[$collection]);
        if($collection==='slides')return array_values(array_filter($items,static fn(array $s):bool=>!str_starts_with($s['automationKey'] ?? '','advertising:event:')));
        if($collection==='channels')return array_map(static fn(array $c):array=>AdvertisingService::channel($state,$c),$items);
        if ($collection === 'groups') {
            return array_map(fn(array $item):array=>array_replace($item,['displayIds'=>array_values(array_column(array_filter($this->active($state['displays']),static fn(array $display):bool=>in_array($item['id'],$display['groupIds'] ?? [],true)),'id'))])+['status'=>'active'],$items);
        }
        if ($collection === 'locations') {
            $counts = [];
            foreach ($this->active($state['displays']) as $display) {
                $id = $display['locationId'] ?? '';
                if (is_string($id)) $counts[$id] = ($counts[$id] ?? 0) + 1;
            }
            return array_map(function (array $item) use ($counts): array {
                $item['displayCount'] = $counts[$item['id']] ?? 0;
                $item['playerBackgroundColor'] ??= '#000000';
                return $item;
            }, $items);
        }
        $channels = [];
        if (in_array($collection, ['presets', 'schedules', 'matrices', 'displays'], true)) {
            foreach ($state['channels'] as $record) $channels[$record['id']] ??= $record;
        }
        if ($collection === 'presets') {
            return array_map(function (array $item) use ($channels): array {
                $channel = $channels[$item['channelId'] ?? ''] ?? null;
                $item['channelName'] = $channel['name'] ?? null;
                return $item;
            }, $items);
        }
        if ($collection === 'schedules') {
            $slides = [];
            foreach ($state['slides'] as $record) $slides[$record['id']] ??= $record;
            return array_map(function (array $item) use ($channels, $slides): array {
                $type=$item['contentType'] ?? (!empty($item['slideId'])?'slide':'channel');$id=$item['contentId'] ?? $item[$type.'Id'] ?? '';
                $item['channelId']=$type==='channel'?$id:null;$item['slideId']=$type==='slide'?$id:null;
                $channel = $channels[$item['channelId'] ?? ''] ?? null;
                $slide = $slides[$item['slideId'] ?? ''] ?? null;
                $item['contentType'] = $item['contentType'] ?? ($slide ? 'slide' : 'channel');
                $item['contentId'] = $item['contentId'] ?? ($slide['id'] ?? $channel['id'] ?? '');
                $item['contentName'] = $slide['name'] ?? $channel['name'] ?? 'Unbekannter Inhalt';
                $item['channelName'] = $channel['name'] ?? null;
                $item['slideName'] = $slide['name'] ?? null;
                return $item;
            }, $items);
        }
        if ($collection === 'matrices') {
            return array_map(function (array $item) use ($channels): array {
                $members = is_array($item['members'] ?? null) ? $item['members'] : [];
                $columns = max(1, (int)($item['columns'] ?? 1));
                $rows = max(1, (int)($item['rows'] ?? 1));
                $columnWidths = [];
                for ($column = 0; $column < $columns; $column++) {
                    $columnWidths[] = max([0, ...array_map(
                        static fn(array $member): int => (int)(($member['orientation'] ?? '') === 'portrait' ? ($member['physicalHeight'] ?? 1920) : ($member['physicalWidth'] ?? 1920)),
                        array_filter($members, static fn(array $member): bool => (int)($member['column'] ?? 0) === $column)
                    )]);
                }
                $rowHeights = [];
                for ($row = 0; $row < $rows; $row++) {
                    $rowHeights[] = max([0, ...array_map(
                        static fn(array $member): int => (int)(($member['orientation'] ?? '') === 'portrait' ? ($member['physicalWidth'] ?? 1080) : ($member['physicalHeight'] ?? 1080)),
                        array_filter($members, static fn(array $member): bool => (int)($member['row'] ?? 0) === $row)
                    )]);
                }
                $channel = $channels[$item['defaultChannelId'] ?? ''] ?? null;
                $item['channelName'] = $channel['name'] ?? null;
                $item['totalResolution'] = ['width' => array_sum($columnWidths), 'height' => array_sum($rowHeights)];
                return $item;
            }, $items);
        }
        if ($collection !== 'displays') return $items;
        $locations = []; $slides = []; $memberships = [];
        foreach ($state['locations'] as $record) $locations[$record['id']] ??= $record;
        foreach ($state['slides'] as $record) $slides[$record['id']] ??= $record;
        foreach ($this->active($state['matrices']) as $matrix) {
            foreach ($matrix['members'] ?? [] as $member) $memberships[$member['displayId']] ??= [$matrix, $member];
        }
        $now = QualityClock::now();
        $eventNames=array_column($state['events'],'title','id');
        return array_map(function (array $item) use ($channels, $locations, $slides, $memberships, $now,$eventNames): array {
            $channel = $channels[$item['defaultChannelId'] ?? ''] ?? null;
            $location = $locations[$item['locationId'] ?? ''] ?? null;
            [$matrix, $member] = $memberships[$item['id']] ?? [null, null];
            $item['defaultContentType']=$item['defaultContentType'] ?? 'channel';
            $defaultSlide=$slides[$item['defaultSlideId'] ?? ''] ?? null;
            $item['channel'] = ($item['defaultContentType']==='slide'?($defaultSlide['name'] ?? null):($channel['name'] ?? null)) ?? 'Kein Standardinhalt';
            $currentChannel = $channels[$item['channelId'] ?? ''] ?? null;
            $currentSlide = $slides[$item['slideId'] ?? ''] ?? null;
            if(!$currentSlide&&preg_match('/^advertising-event:(?:landscape|portrait):(.+)$/',(string)($item['slideId'] ?? ''),$match)&&isset($eventNames[$match[1]]))$currentSlide=['name'=>'Werbung · '.$eventNames[$match[1]]];
            $lastSeen = strtotime((string)($item['lastSeenAt'] ?? ''));
            $item['online'] = !empty($item['online']) && $lastSeen !== false && abs($now - $lastSeen) <= 60;
            $item['currentChannelId'] = $item['channelId'] ?? null;
            $item['currentChannelName'] = $currentChannel['name'] ?? null;
            $item['currentSlideId'] = $item['slideId'] ?? null;
            $item['currentSlideName'] = $currentSlide['name'] ?? null;
            $item['location'] = $location['name'] ?? null;
            $item['playerBackgroundColor'] = preg_match('/^#[0-9a-f]{6}$/i',(string)($location['playerBackgroundColor'] ?? ''))?strtolower($location['playerBackgroundColor']):'#000000';
            $item['clockTimezone'] = $location['timezone'] ?? $item['timezone'] ?? 'Europe/Berlin';
            $item['resolution'] = ['width' => (int)($item['width'] ?? 1920), 'height' => (int)($item['height'] ?? 1080)];
            $item['resolutionMode'] = ($item['resolutionMode'] ?? '') === 'native' ? 'native' : 'fixed';
            unset($item['detectedResolution']);
            $viewportWidth=$item['viewportWidth'] ?? null;$viewportHeight=$item['viewportHeight'] ?? null;
            if(is_numeric($viewportWidth)&&is_numeric($viewportHeight)&&$viewportWidth>=100&&$viewportWidth<=50000&&$viewportHeight>=100&&$viewportHeight<=50000)$item['detectedResolution']=['width'=>(int)$viewportWidth,'height'=>(int)$viewportHeight];
            $item['matrix'] = $matrix && $member ? ['id' => $matrix['id'], 'name' => $matrix['name'], 'row' => (int)($member['row'] ?? 0), 'column' => (int)($member['column'] ?? 0)] : null;
            return $item;
        }, $items);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function itemRoute(array &$state, string $method, string $collection, string $singular, string $id, array $body, bool $trash = false): array
    {
        if ($method === 'PUT') {
            if($collection==='groups'&&!array_key_exists('displayIds',$body))$body['displayIds']=array_values(array_column(array_filter($this->active($state['displays']),static fn(array $display):bool=>in_array($id,$display['groupIds'] ?? [],true)),'id'));
            if($collection==='displays')$body=$this->displayDefaults($state,array_replace($this->required($state['displays'],$id,'Display'),$body));
            if ($collection === 'matrices') $this->validateMatrix($state, $body, $id);
            $record = $this->saveRecord($state, $collection, $body, $id);
            if ($collection === 'groups') $this->syncGroupMembers($state, $record);
            return $this->ok([$singular => $record], true);
        }
        if ($method === 'DELETE') {
            if ($collection === 'groups') {
                foreach ($state['displays'] as &$display) $display['groupIds'] = array_values(array_diff($display['groupIds'] ?? [], [$id]));
                unset($display);
            }
            if ($collection === 'locations') {
                foreach ($state['displays'] as &$display) if (($display['locationId'] ?? '') === $id) unset($display['locationId']);
                unset($display);
            }
            if ($collection === 'displays') {
                foreach ($state['groups'] as &$group) $group['displayIds'] = array_values(array_diff($group['displayIds'] ?? [], [$id]));
                unset($group);
                foreach ($state['matrices'] as &$matrix) $matrix['members'] = array_values(array_filter($matrix['members'] ?? [], static fn(array $member): bool => ($member['displayId'] ?? '') !== $id));
                unset($matrix);
            }
            return $trash ? $this->trashRecord($state, $collection, $singular === 'group' ? 'display_group' : $singular, $id) : $this->deleteRecord($state, $collection, $id);
        }
        throw new RuntimeException('Methode nicht erlaubt.', 405);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $group */
    private function syncGroupMembers(array &$state, array $group): void
    {
        $groupId = (string)$group['id'];
        $displayIds = array_values(array_unique(array_map('strval', is_array($group['displayIds'] ?? null) ? $group['displayIds'] : [])));
        foreach ($state['displays'] as &$display) {
            $groups = array_values(array_diff(array_map('strval', $display['groupIds'] ?? []), [$groupId]));
            if (in_array((string)$display['id'], $displayIds, true)) $groups[] = $groupId;
            $display['groupIds'] = array_values(array_unique($groups));
        }
        unset($display);
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $input */
    private function validateMatrix(array $state, array $input, ?string $matrixId = null): void
    {
        $rows = (int)($input['rows'] ?? 0);
        $columns = (int)($input['columns'] ?? 0);
        $members = is_array($input['members'] ?? null) ? $input['members'] : [];
        if ($rows < 1 || $rows > 20 || $columns < 1 || $columns > 20) throw new RuntimeException('Das Matrix-Raster muss zwischen 1×1 und 20×20 liegen.');
        $positions = [];
        $displayIds = [];
        foreach ($members as $member) {
            if (!is_array($member)) throw new RuntimeException('Matrix-Mitglied ist ungültig.');
            $displayId = (string)($member['displayId'] ?? '');
            $row = (int)($member['row'] ?? -1);
            $column = (int)($member['column'] ?? -1);
            $this->required($state['displays'], $displayId, 'Display');
            if ($row < 0 || $column < 0 || $row >= $rows || $column >= $columns) throw new RuntimeException('Eine Display-Position liegt außerhalb des Matrix-Rasters.');
            $position = $row . ':' . $column;
            if (isset($positions[$position])) throw new RuntimeException('Jedes Matrix-Feld darf nur einmal belegt sein.');
            if (isset($displayIds[$displayId])) throw new RuntimeException('Ein Display darf in einer Matrix nur einmal vorkommen.');
            $positions[$position] = true;
            $displayIds[$displayId] = true;
            if (($input['status'] ?? '') !== 'active') continue;
            $conflict = $this->first($this->active($state['matrices']), static fn(array $matrix): bool =>
                ($matrix['status'] ?? '') === 'active'
                && ($matrix['id'] ?? '') !== $matrixId
                && in_array($displayId, array_column(is_array($matrix['members'] ?? null) ? $matrix['members'] : [], 'displayId'), true)
            );
            if ($conflict) throw new RuntimeException('Das Display ist bereits der aktiven Matrix „' . ($conflict['name'] ?? 'Unbekannt') . '“ zugeordnet.');
        }
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array<string,mixed> */
    private function saveSlide(array &$state, array $body, ?string $id = null): array
    {
        $current = $id ? $this->required($state['slides'], $id, 'Slide') : null;
        unset($body['automationKey'],$body['virtual']);
        $body['ownerId']=$current['ownerId'] ?? ($current?null:(string)$this->identity['id']);
        if (isset($current['document']['menuPdf']) && !isset($body['document']['menuPdf'])) $body['document']['menuPdf']=$current['document']['menuPdf'];
        if (isset($current['document']['menu']) && !isset($body['document']['menu'])) $body['document']['menu'] = $current['document']['menu'];
        if(AdvertisingService::formats(array_replace($current ?? [],$body)) && empty($body['endsAt'])) $body['endsAt']=$current['endsAt'] ?? gmdate('c',max(QualityClock::now(),strtotime((string)($body['startsAt'] ?? '')) ?: 0)+7*86400);
        $version = (int)($current['currentVersion'] ?? 0) + 1;
        $orientation = (string)($body['orientation'] ?? 'landscape');
        $body += ['width' => $orientation === 'portrait' ? 1080 : 1920, 'height' => $orientation === 'portrait' ? 1920 : 1080, 'status' => 'draft'];
        if(isset($body['document']['menu']) || isset($body['document']['menuPdf']))$body['document']=MenuContent::responsiveDocument($body['document'],$orientation);
        if(isset($body['document']['menu']) || isset($body['document']['menuPdf'])){ $base=$orientation==='auto'?($body['document']['designOrientation'] ?? 'landscape'):$orientation;$body['width']=$base==='portrait'?1080:1920;$body['height']=$base==='portrait'?1920:1080;}
        $body['currentVersion'] = $version;
        $slide = $this->saveRecord($state, 'slides', $body, $id);
        $state['slideVersions'][] = $this->record(['slideId' => $slide['id'], 'version' => $version, 'document' => $slide['document'] ?? [], 'changeNote' => $current ? 'Im Slide-Editor gespeichert' : 'Slide angelegt']);
        return $slide;
    }

    private function berlinEventTime(string $date, string $time): ?string
    {
        $digits = preg_replace('/\D/', '', $date) ?: '';
        if (strlen($digits) < 8 || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time)) return null;
        $value = \DateTimeImmutable::createFromFormat('!Ymd H:i', substr($digits, 0, 8) . ' ' . $time, new \DateTimeZone('Europe/Berlin'));
        return $value ? $value->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.v\Z') : null;
    }

    /** @param array<string,mixed> $state @param array<string,mixed> $body @return array<string,mixed> */
    private function saveRecord(array &$state, string $collection, array $body, ?string $id = null): array
    {
        $current = $id ? $this->required($state[$collection], $id, ucfirst($collection)) : [];
        if($collection==='events'){
            $body=TicketLinks::apply($body,$current);
            if($current&&EventLifecycle::effective($current)==='removed')throw new RuntimeException('Veranstaltung wurde gelöscht, weitere Daten sind nicht mehr verfügbar.',409);
            $status=$current?EventLifecycle::status($body['status'] ?? $current['status'] ?? 'draft'):'draft';
            if($status==='removed'){if(($this->identity['role'] ?? '')!=='admin')throw new RuntimeException('Löschen ist Administratoren vorbehalten.',403);$this->purgeEvent($state,(string)$id);return $this->required($state['events'],(string)$id,'Veranstaltung');}
            $body['status']=$status;$body['autoArchived']=false;$body['archivedAt']=$status==='archived'?($current['archivedAt'] ?? $this->now()):null;
            if(array_key_exists('advertisingVideo',$body))$body['advertisingVideo']=AdvertisingVideo::input($body['advertisingVideo']);
            if(array_key_exists('imageEdit',$body))$body['imageEdit']=EventImageEdit::normalize($body['imageEdit']);elseif(array_key_exists('imageUrl',$body)&&($body['imageUrl'] ?? '')!==($current['imageUrl'] ?? ''))$body['imageEdit']=null;}
        if(in_array($collection,['slides','templates'],true)&&isset($body['document']))$body['document']=AdvertisingService::stripOverviewRuntime($body['document']);
        if($collection==='locations'){
            $color=array_key_exists('playerBackgroundColor',$body)?$body['playerBackgroundColor']:($current['playerBackgroundColor'] ?? '#000000');
            if(!is_string($color)||!preg_match('/^#[0-9a-f]{6}$/i',$color))throw new RuntimeException('Die Display-Hintergrundfarbe muss eine sechsstellige Hex-Farbe sein, z. B. #000000.',422);
            $body['playerBackgroundColor']=strtolower($color);
        }
        if($collection==='presets'){
            $config=is_array($body['config'] ?? null)?$body['config']:($current['config'] ?? []);$this->presetSchedules($config);
            $sourceId=$id ?: $this->uuid();$body['id']=$sourceId;PresetTimerActions::assertGraph($state['presets'],$sourceId,$config);
        }
        if($collection==='channels'&&isset($body['items'])&&in_array($current['automationKey'] ?? '',['advertising:channel','advertising:channel:portrait'],true)){
            $orientation=$current['automationKey']==='advertising:channel:portrait'?'portrait':'landscape';
            $state['advertisingSettings']['channelSequences'][$orientation]=array_values(array_map(static fn(array $item):array=>array_intersect_key($item,array_flip(['slideId','durationSeconds','transition'])),array_filter($body['items'],static fn(array $item):bool=>empty($item['advertisingInterstitial']))));
        }
        if($collection==='channels'&&isset($body['items']))$body['items']= array_values(array_filter($body['items'],static fn(array $item):bool=>empty($item['advertisingInterstitial'])&&!str_starts_with((string)($item['slideId'] ?? ''),'advertising-event:')));
        if($collection==='schedules'){
            $merged=array_replace($current,$body);$type=$body['contentType'] ?? $merged['contentType'] ?? (!empty($merged['slideId'])?'slide':'channel');
            $contentId=$body['contentId'] ?? $body[$type.'Id'] ?? $merged['contentId'] ?? $merged[$type.'Id'] ?? '';
            $body=array_replace($body,['contentType'=>$type,'contentId'=>$contentId,'channelId'=>$type==='channel'?$contentId:null,'slideId'=>$type==='slide'?$contentId:null]);
        }
        if($collection==='warnings'&&PresetHandoff::source($body['source'] ?? $current['source'] ?? '')&&($body['status'] ?? '')==='active'&&!$current)$body['publishedAt']=(new \DateTimeImmutable('@'.QualityClock::now(),new \DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.u\Z');
        $record = $this->record(array_replace($current, $body), $id);
        if($collection==='displays'&&$current&&array_intersect_key($current,array_flip(['defaultContentType','defaultChannelId','defaultSlideId']))!==array_intersect_key($record,array_flip(['defaultContentType','defaultChannelId','defaultSlideId'])))PresetHandoff::releaseTargets($state,[['type'=>'display','id'=>$record['id']]]);
        if($collection==='schedules'&&($record['status'] ?? '')==='published'&&$this->scheduleActive($record,$this->now()))PresetHandoff::releaseTargets($state,[['type'=>$record['targetType'] ?? '', 'id'=>$record['targetId'] ?? '']]);
        $index = $this->index($state[$collection], $record['id']);
        if ($index === null) $state[$collection][] = $record; else $state[$collection][$index] = $record;
        if($collection==='displays')foreach($state['groups'] as &$group){
            $members=$group['displayIds'] ?? [];$included=in_array($record['id'],$members,true);$wanted=in_array($group['id'],$record['groupIds'] ?? [],true);
            if($included!==$wanted){$group['displayIds']=$wanted?[...$members,$record['id']]:array_values(array_diff($members,[$record['id']]));$group['updatedAt']=$this->now();}
        }
        unset($group);
        $this->audit($state, $collection . '.saved', (string)$record['id']);
        return $record;
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private function record(array $input, ?string $id = null): array
    {
        $now = $this->now();
        return array_replace(['id' => $id ?: $this->uuid(), 'createdAt' => $now], $input, ['id' => $id ?: ($input['id'] ?? $this->uuid()), 'updatedAt' => $now]);
    }

    /** @param array<string,mixed> $state @return array{0:int,1:array<string,mixed>,2:bool} */
    private function trashRecord(array &$state, string $collection, string $type, string $id): array
    {
        $record = $this->required($state[$collection], $id, ucfirst($type));
        $record['deletedAt'] = $this->now();
        $this->saveRecord($state, $collection, $record, $id);
        $state['trash'] = array_values(array_filter($state['trash'], fn(array $item): bool => !($item['type'] === $type && $item['id'] === $id)));
        $state['trash'][] = ['type' => $type, 'id' => $id, 'name' => $record['name'] ?? $record['title'] ?? $type, 'deletedAt' => $record['deletedAt'], 'deletedBy' => $this->identity['id']];
        return $this->ok(['ok' => true], true);
    }

    /** @param array<string,mixed> $state @return array{0:int,1:array<string,mixed>,2:bool} */
    private function restoreTrash(array &$state, string $collection, string $type, string $id): array
    {
        $record = $this->required($state[$collection], $id, ucfirst($type));
        $record['deletedAt'] = null;
        $this->saveRecord($state, $collection, $record, $id);
        $state['trash'] = array_values(array_filter($state['trash'], fn(array $item): bool => !($item['type'] === $type && $item['id'] === $id)));
        return $this->ok(['ok' => true], true);
    }

    /** @param array<string,mixed> $state @return array{0:int,1:array<string,mixed>,2:bool} */
    private function purgeTrash(array &$state, string $collection, string $type, string $id): array
    {
        if ($collection === 'channels') {
            $record = $this->required($state[$collection], $id, 'Kanal');
            if (empty($record['deletedAt'])) throw new RuntimeException('Kanal wurde im Papierkorb nicht gefunden.', 404);
        }
        $this->purgeRecord($state, $collection, $id);
        $state['trash'] = array_values(array_filter($state['trash'], fn(array $item): bool => !($item['type'] === $type && $item['id'] === $id)));
        return $this->ok(['ok' => true], true);
    }

    /** @param array<string,mixed> $state @return array{0:int,1:array<string,mixed>,2:bool} */
    private function deleteRecord(array &$state, string $collection, string $id): array
    {
        $this->purge($state[$collection], $id);
        return $this->ok(['ok' => true], true);
    }

    /** @param array<string,mixed> $state @return array{0:int,1:array<string,mixed>,2:bool} */
    private function restoreRecord(array &$state, string $collection, string $id): array
    {
        $record = $this->required($state[$collection], $id, ucfirst($collection));
        $record['deletedAt'] = null;
        $this->saveRecord($state, $collection, $record, $id);
        return $this->ok(['ok' => true], true);
    }

    /** @param array<string,mixed> $state @return array{0:int,1:array<string,mixed>,2:bool} */
    private function purgeRecord(array &$state, string $collection, string $id): array
    {
        $this->purge($state[$collection], $id);
        if ($collection === 'channels') $this->removeChannelReferences($state, $id);
        if($collection==='slides'){$state['slideVersions']=array_values(array_filter($state['slideVersions'],static fn(array $version):bool=>($version['slideId'] ?? '')!==$id));foreach($state['displays'] as &$display)if(($display['defaultSlideId'] ?? '')===$id)$display['defaultSlideId']=null;unset($display);}
        return $this->ok(['ok' => true], true);
    }

    /** Permanent deletion only: soft deletion must preserve assignments for restoration. */
    private function removeChannelReferences(array &$state, string $id): void
    {
        $state['schedules'] = array_values(array_filter($state['schedules'], static fn(array $item): bool =>
            ($item['channelId'] ?? '') !== $id && !(($item['contentType'] ?? '') === 'channel' && ($item['contentId'] ?? '') === $id)));
        $state['assignments'] = array_values(array_filter($state['assignments'], static fn(array $item): bool =>
            !(($item['content']['type'] ?? '') === 'channel' && ($item['content']['id'] ?? '') === $id)));
        foreach (['displays', 'matrices', 'proof'] as $collection) {
            foreach ($state[$collection] as &$item) {
                foreach (['defaultChannelId', 'channelId', 'currentChannelId'] as $field) {
                    if (($item[$field] ?? '') === $id) $item[$field] = null;
                }
            }
            unset($item);
        }
        foreach ($state['presets'] as &$preset) {
            if (($preset['channelId'] ?? '') === $id) $preset['channelId'] = null;
            if (is_array($preset['config']['channelUpdates'] ?? null)) {
                $preset['config']['channelUpdates'] = array_values(array_filter($preset['config']['channelUpdates'], static fn(mixed $item): bool => !is_array($item) || ($item['channelId'] ?? '') !== $id));
            }
            if (is_array($preset['config']['schedules'] ?? null)) $preset['config']['schedules']=array_values(array_filter($preset['config']['schedules'],static fn(mixed $item): bool=>!is_array($item)||!(($item['content']['type'] ?? '')==='channel'&&($item['content']['id'] ?? '')===$id)));
            if (is_array($preset['config']['assignments'] ?? null)) {
                $preset['config']['assignments'] = array_values(array_filter($preset['config']['assignments'], static fn(mixed $item): bool => !is_array($item) || !(($item['contentType'] ?? '') === 'channel' && ($item['contentId'] ?? '') === $id)));
            }
        }
        unset($preset);
        $state['trash'] = array_values(array_filter($state['trash'], static fn(array $item): bool => !(($item['type'] ?? '') === 'channel' && ($item['id'] ?? '') === $id)));
    }

    /** @param array<int,array<string,mixed>> $items */
    private function purge(array &$items, string $id): void
    {
        $before = count($items);
        $items = array_values(array_filter($items, fn(array $item): bool => $item['id'] !== $id));
        if (count($items) === $before) throw new RuntimeException('Element wurde nicht gefunden.', 404);
    }

    /** @param array<int,array<string,mixed>> $items @return array<int,array<string,mixed>> */
    private function active(array $items): array
    {
        return array_values(array_filter($items, fn(array $item): bool => empty($item['deletedAt']) && ($item['status'] ?? '') !== 'archived'));
    }

    /** @param array<int,array<string,mixed>> $items @return array<string,mixed> */
    private function required(array $items, string $id, string $label): array
    {
        $item = $this->first($items, fn(array $candidate): bool => $candidate['id'] === $id);
        if (!$item) throw new RuntimeException($label . ' wurde nicht gefunden.', 404);
        return $item;
    }

    /** @param array<int,array<string,mixed>> $items */
    private function index(array $items, string $id): ?int
    {
        foreach ($items as $index => $item) if (($item['id'] ?? '') === $id) return $index;
        return null;
    }

    /** @param array<int,array<string,mixed>> $items @param callable(array<string,mixed>):bool $predicate @return array<string,mixed>|null */
    private function first(array $items, callable $predicate): ?array
    {
        foreach ($items as $item) if ($predicate($item)) return $item;
        return null;
    }

    /** @param array<string,mixed> $state */
    private function audit(array &$state, string $action, string $entityId): void
    {
        $state['audit'][] = ['id' => $this->uuid(), 'actorType' => $this->identity['actorType'] ?? 'cms_user', 'actorId' => $this->identity['id'], 'action' => $action, 'entityId' => $entityId, 'requestId' => $this->identity['requestId'] ?? null, 'ipAddress' => $this->identity['ipAddress'] ?? null, 'createdAt' => $this->now()];
        $state['audit'] = array_slice($state['audit'], -500);
    }

    /** @return array<string,mixed> */
    private function user(): array
    {
        return [
            'id' => $this->identity['id'],
            'username' => $this->identity['email'],
            'email' => $this->identity['email'],
            'displayName' => $this->identity['name'],
            'role' => in_array($this->identity['role'], ['admin', 'editor', 'designer', 'viewer'], true) ? $this->identity['role'] : 'viewer',
            'status' => 'active',
            'mustChangePassword' => false,
            'qualityPermissions'=>$this->identity['qualityPermissions']??['history:slide'=>in_array($this->identity['role'],['admin','editor','designer'],true),'history:channel'=>in_array($this->identity['role'],['admin','editor'],true),'history:event'=>in_array($this->identity['role'],['admin','editor','designer'],true),'history:schedule'=>in_array($this->identity['role'],['admin','editor'],true),'simulation'=>in_array($this->identity['role'],['admin','editor'],true),'report'=>in_array($this->identity['role'],['admin','editor'],true),'check'=>in_array($this->identity['role'],['admin','editor','designer'],true)],
            'canManageCustomerContent'=>$this->canManageCustomerContent(),'canControlDisplays'=>$this->canControlPlayers(),'canManageDisplays'=>$this->canReadPlayerKeys(),
            'canManageSettings' => ($this->identity['canManageSettings'] ?? ($this->identity['role'] === 'admin')) === true,
        ];
    }

    /** @return array<string,mixed> */
    private function license(): LicenseClient{return $this->licenseClient ?? new LicenseClient();}
    public function runLicenseSync(): array{$state=$this->state();$changed=$this->refreshLicenseState($state);return ['ran'=>$changed,'status'=>$this->license()->status($state)];}

    /** One due renewal per installation; never write a stale request snapshot. */
    private function refreshLicenseState(array &$state): bool
    {
        $client=$this->license();if(!$client->isDue($state))return false;
        $path=sys_get_temp_dir().'/kiosky-license-'.$client->synchronizationKey($state).'.lock';
        $lock=@fopen($path,'c');if(!is_resource($lock))$lock=@fopen($path,'r');
        if(!is_resource($lock))return false;
        @chmod($path,0600);
        if(!flock($lock,LOCK_EX|LOCK_NB)){fclose($lock);return false;}
        try{
            for($attempt=0;$attempt<3;$attempt++){
                $fresh=$this->state();if(!$client->runDue($fresh)){$state=$fresh;return false;}
                try{$this->store->save($fresh);$state=$fresh;return true;}
                catch(StateConflict $error){if($attempt===2)throw $error;}
            }
            return false;
        }finally{flock($lock,LOCK_UN);fclose($lock);}
    }

    private function state(bool $migration = false): array
    {
        $stored = $migration && $this->store instanceof CmsMediaStateStore ? $this->store->loadForMigration() : $this->store->load();
        if (!array_key_exists('titleExclusions', $stored)) {
            $stored['titleExclusions'] = $stored['crewbrain']['config']['titleExclusions'] ?? [];
        }
        if(is_array($stored['publicCalendarSettings'] ?? null))$stored['publicCalendarSettings']=PublicEventCalendar::normalizeSettings($stored['publicCalendarSettings']);
        return array_replace_recursive($this->defaults(), $stored);
    }

    /** @return array<int,string> */
    private function normalizeNavigationOrder(mixed $value): array
    {
        $defaults = ['dashboard', 'events', 'displays', 'channels', 'menus', 'advertising', 'media', 'schedule', 'operations', 'integrations', 'updates', 'settings', 'users'];
        $requested = is_array($value) ? array_values(array_filter(array_map('strval', $value), static fn(string $key): bool => in_array($key, $defaults, true))) : [];
        return array_values(array_unique(array_merge($requested, $defaults)));
    }

    /** @return array<string,mixed> */
    private function defaults(): array
    {
        $now = $this->now();
        return [
            'schemaVersion' => 1, 'createdAt' => $now, 'updatedAt' => $now,
            'menuAccess' => [], 'events' => [], 'eventSchedules' => [], 'slides' => [], 'slideVersions' => [], 'channels' => [], 'templates' => [],
            'mediaFolders' => [], 'mediaAssets' => [], 'presets' => [], 'displays' => [], 'groups' => [],
            'locations' => [], 'matrices' => [], 'schedules' => [], 'scheduleTargetOrder' => [], 'trash' => [],
            'warnings' => [], 'proof' => [], 'commands' => [], 'assignments' => [], 'presetExecutions' => [], 'presetTriggers' => [], 'presetTriggerRuns' => [], 'playerPairings' => [], 'audit' => [], 'dwd' => [],
            'featureSettings' => ['dashboard' => true, 'events' => true, 'displays' => true, 'channels' => true, 'menus' => true, 'advertising' => true, 'media' => true, 'schedule' => true, 'operations' => true, 'integrations' => true, 'updates' => true, 'settings' => true, 'users' => true, 'content' => true, 'presets_warnings' => true],
            'navigationOrder' => ['dashboard', 'events', 'displays', 'channels', 'menus', 'advertising', 'media', 'schedule', 'operations', 'integrations', 'updates', 'settings', 'users'],
            'publicCalendarSettings' => PublicEventCalendar::DEFAULTS,
            'activeEventSource' => null,
            'portableUsers' => [], 'portableApiUsers' => [], 'apiUsers' => [],
            'titleExclusions' => [],
            'warningTemplates' => [[
                'id' => 'warning-template-info', 'name' => 'Wichtige Information', 'warningType' => 'info',
                'description' => 'Allgemeiner Hinweis', 'priority' => 700, 'status' => 'active',
                'document' => ['title' => 'Wichtige Information', 'instructions' => 'Bitte beachten Sie die Hinweise.', 'backgroundColor' => '#17342b', 'textColor' => '#ffffff'],
                'createdAt' => $now, 'updatedAt' => $now,
            ]],
            'crewbrain' => [
                'config' => ['baseUrl' => '', 'documentationUrl' => '', 'authType' => 'api_key', 'syncEnabled' => false, 'syncIntervalMinutes' => 1440, 'autoImportTime' => '03:00', 'lookbackDays' => 30, 'lookaheadDays' => 365, 'pageSize' => 100, 'importStrategy' => 'project', 'titleExclusions' => [], 'autoCreateChannels' => false, 'autoCreateSlides' => false],
                'mapping' => CrewBrainService::DEFAULT_MAPPING,
                'syncLogs' => [],
            ],
            'easyjob' => [
                'config' => ['baseUrl' => '', 'allowInsecureHttp' => false, 'allowSelfSignedCertificate' => false, 'syncEnabled' => false, 'autoImportTime' => '03:00', 'lookbackDays' => 30, 'lookaheadDays' => 365, 'pageSize' => 100, 'importMode' => 'projects_with_jobs', 'autoCreateChannels' => true],
                'mapping' => EasyJobService::DEFAULT_MAPPING,
                'syncLogs' => [],
            ],
        ];
    }

    /** @param array<string,mixed> $state @return array<string,mixed> */
    private function integrationSources(array $state): array
    {
        $active=in_array($state['activeEventSource'] ?? null,['crewbrain','easyjob'],true)?$state['activeEventSource']:null;
        if($active&&!$this->license()->allows($state,'integrations',$active))$active=null;
        $sources=['crewbrain'=>['enabled'=>$active==='crewbrain','configured'=>!empty($state['crewbrain']['config']['encryptedCredential'])],'easyjob'=>['enabled'=>$active==='easyjob','configured'=>!empty($state['easyjob']['config']['encryptedCredentials'])]];
        return ['activeSource'=>$active,'sources'=>array_filter($sources,fn(string $source):bool=>$this->license()->allows($state,'integrations',$source),ARRAY_FILTER_USE_KEY)];
    }

    /** @param array<string,mixed> $state @return array<int,string> */
    private function titleExclusions(array $state): array
    {
        return $this->normalizeTitleExclusions($state['titleExclusions'] ?? ($state['crewbrain']['config']['titleExclusions'] ?? []));
    }

    /** @return array<int,string> */
    private function normalizeTitleExclusions(mixed $value): array
    {
        $entries = is_array($value) ? $value : [];
        $normalized = array_values(array_unique(array_filter(array_map(
            static fn(mixed $entry): string => trim(is_string($entry) ? $entry : ''),
            $entries
        ))));
        if (count($normalized) > 100 || array_filter($normalized, static fn(string $entry): bool => strlen($entry) > 80)) {
            throw new RuntimeException('Die Titel-Ausschlussliste darf höchstens 100 Einträge mit jeweils 80 Zeichen enthalten.', 422);
        }
        return $normalized;
    }

    /** @param array<int,string> $exclusions */
    private function matchingTitleExclusion(string $title, array $exclusions): ?string
    {
        foreach ($exclusions as $exclusion) if (str_contains($title, $exclusion)) return $exclusion;
        return null;
    }

    /** @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function ok(array $body, bool $changed = false): array { return [200, $body, $changed]; }
    /** @param array<string,mixed> $body @return array{0:int,1:array<string,mixed>,2:bool} */
    private function created(array $body): array { return [201, $body, true]; }
    private function now(): string { return gmdate('c',QualityClock::now()); }
    private function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }
}
