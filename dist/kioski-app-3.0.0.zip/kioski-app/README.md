# Kiosky 3.0.0

Webbasiertes Digital-Signage-System für Veranstaltungen, Displays, Displaygruppen, Standorte, Matrix-Displays, Kanäle, Slides, Zeitpläne und Warnhinweise.

Copyright © 2026 Sören Elvers. Lizenzzuordnung und Nutzungsbedingungen:
[LICENSE.md](LICENSE.md).

Die Architektur und API für Veranstaltungsabläufe und easyjob-Raumnutzungen ist in [docs/event-schedule.md](docs/event-schedule.md) beschrieben.

## Enthalten

- Dashboard für den täglichen Veranstaltungsbetrieb
- Veranstaltungsübersicht mit importierter Datenquelle
- Displayverwaltung mit festen Display-URLs
- Displays anlegen und bearbeiten, Player-URL kopieren, direkt öffnen oder als Vollbild-Player für Windows (32/64 Bit), Ubuntu/Debian (64 Bit) und macOS (Apple Silicon/Intel) installieren
- eigenständige Vollbild-Playeransicht je Display-URL
- Display-Gruppen anlegen, bearbeiten und löschen
- Slide-Bibliothek mit Veranstaltung, Text, Bild, Video, Website und PDF als Inhaltstypen
- visueller Slide-Editor mit frei positionierbaren Text-, Bild-, Video-, Website- und Eventelementen
- Bild- und Video-Upload sowie Einbindung externer Medien- und Website-URLs
- Kanal-Builder mit Drag-and-drop-Reihenfolge und individueller Slide-Dauer
- Standardübergang pro Kanal und abweichender Übergang zwischen einzelnen Slides
- umschaltbarer Tages-, Wochen- und Monatsplan mit Drag-and-drop-Zeitsteuerung
- direkte Planung von Kanälen und einzelnen Slides, einschließlich Stapelung und Verschieben zwischen Zielzeilen
- gleichzeitige Zuweisung an mehrere Displays und Display-Gruppen
- Prioritäten, Laufzeiten und tägliche oder wöchentliche Wiederholungen im Zeitplan
- Konfliktschutz: höher priorisierte Ausspielungen werden nicht versehentlich überschrieben
- Betriebszentrale mit Player-Heartbeat, Online-/Offline-Zustand und Cache-Bereitschaft
- Fernaktionen zum Synchronisieren und Neuladen einzelner Player
- gezielte Warnhinweise für Display-Gruppen oder einzelne Displays
- automatische Rückkehr zum regulären Kanal nach Ende einer Notfallmeldung
- schlankes strukturiertes Betriebslog für Serverstart, Fehler und langsame Anfragen
- normalisierte Standortverwaltung und Matrix-Displays
- zentraler Papierkorb mit Wiederherstellung
- providerunabhängige Warnhinweise und zehn editierbare Vorlagen
- CrewBrain und easyjob parallel als auswählbare Veranstaltungsdatenquellen mit eigener Feldzuordnung, Importvorschau sowie manuellem und automatischem Import
- Webkonfiguration für CrewBrain-Verbindung, manuelle Token-Eingabe oder einmaligen Token-Abruf per CrewBrain-Login, Sync-Regeln, Feldzuordnung, Verbindungstest und Importvorschau
- sicherer Admin-Login, einmalige Ersteinrichtung, Benutzerverwaltung und Rollen für Administratoren, Redakteure und Betrachter
- Einladungs-E-Mails direkt über eine HTTPS-API, ohne eigenen SMTP-Server
- responsive Darstellung für Desktop, Tablet und Smartphone
- additives Node.js-/TypeScript-Backend mit SQLite-Migrationen
- serverseitiger, aus der offiziellen OpenAPI typisierter CrewBrain-v2-Client
- konfigurierbare CrewBrain-Basis-URL und Authentifizierungsart
- verschlüsselte Speicherung von CrewBrain-Zugangsdaten
- Verbindungstest mit unterscheidbaren Fehlerzuständen
- read-only Importvorschau mit Zeitraum-, Status- und Suchfiltern
- providerunabhängige Veranstaltungsquellen-Abstraktion
- Audit-Log für CrewBrain-Konfiguration, Tests und Vorschauen

## Lokale Entwicklung

Für die reine Frontend-Vorschau kann `index.html` weiterhin direkt geöffnet werden. Für Backend, Datenbank und CrewBrain-Integration:

```sh
pnpm install
cp .env.example .env
pnpm db:migrate
pnpm dev
```

Anschließend ist Kiosky standardmäßig unter `http://127.0.0.1:8080` erreichbar. Beim ersten Aufruf führt die Oberfläche durch das Anlegen des ersten Administrators. `KIOSKY_ENCRYPTION_KEY` muss für externe Zugangsdaten sicher gesetzt werden; `KIOSKY_ADMIN_API_KEY` ist nur noch für optionale Maschinenzugriffe erforderlich. Weitere Hinweise stehen in [docs/development.md](docs/development.md).

## Plesk

Für Plesk wird Node.js 24 LTS empfohlen. Als Anwendungsstamm dient das Repository, als Dokumentenstamm dessen Unterordner `public` und als Anwendungsstartdatei `server.js`. Nach der NPM-Installation muss einmal das Skript `build` ausgeführt werden. Kiosky übernimmt automatisch den von Plesk bereitgestellten `PORT`; dieser darf nicht als eigene Umgebungsvariable überschrieben werden. Die vollständige Einrichtung steht in [docs/plesk.md](docs/plesk.md).

## Standalone, WordPress und TYPO3

Kiosky wird weiterhin einmal als Standalone-Kern entwickelt. Ein gemeinsamer
Plattform-Build erzeugt daraus versionierte Pakete für Standalone, WordPress und
TYPO3:

```sh
pnpm build:platforms
```

Die ZIP-Dateien werden unter `artifacts/` ausgegeben. WordPress und TYPO3 enthalten
jeweils eine eigenständige CMS-Laufzeit mit lokaler Datenhaltung, CMS-Anmeldung,
API und Player. Oberfläche und PHP-Domainkern werden aus gemeinsamen Quellen gebaut.
Architektur, Installation und Grenzen sind in
[docs/platform-distributions.md](docs/platform-distributions.md) beschrieben.

Die TYPO3-Extension wird über den automatisch erzeugten Composer-Mirror installiert:

```sh
composer require casesound/kiosky
vendor/bin/typo3 extension:setup
vendor/bin/typo3 cache:flush
```

TYPO3 13.4 LTS ist die bevorzugte Zielversion. Architektur, Migration, Rechte,
Display-API und Releases sind unter [Documentation](Documentation/) dokumentiert.

## Player Center

Die laufende Kiosky-Instanz stellt unter `/player` ein öffentliches Player
Center bereit. Dort können Browser-, Windows-, Linux- und macOS-Universal-Player
gestartet beziehungsweise heruntergeladen werden. Beim ersten Start erscheint
ein kurzlebiger sechsstelliger Code, mit dem der Player im Backend einem Display
zugeordnet wird. Alternativ kann am gewünschten Display direkt ein bereits
zugeordneter Windows-, Linux- oder macOS-Player heruntergeladen werden. Der
macOS-Download enthält eine `.app` in einem ZIP-Archiv. Da die Display-URL
individuell in die App eingebettet wird, ist sie nicht mit einem Apple-
Entwicklerzertifikat signiert und muss beim ersten Start gegebenenfalls über
**Rechtsklick → Öffnen** bestätigt werden.

Die Player-Center-URLs lauten:

- Standalone: `/player`
- WordPress: `/player` (compatibility alias: `/kiosky-player-center/`)
- TYPO3: `/player` (compatibility alias: `/kiosky-player-center/`)

Der jeweilige Browser-Player ist unter `/player/browser.html` (Standalone)
beziehungsweise `/kiosky-player-browser/` (WordPress und TYPO3) erreichbar.

Die Universal-Binary-Vorlage für Apple Silicon und Intel lässt sich auf macOS
mit installierten Command Line Tools neu erzeugen:

```sh
pnpm build:player:macos
```

## CrewBrain API v2

Die Swagger-Seite der Entwicklungsinstanz lädt eine OpenAPI-3.0-Spezifikation der Version 2.339. Kiosky erzeugt daraus TypeScript-Typen. Details zu Endpunkten, Authentifizierung, Pagination, Feldern und Einschränkungen stehen in [docs/crewbrain-api-analysis.md](docs/crewbrain-api-analysis.md). Die aktuelle Admin-API ist in [docs/api.md](docs/api.md) beschrieben.

## Aktueller Stand

Standalone, WordPress und TYPO3 besitzen jeweils eine serverseitige, dauerhafte
Datenhaltung. Die CMS-Pakete laufen ohne Standalone-Server und übernehmen Anmeldung,
Benutzer- und Medienverwaltung aus dem jeweiligen CMS. CrewBrain- und easyjob-Livetest,
Tokenabruf, Vorschau, manueller und automatischer Import, DWD-Warnungen,
Zeitplanung, Matrix-Wiedergabe und externe Steuerung sind auch in
den CMS-Ausgaben integriert. Der gemeinsame Release-Workflow prüft TypeScript und
PHP und erzeugt drei installierbare ZIP-Dateien.
