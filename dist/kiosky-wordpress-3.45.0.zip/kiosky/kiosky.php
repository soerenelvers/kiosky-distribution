<?php
/**
 * Plugin Name: Kiosky
 * Description: Eigenständiges Digital-Signage-System für WordPress.
 * Version: 3.45.0
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Update URI: https://api.github.com/repos/soerenelvers/kiosky-distribution/contents/latest.json?ref=main
 * Author: Sören Elvers
 * License: GPL-2.0-or-later
 * Copyright: © 2026 Sören Elvers
 * Text Domain: kiosky
 */

defined('ABSPATH') || exit;

const KIOSKY_PLUGIN_VERSION = '3.45.0';
const KIOSKY_VERSION = '3.45.0';
const KIOSKY_UPDATE_MANIFEST_URL = 'https://api.github.com/repos/soerenelvers/kiosky-distribution/contents/latest.json?ref=main';

require_once __DIR__ . '/includes/Core/StateStore.php';
require_once __DIR__ . '/includes/Core/PlaybackProof.php';
require_once __DIR__ . '/includes/WordPressProofStore.php';
require_once __DIR__ . '/includes/Core/MediaLibrary.php';
require_once __DIR__ . '/includes/Core/MediaUpload.php';
require_once __DIR__ . '/includes/Core/CmsMediaStateStore.php';
require_once __DIR__ . '/includes/WordPressMediaLibrary.php';
require_once __DIR__ . '/includes/Core/HttpClient.php';
require_once __DIR__ . '/includes/Core/Crypto.php';
require_once __DIR__ . '/includes/Core/CrewBrainService.php';
require_once __DIR__ . '/includes/Core/EasyJobService.php';
require_once __DIR__ . '/includes/Core/DwdService.php';
require_once __DIR__ . '/includes/Core/TransferService.php';
require_once __DIR__ . '/includes/Core/ContentPackage.php';
require_once __DIR__ . '/includes/Core/PublicEventCalendar.php';
require_once __DIR__ . '/includes/Core/StateConflict.php';
require_once __DIR__ . '/includes/Core/ApiAccess.php';
require_once __DIR__ . '/includes/Core/ExternalRequest.php';
require_once __DIR__ . '/includes/Core/PlayerLauncher.php';
require_once __DIR__ . '/includes/Core/AdvertisingService.php';
require_once __DIR__ . '/includes/Core/MenuContent.php';
require_once __DIR__ . '/includes/Core/MenuShare.php';
require_once __DIR__ . '/includes/Core/MenuWebPdf.php';
require_once __DIR__ . '/includes/Core/MenuSubscriptions.php';
require_once __DIR__ . '/includes/Core/Api.php';
require_once __DIR__ . '/includes/WordPressStateStore.php';
require_once __DIR__ . '/includes/WordPressHttpClient.php';
require_once __DIR__ . '/includes/Updater.php';

Kiosky\WordPress\Updater::register(__FILE__, KIOSKY_UPDATE_MANIFEST_URL, KIOSKY_PLUGIN_VERSION);

function kiosky_register_roles(): void {
    add_role('kiosky_administrator', __('Kiosky Administrator', 'kiosky'), [
        'read' => true, 'kiosky_access' => true, 'kiosky_edit' => true, 'kiosky_admin' => true,
    ]);
    add_role('kiosky_editor', __('Kiosky Redakteur', 'kiosky'), [
        'read' => true, 'kiosky_access' => true, 'kiosky_edit' => true,
    ]);
    add_role('kiosky_designer', __('Kiosky Mediengestalter', 'kiosky'), ['read'=>true,'kiosky_access'=>true,'kiosky_design'=>true,'upload_files'=>true]);
    add_role('kiosky_viewer', __('Kiosky Betrachter', 'kiosky'), [
        'read' => true, 'kiosky_access' => true,
    ]);

    foreach (['kiosky_administrator', 'kiosky_editor', 'kiosky_designer'] as $slug) {
        $role = get_role($slug);
        if ($role) {
            foreach (['upload_files'] as $capability) $role->add_cap($capability);
        }
    }

    foreach (wp_roles()->roles as $slug => $definition) {
        $role = get_role($slug);
        if (!$role) continue;
        if (!empty($definition['capabilities']['manage_options'])) {
            $role->add_cap('kiosky_access');
            $role->add_cap('kiosky_edit');
            $role->add_cap('kiosky_admin');
        } elseif (!empty($definition['capabilities']['edit_posts'])) {
            $role->add_cap('kiosky_access');
            $role->add_cap('kiosky_edit');
        } elseif ($slug === 'subscriber') {
            $role->add_cap('kiosky_access');
        }
    }
}

/** @return 'admin'|'editor'|'viewer'|null */
function kiosky_current_role(): ?string {
    if (!is_user_logged_in() || !current_user_can('kiosky_access')) return null;
    if (current_user_can('kiosky_admin')) return 'admin';
    if (current_user_can('kiosky_edit')) return 'editor';
    if (current_user_can('kiosky_design')) return 'designer';
    return 'viewer';
}

function kiosky_activate(): void {
    kiosky_register_roles();
    add_rewrite_rule('^speisekarten/?$', 'index.php?kiosky_app=menus', 'top');
    add_rewrite_rule('^kiosky-player/?$', 'index.php?kiosky_app=player', 'top');
    add_rewrite_rule('^kiosky-player-update/?$', 'index.php?kiosky_app=player-update', 'top');
    add_rewrite_rule('^kiosky-player-center/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^player/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^kiosky-player-browser/?$', 'index.php?kiosky_app=player-browser', 'top');
    add_rewrite_rule('^kiosky-player-download/([^/]+)/?$', 'index.php?kiosky_app=player-download&kiosky_player_platform=$matches[1]', 'top');
    $event=wp_get_scheduled_event('kiosky_scheduled_tasks');
    if($event && $event->schedule!=='kiosky_minute')wp_clear_scheduled_hook('kiosky_scheduled_tasks');
    if (!wp_next_scheduled('kiosky_scheduled_tasks')) {
        wp_schedule_event(time() + 60, 'kiosky_minute', 'kiosky_scheduled_tasks');
    }
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'kiosky_activate');
add_action('init', 'kiosky_register_roles');
add_action('init', [Kiosky\WordPress\WordPressMediaLibrary::class, 'register']);
add_filter('map_meta_cap', static function (array $caps, string $cap, int $userId, array $args): array {
    if (in_array($cap, ['edit_post', 'delete_post'], true) && !empty($args[0]) && get_post_type((int)$args[0]) === 'attachment') {
        $user = get_userdata($userId);
        $post = get_post((int)$args[0]);
        if ($user && in_array('kiosky_administrator', $user->roles, true)) return ['kiosky_admin'];
        if ($user && in_array('kiosky_editor', $user->roles, true) && (int)$post->post_author === $userId) return ['kiosky_edit'];
    }
    return $caps;
}, 10, 4);
function kiosky_deactivate(): void {
    wp_clear_scheduled_hook('kiosky_scheduled_tasks');
    wp_clear_scheduled_hook('kiosky_preset_triggers');
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'kiosky_deactivate');

add_filter('cron_schedules', static function (array $schedules): array {
    $schedules['kiosky_minute'] = ['interval'=>60,'display'=>__('Jede Minute (Kiosky)','kiosky')];
    $schedules['kiosky_15_minutes'] = ['interval' => 15 * MINUTE_IN_SECONDS, 'display' => __('Alle 15 Minuten (Kiosky)', 'kiosky')];
    return $schedules;
});

function kiosky_rewrite_rules(): void {
    add_rewrite_rule('^speisekarten/?$', 'index.php?kiosky_app=menus', 'top');
    add_rewrite_rule('^kiosky-player/?$', 'index.php?kiosky_app=player', 'top');
    add_rewrite_rule('^kiosky-player-update/?$', 'index.php?kiosky_app=player-update', 'top');
    add_rewrite_rule('^kiosky-player-center/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^player/?$', 'index.php?kiosky_app=player-center', 'top');
    add_rewrite_rule('^kiosky-player-browser/?$', 'index.php?kiosky_app=player-browser', 'top');
    add_rewrite_rule('^kiosky-player-download/([^/]+)/?$', 'index.php?kiosky_app=player-download&kiosky_player_platform=$matches[1]', 'top');
}
add_action('init', 'kiosky_rewrite_rules');
add_action('init', static function (): void {
    if(get_option('kiosky_player_update_routes','')!=='1'){
        flush_rewrite_rules(false);
        update_option('kiosky_player_update_routes','1',false);
    }
});
add_action('init', static function (): void {
    $event=wp_get_scheduled_event('kiosky_scheduled_tasks');
    if($event && $event->schedule!=='kiosky_minute')wp_clear_scheduled_hook('kiosky_scheduled_tasks');
    if (!wp_next_scheduled('kiosky_scheduled_tasks')) {
        wp_schedule_event(time() + 60, 'kiosky_minute', 'kiosky_scheduled_tasks');
    }
});
add_filter('query_vars', static function (array $vars): array {
    $vars[] = 'kiosky_app';
    $vars[] = 'kiosky_player_platform';
    return $vars;
});

function kiosky_register_menu(): void {
    add_menu_page(
        __('Kiosky', 'kiosky'),
        __('Kiosky', 'kiosky'),
        'kiosky_access',
        'kiosky',
        'kiosky_render_admin_page',
        'dashicons-welcome-widgets-menus',
        58
    );
    $items = [
        ['kiosky', __('Übersicht', 'kiosky'), 'kiosky_access'],
        ['kiosky-events', __('Veranstaltungen', 'kiosky'), 'kiosky_access'],
        ['kiosky-displays', __('Displays', 'kiosky'), 'kiosky_access'],
        ['kiosky-content', __('Slides & Kanäle', 'kiosky'), 'kiosky_access'],
        ['kiosky-advertising', __('Werbung', 'kiosky'), 'kiosky_access'],
        ['kiosky-menus', __('Speisekarten', 'kiosky'), 'kiosky_access'],
        ['kiosky-schedule', __('Zeitplanung', 'kiosky'), 'kiosky_access'],
        ['kiosky-operations', __('Presets & Warnhinweise', 'kiosky'), 'kiosky_edit'],
        ['kiosky-integrations', __('Schnittstellen', 'kiosky'), 'kiosky_admin'],
        ['kiosky-update-center', __('Updates', 'kiosky'), 'kiosky_admin'],
        ['kiosky-settings', __('Einstellungen', 'kiosky'), 'kiosky_admin'],
    ];
    $menuState = (new Kiosky\WordPress\WordPressStateStore())->load();
    $menuUserId = 'wp:' . get_current_user_id();
    $license=new Kiosky\Core\LicenseClient(new Kiosky\Core\Crypto(wp_salt('auth').wp_salt('secure_auth')),'wordpress',KIOSKY_PLUGIN_VERSION);
    $moduleMap=['kiosky'=>'dashboard','kiosky-events'=>'events','kiosky-displays'=>'displays','kiosky-content'=>'channels','kiosky-advertising'=>'advertising','kiosky-menus'=>'menus','kiosky-schedule'=>'schedule','kiosky-operations'=>'operations','kiosky-integrations'=>'integrations','kiosky-update-center'=>'updates'];
    $items=array_filter($items,static fn(array $item):bool=>!isset($moduleMap[$item[0]])||$license->allows($menuState,$moduleMap[$item[0]]));
    if(current_user_can('kiosky_design')&&!current_user_can('kiosky_edit'))$items=array_filter($items,static fn(array $item):bool=>in_array($item[0],['kiosky','kiosky-events','kiosky-content','kiosky-menus'],true));
    $items = array_filter($items, static fn(array $item): bool => $item[0] !== 'kiosky-advertising' || ($menuState['featureSettings']['advertising'] ?? true) !== false);
    $items = array_filter($items, static fn(array $item): bool => $item[0] !== 'kiosky-menus' || (($menuState['featureSettings']['menus'] ?? true) !== false && (current_user_can('kiosky_admin') || !empty($menuState['menuAccess'][$menuUserId]['enabled']))));
    foreach ($items as [$slug, $label, $capability]) {
        add_submenu_page('kiosky', $label, $label, $capability, $slug, 'kiosky_render_admin_page');
    }
}
add_action('admin_menu', 'kiosky_register_menu');

function kiosky_enqueue_media_picker(): void {
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    $pages = ['kiosky', 'kiosky-events', 'kiosky-displays', 'kiosky-content', 'kiosky-advertising', 'kiosky-menus', 'kiosky-schedule', 'kiosky-operations', 'kiosky-integrations', 'kiosky-update-center', 'kiosky-settings'];
    if (!in_array($page, $pages, true) || (!current_user_can('kiosky_edit') && !current_user_can('kiosky_design')) || !current_user_can('upload_files')) return;
    // Open the native modal in the WordPress parent document, above the app iframe.
    wp_enqueue_media();
    wp_enqueue_script('kiosky-wordpress-media', plugin_dir_url(__FILE__) . 'assets/wordpress-media.js', ['media-views'], KIOSKY_PLUGIN_VERSION, true);
}
add_action('admin_enqueue_scripts', 'kiosky_enqueue_media_picker');
function kiosky_enqueue_frame_layout():void {
    $page=isset($_GET['page'])?sanitize_key(wp_unslash($_GET['page'])):'';
    if(($page==='kiosky'||str_starts_with($page,'kiosky-'))&&current_user_can('kiosky_access'))wp_enqueue_script('kiosky-frame-layout',plugin_dir_url(__FILE__).'assets/frame-layout.js',[],KIOSKY_PLUGIN_VERSION,true);
}
add_action('admin_enqueue_scripts','kiosky_enqueue_frame_layout');


function kiosky_view_for_admin_page(string $page): string {
    return [
        'kiosky' => 'dashboard',
        'kiosky-events' => 'events',
        'kiosky-displays' => 'displays',
        'kiosky-content' => 'channels',
        'kiosky-advertising' => 'advertising',
        'kiosky-menus' => 'menus',
        'kiosky-schedule' => 'schedule',
        'kiosky-operations' => 'operations',
        'kiosky-integrations' => 'integrations',
        'kiosky-update-center' => 'updates',
        'kiosky-settings' => 'settings',
    ][$page] ?? 'dashboard';
}

function kiosky_render_admin_page(): void {
    if (!current_user_can('kiosky_access')) wp_die(esc_html__('Keine Berechtigung.', 'kiosky'));
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : 'kiosky';
    $url = add_query_arg(['action' => 'kiosky_app', 'view' => kiosky_view_for_admin_page($page)], admin_url('admin-post.php'));
    echo '<style>.kiosky-admin-frame-wrap{margin:0 0 0 -20px}.kiosky-admin-frame{display:block;width:100%;height:calc(100vh - var(--wp-admin--admin-bar--height,32px));height:calc(100dvh - var(--wp-admin--admin-bar--height,32px));min-height:0;border:0;background:#fff}@media(max-width:782px){.kiosky-admin-frame-wrap{margin-left:-10px}.kiosky-admin-frame{height:calc(100dvh - var(--wp-admin--admin-bar--height,46px))}}</style><div class="wrap kiosky-admin-frame-wrap">';
    printf(
        '<iframe class="kiosky-admin-frame" src="%1$s" title="Kiosky"></iframe>',
        esc_url($url)
    );
    echo '</div>';
}

function kiosky_admin_app(): void {
    if (!current_user_can('kiosky_access')) wp_die(esc_html__('Keine Berechtigung.', 'kiosky'), 403);
    $view = isset($_GET['view']) ? sanitize_key(wp_unslash($_GET['view'])) : 'dashboard';
    $allowed = ['dashboard', 'events', 'displays', 'channels', 'menus', 'schedule', 'operations', 'integrations', 'updates', 'settings'];
    $role = kiosky_current_role();
    if ($role !== 'admin') $allowed = array_diff($allowed, ['integrations', 'settings']);
    if ($role === 'viewer') $allowed = array_diff($allowed, ['operations']);
    kiosky_output_app(false, in_array($view, $allowed, true) ? $view : 'dashboard');
}
add_action('admin_post_kiosky_app', 'kiosky_admin_app');

function kiosky_public_app(): void {
    $app = (string)get_query_var('kiosky_app');
    // Public player updates also work with plain permalinks and before a saved
    // rewrite table is refreshed. Handle the exact reserved site-relative path.
    $updatePath=rtrim((string)parse_url(home_url('/kiosky-player-update'),PHP_URL_PATH),'/');
    if(rtrim((string)parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),'/')===$updatePath)kiosky_output_player_update();
    $menuPath = rtrim((string)parse_url(home_url('/speisekarten'),PHP_URL_PATH),'/');
    if ($app === 'menus' || rtrim((string)parse_url($_SERVER['REQUEST_URI'] ?? '',PHP_URL_PATH),'/') === $menuPath) {
        if (isset($_GET['freigabe']) && is_string($_GET['freigabe']) && $_GET['freigabe'] !== '') kiosky_output_app(true,'menus',true);
        auth_redirect();
        if (!current_user_can('kiosky_access')) wp_die(esc_html__('Keine Kiosky-Berechtigung.', 'kiosky'),403);
        kiosky_output_app(false,'menus',true);
    }
    if ($app === 'player') kiosky_output_app(true, 'dashboard');
    if ($app === 'player-center') kiosky_output_player_portal('index');
    if ($app === 'player-browser') kiosky_output_player_portal('browser');
    if ($app === 'player-update') kiosky_output_player_update();
    if ($app === 'player-download') kiosky_output_player_download((string)get_query_var('kiosky_player_platform'));
}
add_action('template_redirect', 'kiosky_public_app', 0);

/**
 * Theme-neutrale Website-Ausgabe. Beispiel:
 * [kiosky_event_calendar upcoming="15" show_search="true" show_upcoming="true"]
 *
 * @param array<string,mixed> $attributes
 */
function kiosky_event_calendar_shortcode(array $attributes = []): string {
    $attributes = shortcode_atts([
        'title' => '',
        'upcoming_title' => '',
        'upcoming' => '',
        'show_search' => '',
        'show_upcoming' => '',
        'view'=>'','color_mode'=>'','accent_color'=>'','accent_text_color'=>'','control_background'=>'','control_text_color'=>'','control_border_color'=>'',
        'show_time'=>'','show_location'=>'','show_category'=>'','show_organizer'=>'','show_description'=>'','show_status'=>'','show_tickets'=>'','show_remaining_tickets'=>'','show_details'=>'','show_subtitle'=>'','show_admission'=>'','show_break'=>'','show_end_time'=>'','show_image'=>'','show_public_notes'=>'','show_box_office'=>'','show_setup_time'=>'','show_event_number'=>'','allow_view_switch'=>'',
    ], $attributes, 'kiosky_event_calendar');
    $overrides = [
        'title' => sanitize_text_field((string)$attributes['title']),
        'upcomingTitle' => sanitize_text_field((string)$attributes['upcoming_title']),
        'upcomingCount' => $attributes['upcoming'] === '' ? null : (int)$attributes['upcoming'],
        'showSearch' => $attributes['show_search'] === '' ? null : filter_var($attributes['show_search'], FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE),
        'showUpcoming' => $attributes['show_upcoming'] === '' ? null : filter_var($attributes['show_upcoming'], FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE),
    ];
    foreach(['view'=>'view','color_mode'=>'colorMode','accent_color'=>'accentColor','accent_text_color'=>'accentTextColor','control_background'=>'controlBackground','control_text_color'=>'controlTextColor','control_border_color'=>'controlBorderColor'] as $attribute=>$key)if($attributes[$attribute]!=='')$overrides[$key]=sanitize_text_field((string)$attributes[$attribute]);
    foreach(['show_time'=>'showTime','show_location'=>'showLocation','show_category'=>'showCategory','show_organizer'=>'showOrganizer','show_description'=>'showDescription','show_status'=>'showStatus','show_tickets'=>'showTickets','show_remaining_tickets'=>'showRemainingTickets','show_details'=>'showDetails','show_subtitle'=>'showSubtitle','show_admission'=>'showAdmission','show_break'=>'showBreak','show_end_time'=>'showEndTime','show_image'=>'showImage','show_public_notes'=>'showPublicNotes','show_box_office'=>'showBoxOffice','show_setup_time'=>'showSetupTime','show_event_number'=>'showEventNumber','allow_view_switch'=>'allowViewSwitch'] as $attribute=>$key)if($attributes[$attribute]!=='')$overrides[$key]=filter_var($attributes[$attribute],FILTER_VALIDATE_BOOL,FILTER_NULL_ON_FAILURE);
    wp_enqueue_style('kiosky-event-calendar', plugin_dir_url(__FILE__) . 'assets/event-calendar/calendar.css', [], KIOSKY_PLUGIN_VERSION);
    wp_enqueue_script('kiosky-event-calendar', plugin_dir_url(__FILE__) . 'assets/event-calendar/calendar.js', [], KIOSKY_PLUGIN_VERSION, true);
    $state = (new Kiosky\WordPress\WordPressStateStore())->load();
    if(Kiosky\Core\LicenseClient::managed()){$license=new Kiosky\Core\LicenseClient(new Kiosky\Core\Crypto(wp_salt('auth').wp_salt('secure_auth')));if(!$license->allows($state,'events'))return '';}
    return Kiosky\Core\PublicEventCalendar::render($state, $overrides, [new Kiosky\WordPress\WordPressMediaLibrary(), 'calendarImage']);
}
add_shortcode('kiosky_event_calendar', 'kiosky_event_calendar_shortcode');

/** The backend always mounts the full application; only /speisekarten uses the kitchen editor. */
function kiosky_render_app_document(bool $player, string $initial_view, bool $menu_editor = false): string {
    $index_path = __DIR__ . '/assets/app/' . ($menu_editor ? 'menus.html' : 'index.html');
    if (!is_readable($index_path)) wp_die(esc_html__('Die Kiosky-Oberfläche fehlt im Pluginpaket.', 'kiosky'), 500);
    $html = (string) file_get_contents($index_path);
    $asset_base = trailingslashit(plugin_dir_url(__FILE__) . 'assets/app');
    $bootstrap = '<base href="' . esc_url($asset_base) . '">'
        . '<meta name="kiosky-platform" content="wordpress">'
        . '<meta name="kiosky-menu-base-url" content="' . esc_url(home_url('/speisekarten')) . '">'
        . '<meta name="kiosky-external-api-base-url" content="' . esc_url(rest_url('kiosky/v1/control')) . '">'
        . '<meta name="kiosky-api-endpoint" content="' . esc_url(rest_url('kiosky/v1/api')) . '">'
        . '<meta name="kiosky-asset-base-url" content="' . esc_url(untrailingslashit($asset_base)) . '">'
        . '<meta name="kiosky-player-base-url" content="' . esc_url(home_url('/kiosky-player/')) . '">'
        . '<meta name="kiosky-player-center-url" content="' . esc_url(home_url('/kiosky-player-center/')) . '">'
        . '<meta name="kiosky-initial-view" content="' . esc_attr($initial_view) . '">'
        . ($player ? '' : '<meta name="kiosky-request-header-x-wp-nonce" content="' . esc_attr(wp_create_nonce('wp_rest')) . '">');
    $html=str_replace('<head>', '<head>' . $bootstrap, $html);
    if($player&&!$menu_editor&&($_GET['tizen']??'')==='1')$html=Kiosky\Core\TizenPlayer::document($html,$asset_base,$_GET['display']??null,$_GET['key']??null);
    return $html;
}

function kiosky_output_app(bool $player, string $initial_view, bool $menu_editor = false): never {
    $html = kiosky_render_app_document($player, $initial_view, $menu_editor);
    status_header(200);
    nocache_headers();
    header('Content-Type: text/html; charset=utf-8');
    header("Referrer-Policy: no-referrer");
    if($player&&!$menu_editor&&($_GET['tizen']??'')==='1')header_remove('X-Frame-Options');
    header("Content-Security-Policy: default-src 'self' data: blob: https:; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self' blob: data:; connect-src 'self'; frame-src https:; object-src 'none'");
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- packaged application HTML
    exit;
}

function kiosky_output_player_portal(string $page): never {
    $path = __DIR__ . '/assets/app/player/' . ($page === 'browser' ? 'browser.html' : 'index.html');
    if (!is_readable($path)) wp_die(esc_html__('Das Kiosky Player Center fehlt im Pluginpaket.', 'kiosky'), 500);
    $asset = trailingslashit(plugin_dir_url(__FILE__) . 'assets/app/player');
    $html = str_replace('/player/', $asset, (string)file_get_contents($path));
    $runtime = $page === 'browser'
        ? '<script>window.KioskyPlayerRuntime=' . wp_json_encode(['apiEndpoint' => rest_url('kiosky/v1/api'), 'playerBaseUrl' => home_url('/kiosky-player/'), 'browserUrl' => home_url('/kiosky-player-browser/')]) . ';</script>'
        : '<script>window.KioskyPlayerCenterRuntime=' . wp_json_encode(['browserUrl' => home_url('/kiosky-player-browser/'), 'downloadBase' => home_url('/kiosky-player-download/')]) . ';</script>';
    $html = str_replace('</head>', $runtime . '</head>', $html);
    status_header(200); nocache_headers(); header('Content-Type: text/html; charset=utf-8');
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    exit;
}

function kiosky_output_player_update(): never {
    if(!in_array(strtoupper($_SERVER['REQUEST_METHOD']??'GET'),['GET','HEAD'],true)){status_header(405);header('Allow: GET, HEAD');exit;}
    try{$update=Kiosky\Core\PlayerLauncher::update(is_string($_GET['platform']??null)?$_GET['platform']:'',($_GET['file']??'')==='1',__DIR__.'/assets/app/launchers');}
    catch(RuntimeException $error){wp_die(esc_html($error->getMessage()),'',['response'=>$error->getCode()?:503]);}
    nocache_headers();header('Content-Type: '.$update['contentType']);header('Content-Length: '.strlen($update['body']));header('X-Content-Type-Options: nosniff');
    if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')==='GET')echo $update['body'];exit;
}

/** @return array{body:string,filename:string,contentType:string} */
function kiosky_player_download(string $platform): array {
    return Kiosky\Core\PlayerLauncher::download($platform, home_url('/kiosky-player-browser/'), __DIR__.'/assets/app/launchers', ['apiEndpoint'=>rest_url('kiosky/v1/api'),'playerBaseUrl'=>home_url('/kiosky-player/')]);
}

function kiosky_output_player_download(string $platform): never {
    if (!in_array(strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['GET','HEAD'], true)) { status_header(405); header('Allow: GET, HEAD'); exit; }
    try { $download = kiosky_player_download($platform); }
    catch (RuntimeException $error) { wp_die(esc_html($error->getMessage()), '', ['response'=>$error->getCode() ?: 503]); }
    nocache_headers(); header('Content-Type: '.$download['contentType']);
    header('Content-Disposition: attachment; filename="'.$download['filename'].'"');
    header('Content-Length: '.strlen($download['body'])); header('X-Content-Type-Options: nosniff');
    if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') echo $download['body'];
    exit;
}

function kiosky_register_rest_routes(): void {
    register_rest_route('kiosky/v1', '/control(?:/(?P<endpoint>.*))?', [
        'methods' => WP_REST_Server::ALLMETHODS,
        'callback' => 'kiosky_rest_external_api',
        // Machine credentials are verified by the callback, independently of CMS login.
        'permission_callback' => '__return_true',
    ]);
    register_rest_route('kiosky/v1', '/api', [
        'methods' => WP_REST_Server::ALLMETHODS,
        'callback' => 'kiosky_rest_api',
        'permission_callback' => 'kiosky_rest_permission',
    ]);
}
add_action('rest_api_init', 'kiosky_register_rest_routes');

/** WordPress handles OPTIONS before endpoint callbacks; scope this to public pairing. */
function kiosky_tizen_pairing_preflight($response, $server, WP_REST_Request $request) {
    if($response!==null||$request->get_method()!=='OPTIONS'||$request->get_route()!=='/kiosky/v1/api'||!preg_match('#^/api/player-pairings(?:/[^/]+)?$#',kiosky_rest_api_path($request)))return $response;
    return new WP_REST_Response(null,204,Kiosky\Core\TizenPlayer::pairingHeaders());
}
add_filter('rest_pre_dispatch','kiosky_tizen_pairing_preflight',5,3);

/** Reject oversized REST bodies before WordPress buffers/parses the JSON request. */
function kiosky_guard_rest_body($wp):void {
    $route=$wp->query_vars['rest_route']??'';if(!is_string($route)||strtolower('/'.trim($route,'/'))!=='/kiosky/v1/api')return;
    $path=is_string($_GET['path']??null)?$_GET['path']:'';$customer=str_starts_with($path,'/api/customer-portal');
    require_once __DIR__.'/includes/Core/PlayerRequest.php';
    $limit=$customer?($path==='/api/customer-portal/uploads'?28000000:50000):Kiosky\Core\PlayerRequest::limit($path);
    if($limit===null)$limit=$path===''?8192:((current_user_can('kiosky_access')&&wp_verify_nonce((string)($_SERVER['HTTP_X_WP_NONCE']??''),'wp_rest'))?256000000:3000000);
    $declared=$_SERVER['CONTENT_LENGTH']??null;
    try{
        if(is_numeric($declared)&&(float)$declared>0){if((float)$declared>$limit)throw new RuntimeException('Die Anfrage ist zu groß.',413);if($customer)Kiosky\Core\CustomerVault::assertRequest(max(0,(int)$declared));}
        elseif($customer){$stream=@fopen('php://input','rb');if($stream){$bytes=0;try{while(!feof($stream)){$chunk=fread($stream,65536);if($chunk===false)throw new RuntimeException('Die Anfrage konnte nicht gelesen werden.',400);$bytes+=strlen($chunk);if($bytes>$limit)throw new RuntimeException('Die Anfrage ist zu groß.',413);Kiosky\Core\CustomerVault::assertRequest($bytes);}}finally{fclose($stream);}}}
    }catch(RuntimeException $error){wp_send_json(['error'=>['message'=>$error->getMessage()]],$error->getCode()?:413);}
}
add_action('parse_request','kiosky_guard_rest_body',0);

function kiosky_player_request_guard($response,$server,WP_REST_Request $request){
    if($response!==null||$request->get_route()!=='/kiosky/v1/api')return $response;$query=$request->get_query_params();$path=is_string($query['path']??null)?$query['path']:'';
    if(str_starts_with($path,'/api/customer-portal')){if(strlen((string)$request->get_body())>($path==='/api/customer-portal/uploads'?28000000:50000))return new WP_REST_Response(['error'=>['message'=>'Anfrage zu groß.']],413);$token=(string)$request->get_header('X-Customer-Token');if(!preg_match('/^[a-f0-9]{64}$/D',$token))return new WP_REST_Response(['error'=>['message'=>'Der Kundenlink ist ungültig.']],401);try{Kiosky\Core\CustomerVault::assertRequest(strlen((string)$request->get_body()));}catch(RuntimeException $e){return new WP_REST_Response(['error'=>['message'=>$e->getMessage()]],$e->getCode());}if(in_array($request->get_method(),['POST','PUT'],true)){[$status,$payload]=kiosky_api(['id'=>'customer','name'=>'Kundenportal','email'=>'','role'=>'viewer','ipAddress'=>(string)($_SERVER['REMOTE_ADDR']??'')],true)->handle('GET','/api/customer-portal',[],$token);if($status>=400)return new WP_REST_Response($payload,$status);}return $response;}
    require_once __DIR__.'/includes/Core/PlayerRequest.php';$limit=Kiosky\Core\PlayerRequest::limit($path);if($limit===null){$limit=$path===''?8192:((current_user_can('kiosky_access')&&wp_verify_nonce((string)$request->get_header('X-WP-Nonce'),'wp_rest'))?256000000:3000000);if(strlen((string)$request->get_body())>$limit)return new WP_REST_Response(['error'=>['code'=>'REQUEST_TOO_LARGE','message'=>'Die Anfrage ist zu groß.']],413);return $response;}
    try{Kiosky\Core\PlayerRequest::decode((string)$request->get_body(),$path);}catch(RuntimeException $e){return new WP_REST_Response(['error'=>['code'=>'INVALID_PLAYER_REQUEST','message'=>$e->getMessage()]],$e->getCode());}return $response;
}
add_filter('rest_pre_dispatch','kiosky_player_request_guard',4,3);



/** Keep routing and pre-parse size checks on the same path; JSON cannot override it. */
function kiosky_rest_api_path(WP_REST_Request $request):string {
    $query=$request->get_query_params();$path=$query['path']??$request->get_param('path');return is_string($path)?$path:'';
}

function kiosky_rest_permission(WP_REST_Request $request): bool {
    $path = kiosky_rest_api_path($request);
    if(preg_match('#^/api/customer-portal(?:/(uploads|proposals|files)(?:/[^/]+)?)?$#',$path))return true;
    if (preg_match('#^/api/menu-share/(session|menus(?:/[^/]+)?)$#',$path)) return true;
    if ($path === '/api/v1' || str_starts_with($path, '/api/v1/')) return true;
    if (preg_match('#^/api/public/tickets/[^/]{1,300}$#',$path)&&$request->get_method()==='GET') return true;
    if ($path === '/api/public/calendar' || preg_match('#^/api/player/[^/]+/(state|heartbeat|proof|commands)$#', $path) || str_starts_with($path, '/api/player-pairings')) return true;
    return kiosky_current_role() !== null;
}

/** Persistent private files, outside the public document root (Plesk: domain/private). */
function kiosky_font_storage_directory(): string {
    if(defined('KIOSKY_FONT_STORAGE_PATH')&&is_string(KIOSKY_FONT_STORAGE_PATH)&&KIOSKY_FONT_STORAGE_PATH!=='')return rtrim(KIOSKY_FONT_STORAGE_PATH,'/');
    $configuredRoot=(string)($_SERVER['DOCUMENT_ROOT'] ?? '');
    $documentRoot=$configuredRoot!==''?realpath($configuredRoot):false;
    if(!$documentRoot)$documentRoot=rtrim(ABSPATH,'/');
    return dirname($documentRoot).'/private/kiosky-fonts-'.substr(hash('sha256',ABSPATH),0,16);
}

/** @param array{id:string,name:string,email:string,role:string} $identity */
function kiosky_api(array $identity, bool $external = false): Kiosky\Core\Api {
    $http = new Kiosky\WordPress\WordPressHttpClient();
    $crypto = new Kiosky\Core\Crypto(wp_salt('auth') . wp_salt('secure_auth'));
    $portableUsers = array_map(static function (WP_User $user): array {
        $role = user_can($user, 'kiosky_admin') || user_can($user, 'manage_options') ? 'admin' : (user_can($user, 'kiosky_edit') ? 'editor' : (user_can($user,'kiosky_design') ? 'designer' : 'viewer'));
        return ['id' => 'wp:' . $user->ID, 'email' => $user->user_email, 'username' => $user->user_login, 'displayName' => $user->display_name ?: $user->user_login, 'role' => $role, 'status' => 'active', 'allLocations' => true, 'locationIds' => []];
    }, $external ? [] : get_users(['capability' => 'kiosky_access']));
    return new Kiosky\Core\Api(
        new Kiosky\Core\CmsMediaStateStore(new Kiosky\WordPress\WordPressStateStore(), new Kiosky\WordPress\WordPressMediaLibrary(), !$external && ($identity['role'] ?? 'viewer') !== 'viewer', !$external),
        $identity,
        KIOSKY_PLUGIN_VERSION,
        new Kiosky\Core\CrewBrainService($http, $crypto),
        new Kiosky\Core\DwdService($http),
        new Kiosky\Core\EasyJobService($http, $crypto),
        $portableUsers,
        'wordpress',
        null,
        new Kiosky\Core\LicenseClient($crypto,'wordpress',KIOSKY_PLUGIN_VERSION),
        proofStore: new Kiosky\WordPress\WordPressProofStore(),
        proofSecret: wp_salt('auth').wp_salt('secure_auth'),
        fontStorage: new Kiosky\Core\FontStorage(kiosky_font_storage_directory()),
        customerVault: new Kiosky\Core\CustomerVault(kiosky_font_storage_directory().'/customer-uploads'),
        canReadFonts: !$external && kiosky_current_role()!==null && (int)wp_get_current_user()->ID>0,
        canManageFonts: !$external && kiosky_current_role()==='admin' && current_user_can('kiosky_admin') && ($identity['role']??'viewer')==='admin',
    );
}

function kiosky_rest_external_api(WP_REST_Request $request, ?string $apiPath = null): WP_REST_Response {
    $requestId = bin2hex(random_bytes(16));
    $endpoint = (string)($request->get_url_params()['endpoint'] ?? '');
    $apiPath ??= '/api/v1' . ($endpoint !== '' ? '/' . trim($endpoint, '/') : '');
    try {
        $body = Kiosky\Core\ExternalRequest::body((string)$request->get_body());
        $query = $request->get_query_params();
        unset($query['path'], $query['rest_route']);
        $body = array_merge($query,$body);
        $token = Kiosky\Core\ApiAccess::token((string)$request->get_header('Authorization'),(string)$request->get_header('X-API-Key'));
        if ($token === '' && kiosky_current_role() === 'admin') {
            // Preserve WordPress application-password and authenticated administrator access.
            $user = wp_get_current_user();
            $api = kiosky_api(['id'=>'wp:'.$user->ID,'name'=>$user->display_name,'email'=>$user->user_email,'role'=>'admin','requestId'=>$requestId,'ipAddress'=>(string)($_SERVER['REMOTE_ADDR'] ?? '')],true);
            [$status,$payload] = $api->handle($request->get_method(),$apiPath,$body);
        } else {
            $api = kiosky_api(['id'=>'external','name'=>'Externe API','email'=>'','role'=>'viewer'],true);
            [$status,$payload] = $api->handleExternal($request->get_method(),$apiPath,$body,$token,'',$requestId,(string)($_SERVER['REMOTE_ADDR'] ?? ''));
        }
        if ($apiPath === '/api/v1' && $status === 200) {
            $payload['documentation'] = plugin_dir_url(__FILE__).'assets/app/docs/external-api.md';
            $payload['openapi'] = plugin_dir_url(__FILE__).'assets/app/docs/openapi.yaml';
        }
    } catch (RuntimeException $error) {
        $status = $error->getCode() ?: 400;
        $payload = Kiosky\Core\ExternalRequest::error($error);
    }
    return new WP_REST_Response($payload,$status,Kiosky\Core\ExternalRequest::headers($requestId,$status));
}

function kiosky_rest_api(WP_REST_Request $request): WP_REST_Response {
    $apiPath = kiosky_rest_api_path($request);
    if(preg_match('#^/api/player-pairings(?:/[^/]+)?$#',$apiPath)&&$request->get_method()==='OPTIONS')return new WP_REST_Response(null,204,Kiosky\Core\TizenPlayer::pairingHeaders());
    if ($apiPath === '/api/v1' || str_starts_with($apiPath,'/api/v1/')) return kiosky_rest_external_api($request,$apiPath);
    if(preg_match('#^/api/customer-portal(?:/(uploads|proposals|files)(?:/[^/]+)?)?$#',$apiPath)){
        $raw=(string)$request->get_body();if(strlen($raw)>($apiPath==='/api/customer-portal/uploads'?28000000:50000))return new WP_REST_Response(['error'=>['message'=>'Anfrage zu groß.']],413);
        try{$body=$raw===''?[]:json_decode($raw,true,32,JSON_THROW_ON_ERROR);if(!is_array($body)||($raw!==''&&!str_starts_with(ltrim($raw),'{')))throw new RuntimeException('JSON-Objekt erforderlich.');}catch(Throwable){return new WP_REST_Response(['error'=>['message'=>'Ungültiges JSON.']],400);}
        [$status,$payload]=kiosky_api(['id'=>'customer','name'=>'Kundenportal','email'=>'','role'=>'viewer','ipAddress'=>(string)($_SERVER['REMOTE_ADDR']??'')],true)->handle($request->get_method(),$apiPath,$body,(string)$request->get_header('X-Customer-Token'));
        return new WP_REST_Response($payload,$status,['Cache-Control'=>'no-store','Referrer-Policy'=>'no-referrer','X-Content-Type-Options'=>'nosniff']);
    }
    if (str_starts_with($apiPath,'/api/menu-share/')) {
        $identity=['id'=>'menu-share','name'=>'Speisekarten-Freigabe','email'=>'','role'=>'viewer','ipAddress'=>(string)($_SERVER['REMOTE_ADDR'] ?? '')];
        $token=(string)$request->get_header('Authorization');
        $token=str_starts_with($token,'Bearer ')?substr($token,7):'';
        $body=$request->get_json_params();
        [$status,$payload]=kiosky_api($identity,true)->handle($request->get_method(),$apiPath,is_array($body)?$body:[],$token);
        return new WP_REST_Response($payload,$status,['Cache-Control'=>'no-store','Referrer-Policy'=>'no-referrer']);
    }
    if(preg_match('#^/api/public/tickets/[^/]{1,300}$#',$apiPath)&&$request->get_method()==='GET'){
        [$status,$payload]=kiosky_api(['id'=>'public-tickets','name'=>'Ticketanbieter','email'=>'','role'=>'viewer'],true)->handle('GET',$apiPath);
        return new WP_REST_Response($payload,$status,['Cache-Control'=>'no-store','Referrer-Policy'=>'no-referrer','X-Content-Type-Options'=>'nosniff']);
    }
    $user = wp_get_current_user();
    $identity = [
        'id' => 'wp:' . (string) $user->ID,
        'name' => $user->display_name ?: $user->user_login,
        'email' => $user->user_email ?: $user->user_login,
        'role' => kiosky_current_role() ?? 'viewer',
    ];
    $body = $request->get_json_params();
    if (!is_array($body)) $body = [];
    $query = $request->get_query_params();
    unset($query['path']);
    $body = array_merge($query, $body);
    $apiPath = kiosky_rest_api_path($request);
    if ($apiPath === '/api/settings/menus' || $apiPath === '/api/menus' || str_starts_with($apiPath,'/api/menus/')) $body = is_array($request->get_json_params()) ? $request->get_json_params() : [];
    if (str_starts_with($apiPath, '/api/updates')) {
        if (!current_user_can('kiosky_admin') || !current_user_can('update_plugins')) {
            return new WP_REST_Response(['error' => ['code' => 'FORBIDDEN', 'message' => 'Updates dürfen nur von WordPress-Administratoren installiert werden.']], 403);
        }
        try {
            $update = match ([$request->get_method(), $apiPath]) {
                ['GET', '/api/updates/status'] => Kiosky\WordPress\Updater::status(),
                ['POST', '/api/updates/check'] => Kiosky\WordPress\Updater::status(true),
                ['POST', '/api/updates/install'] => Kiosky\WordPress\Updater::install(),
                default => null,
            };
            return $update === null
                ? new WP_REST_Response(['error' => ['code' => 'NOT_FOUND', 'message' => 'Update-Endpunkt nicht gefunden.']], 404)
                : new WP_REST_Response(['update' => $update, 'scheduled' => false], 200, ['Cache-Control' => 'no-store']);
        } catch (Throwable $error) {
            return new WP_REST_Response(['error' => ['code' => 'UPDATE_FAILED', 'message' => $error->getMessage()]], 422);
        }
    }
    $api = kiosky_api($identity,preg_match('#^/api/player/[^/]+/(commands|heartbeat)$#',$apiPath)===1);
    [$status, $payload] = $api->handle(
        $request->get_method(),
        $apiPath,
        $body,
        (string) $request->get_header('X-Player-Key')
    );
    return new WP_REST_Response($payload, $status, ['Cache-Control' => 'no-store']+(preg_match('#^/api/player-pairings(?:/[^/]+)?$#',$apiPath)?Kiosky\Core\TizenPlayer::pairingHeaders():[]));
}

function kiosky_run_scheduled_tasks(): void {
    if (get_transient('kiosky_scheduled_tasks_lock')) return;
    set_transient('kiosky_scheduled_tasks_lock', '1', 10 * MINUTE_IN_SECONDS);
    try {
        kiosky_api(['id' => 'wp:cron', 'name' => 'WordPress Cron', 'email' => '', 'role' => 'admin'])->runScheduledTasks();
    } finally {
        delete_transient('kiosky_scheduled_tasks_lock');
    }
}
add_action('kiosky_scheduled_tasks', 'kiosky_run_scheduled_tasks');

// Independent of event imports: due preset actions must not wait on remote providers.
add_action('init',static function(): void {
    if(!wp_next_scheduled('kiosky_preset_triggers'))wp_schedule_event(time()+60,'kiosky_minute','kiosky_preset_triggers');
},20);
add_action('kiosky_preset_triggers',static function(): void {
    if(get_transient('kiosky_preset_triggers_lock'))return;
    set_transient('kiosky_preset_triggers_lock','1',30);
    try{kiosky_api(['id'=>'wp:preset-scheduler','name'=>'Preset-Zeitplanung','email'=>'','role'=>'admin'],true)->runPresetTriggers();}
    finally{delete_transient('kiosky_preset_triggers_lock');}
});
