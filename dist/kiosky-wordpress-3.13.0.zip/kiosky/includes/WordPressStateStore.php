<?php

declare(strict_types=1);

namespace Kiosky\WordPress;

use Kiosky\Core\StateStore;
use Kiosky\Core\ApiAccess;
use Kiosky\Core\StateConflict;
use RuntimeException;

final class WordPressStateStore implements StateStore
{
    private const OPTION = 'kiosky_application_state';
    private bool $loaded = false;
    private ?string $loadedRaw = null;

    public function load(): array
    {
        $raw = $this->readRaw();
        $this->loaded = true;
        $this->loadedRaw = $raw;
        return $this->decode($raw);
    }

    public function save(array $state): void
    {
        global $wpdb;
        // Compare-and-swap prevents a stale request from undoing credential revocations.
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $raw = $this->readRaw();
            if ($this->loaded && $raw !== $this->loadedRaw) throw new StateConflict();
            if ($raw === null) {
                $previousSuppression = $wpdb->suppress_errors();
                try { $created = add_option(self::OPTION,$state,'',false); }
                finally { $wpdb->suppress_errors($previousSuppression); }
                if ($created) { $this->loaded = true; $this->loadedRaw = maybe_serialize($state); return; }
                if ($wpdb->last_error !== '') throw $this->failure('CREATE');
                continue;
            }
            $current = $this->decode($raw);
            $next = $state;
            if (isset($state['apiUsers']) || isset($current['apiUsers'])) $next['apiUsers'] = ApiAccess::mergeUsers($state['apiUsers'] ?? [],$current['apiUsers'] ?? []);
            $encoded = maybe_serialize($next);
            if ($encoded === $raw) return;
            // Preserve WordPress's column-specific validation, including its refusal
            // to silently truncate serialized content. No table charset conversion.
            $validated = $wpdb->strip_invalid_text_for_column($wpdb->options, 'option_value', $encoded);
            if (is_wp_error($validated)) throw $this->failure('SCHEMA');
            if ($validated !== $encoded) throw $this->failure('TEXT_FORMAT');
            // Send the state once. A digest compares the exact previous bytes, rather
            // than doubling large SQL packets or using a case-insensitive text match.
            // The ASCII transport also avoids WordPress's table-wide charset check.
            // FROM_BASE64 stores the original bytes; the option format is unchanged.
            $query = $wpdb->prepare(
                'UPDATE %i SET option_value = FROM_BASE64(%s) WHERE option_name = %s AND SHA2(option_value, 256) = %s',
                $wpdb->options, base64_encode($encoded), self::OPTION, hash('sha256', $raw),
            );
            $packetLimit = $wpdb->get_var('SELECT @@max_allowed_packet');
            if ($wpdb->last_error !== '') throw $this->failure('READ');
            if (is_numeric($packetLimit) && strlen($query) + 1 > (int)$packetLimit) throw $this->failure('PACKET_LIMIT');
            $previousSuppression = $wpdb->suppress_errors();
            try { $changed = $wpdb->query($query); }
            finally { $wpdb->suppress_errors($previousSuppression); }
            if ($changed === 1) {
                $this->loaded = true; $this->loadedRaw = $encoded;
                wp_cache_delete(self::OPTION,'options');
                return;
            }
            if ($changed === false) throw $this->failure('WRITE');
        }
        throw new StateConflict();
    }

    private function readRaw(): ?string
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT option_value FROM %i WHERE option_name = %s', $wpdb->options, self::OPTION), ARRAY_A);
        if ($wpdb->last_error !== '') throw $this->failure('READ');
        return $row ? (string)$row['option_value'] : null;
    }

    private function decode(?string $raw): array
    {
        if ($raw === null) return [];
        $state = maybe_unserialize($raw);
        if (!is_array($state)) throw $this->failure('STATE_CORRUPT');
        return $state;
    }

    private function failure(string $reason): RuntimeException
    {
        global $wpdb;
        // Database messages may contain SQL, state and credentials: classify locally
        // and return only fixed, actionable text. Never expose the original error.
        $error = strtolower((string)$wpdb->last_error);
        if (str_contains($error, 'max_allowed_packet') || str_contains($error, 'packet bigger') || str_contains($error, 'packet too large')) $reason = 'PACKET_LIMIT';
        elseif (str_contains($error, 'denied') || str_contains($error, 'read only') || str_contains($error, 'read-only')) $reason = 'PERMISSION';
        elseif (str_contains($error, 'server has gone away') || str_contains($error, 'lost connection')) $reason = 'CONNECTION';
        elseif (str_contains($error, 'incorrect string') || str_contains($error, 'invalid data') || str_contains($error, 'data too long') || str_contains($error, 'illegal mix of collations')) $reason = 'TEXT_FORMAT';
        elseif (str_contains($error, 'disk full') || str_contains($error, 'table is full') || str_contains($error, 'no space left')) $reason = 'DISK_FULL';
        $hint = match ($reason) {
            'PACKET_LIMIT' => 'Der Datenbestand überschreitet das Datenbank-Paketlimit. Der Hoster muss max_allowed_packet erhöhen.',
            'PERMISSION' => 'Die Datenbank verweigert den Schreibzugriff oder ist schreibgeschützt. Bitte die Datenbankrechte beim Hoster prüfen.',
            'CONNECTION' => 'Die Datenbankverbindung wurde unterbrochen. Bitte erneut versuchen; bei Wiederholung den Hoster prüfen lassen.',
            'TEXT_FORMAT' => 'Zeichensatz oder Feldgröße von option_value unterstützen den Datenbestand nicht. Bitte die WordPress-Optionstabelle beim Hoster prüfen lassen.',
            'STATE_CORRUPT' => 'Der vorhandene Datenbestand ist nicht lesbar. Er wird zum Schutz vor Datenverlust nicht überschrieben. Bitte ein Datenbank-Backup prüfen.',
            'DISK_FULL' => 'Der Datenbankspeicher ist voll. Bitte Speicherplatz beim Hoster prüfen lassen.',
            'SCHEMA' => 'Die Datenbankspalte konnte nicht geprüft werden. Bitte die WordPress-Optionstabelle beim Hoster prüfen lassen.',
            'READ' => 'Der vorhandene Datenbestand konnte nicht aus der Datenbank gelesen werden.',
            default => 'Die Datenbank hat den Schreibzugriff abgewiesen. Bitte dem Support diese Fehlerkennung und die installierte Kiosky-Version nennen.',
        };
        return new RuntimeException('Kiosky-Daten konnten nicht in WordPress gespeichert werden. [WP_DB_'.$reason.'] '.$hint, 503);
    }
}
