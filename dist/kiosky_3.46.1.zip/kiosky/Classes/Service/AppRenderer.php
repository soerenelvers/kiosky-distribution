<?php

declare(strict_types=1);

namespace Kiosky\Kiosky\Service;

use Psr\Http\Message\ServerRequestInterface;
use RuntimeException;
use TYPO3\CMS\Core\Utility\GeneralUtility;

final readonly class AppRenderer
{
    public function render(
        string $platform,
        string $apiEndpoint,
        string $playerBaseUrl,
        ServerRequestInterface $request,
        string $nonce = '',
        string $mediaBrowserUrl = '',
    ): string
    {
        $indexPath = GeneralUtility::getFileAbsFileName('EXT:kiosky/Resources/Public/App/index.html');
        if (!$indexPath || !is_readable($indexPath)) throw new RuntimeException('Die Kiosky-Oberfläche fehlt in der Extension.');
        $assetBase = $this->assetBaseUrl($request);
        $sitePath = $request->getAttribute('normalizedParams')?->getSitePath() ?? '/';
        $externalBase = $request->getUri()->getScheme().'://'.$request->getUri()->getAuthority().rtrim($sitePath,'/').'/kiosky-api/v1';
        $meta = $this->meta('kiosky-platform', $platform)
            . $this->meta('kiosky-external-api-base-url', $externalBase)
            . $this->meta('kiosky-api-endpoint', $apiEndpoint)
            . $this->meta('kiosky-asset-base-url', rtrim($assetBase, '/'))
            . $this->meta('kiosky-menu-base-url', rtrim(dirname(rtrim($playerBaseUrl,'/')),'/').'/speisekarten')
            . $this->meta('kiosky-player-base-url', $playerBaseUrl)
            . $this->meta('kiosky-player-center-url', rtrim(dirname(rtrim($playerBaseUrl, '/')), '/') . '/kiosky-player-center/')
            . ($nonce !== '' ? $this->meta('kiosky-request-header-typo3-nonce', $nonce) : '');
        if($mediaBrowserUrl!=='')$meta.=$this->meta('kiosky-native-media-browser-url',$mediaBrowserUrl).'<script defer src="'.htmlspecialchars($assetBase.'typo3-media.js',ENT_QUOTES).'"></script>';
        $html = $this->rewriteAppAssetUrls((string)file_get_contents($indexPath), $assetBase);
        return str_replace('<head>', '<head>' . $meta, $html);
    }

    public function renderMenus(string $apiEndpoint, ServerRequestInterface $request): string
    {
        $file = GeneralUtility::getFileAbsFileName('EXT:kiosky/Resources/Public/App/menus.html');
        if (!$file || !is_readable($file)) throw new RuntimeException('Der Speisekarten-Editor fehlt.');
        $base = htmlspecialchars($this->assetBaseUrl($request),ENT_QUOTES);
        $html = str_replace(['href="menus.css','src="runtime-config.js','src="menus.js'],['href="'.$base.'menus.css','src="'.$base.'runtime-config.js','src="'.$base.'menus.js'],(string)file_get_contents($file));
        return str_replace('<head>','<head>'.$this->meta('kiosky-platform','typo3').$this->meta('kiosky-api-endpoint',$apiEndpoint).$this->meta('kiosky-asset-base-url',rtrim($this->assetBaseUrl($request),'/')),$html);
    }

    public function renderPlayerPortal(
        string $page,
        string $apiEndpoint,
        string $playerBaseUrl,
        string $browserUrl,
        ServerRequestInterface $request,
    ): string
    {
        $appPath = GeneralUtility::getFileAbsFileName('EXT:kiosky/Resources/Public/App/');
        $assetBase = $this->assetBaseUrl($request);
        $file = $appPath . 'player/' . ($page === 'browser' ? 'browser.html' : 'index.html');
        if (!is_readable($file)) throw new RuntimeException('Das Kiosky Player Center fehlt in der Extension.');
        $html = str_replace('/player/', $assetBase . 'player/', (string)file_get_contents($file));
        $runtime = $page === 'browser'
            ? ['apiEndpoint' => $apiEndpoint, 'playerBaseUrl' => $playerBaseUrl, 'browserUrl' => $browserUrl]
            : ['browserUrl' => $browserUrl, 'downloadBase' => rtrim(dirname(rtrim($playerBaseUrl, '/')), '/') . '/kiosky-player-download/'];
        $name = $page === 'browser' ? 'KioskyPlayerRuntime' : 'KioskyPlayerCenterRuntime';
        return str_replace('</head>', '<script>window.' . $name . '=' . json_encode($runtime, JSON_UNESCAPED_SLASHES) . ';</script></head>', $html);
    }

    private function assetBaseUrl(ServerRequestInterface $request): string
    {
        return $request->getUri()->getScheme() . '://' . $request->getUri()->getAuthority()
            . rtrim($request->getAttribute('normalizedParams')?->getSitePath() ?? '/', '/') . '/kiosky-assets/';
    }

    private function rewriteAppAssetUrls(string $html, string $assetBase): string
    {
        $assetBase = htmlspecialchars($assetBase, ENT_QUOTES);
        $html = str_replace(
            ['href="styles.css', 'src="runtime-config.js', 'src="app.js'],
            [
                'href="' . $assetBase . 'styles.css',
                'src="' . $assetBase . 'runtime-config.js',
                'src="' . $assetBase . 'app.js',
            ],
            $html,
            $replacementCount,
        );
        if ($replacementCount !== 3) {
            throw new RuntimeException('Die Asset-Verweise der Kiosky-Oberfläche konnten nicht vollständig aufgelöst werden.');
        }
        // Shared editor/player helpers also live under the app asset root.
        // Relative script URLs would otherwise resolve against the backend route.
        return preg_replace_callback(
            '~\b(src|href)="((?:[a-zA-Z0-9_-]+/)*[a-zA-Z0-9_.-]+\.(?:js|css)(?:\?[^\"]*)?)"~',
            static fn(array $match): string => $match[1].'="'.$assetBase.$match[2].'"',
            $html,
        ) ?? throw new RuntimeException('Die zusätzlichen Kiosky-Assets konnten nicht aufgelöst werden.');
    }

    private function meta(string $name, string $content): string
    {
        return '<meta name="' . htmlspecialchars($name, ENT_QUOTES) . '" content="' . htmlspecialchars($content, ENT_QUOTES) . '">';
    }
}
