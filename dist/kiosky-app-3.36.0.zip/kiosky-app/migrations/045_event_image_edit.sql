ALTER TABLE events ADD COLUMN image_edit_json TEXT;
