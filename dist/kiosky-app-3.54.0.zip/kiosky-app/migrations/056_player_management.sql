ALTER TABLE player_pairings ADD COLUMN name TEXT NOT NULL DEFAULT '';
ALTER TABLE player_commands ADD COLUMN target_player_id TEXT;
CREATE TABLE player_snapshots (
 player_id TEXT PRIMARY KEY REFERENCES player_pairings(id) ON DELETE CASCADE,
 request_json TEXT NOT NULL,
 result_json TEXT
);
