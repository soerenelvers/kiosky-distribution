ALTER TABLE events ADD COLUMN advertising_video_json TEXT;
