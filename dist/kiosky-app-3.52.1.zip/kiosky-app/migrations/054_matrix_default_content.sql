ALTER TABLE matrix_displays ADD COLUMN default_content_type TEXT NOT NULL DEFAULT 'channel' CHECK (default_content_type IN ('channel','slide'));
ALTER TABLE matrix_displays ADD COLUMN default_slide_id TEXT REFERENCES slides(id) ON DELETE SET NULL;
UPDATE matrix_display_members SET physical_width=CASE WHEN physical_width<240 OR physical_width>16384 THEN 1920 ELSE physical_width END,physical_height=CASE WHEN physical_height<240 OR physical_height>16384 THEN 1080 ELSE physical_height END;
DROP INDEX IF EXISTS idx_matrix_active_display;
CREATE INDEX idx_matrix_member_display ON matrix_display_members(display_id,matrix_id);
CREATE TRIGGER matrix_member_active_conflict BEFORE INSERT ON matrix_display_members
WHEN EXISTS(SELECT 1 FROM matrix_displays WHERE id=NEW.matrix_id AND status='active' AND deleted_at IS NULL)
 AND EXISTS(SELECT 1 FROM matrix_display_members mm JOIN matrix_displays m ON m.id=mm.matrix_id WHERE mm.display_id=NEW.display_id AND mm.matrix_id!=NEW.matrix_id AND m.status='active' AND m.deleted_at IS NULL)
BEGIN SELECT RAISE(ABORT,'Das Display ist bereits einer aktiven Matrix zugeordnet.'); END;
CREATE TRIGGER matrix_activate_conflict BEFORE UPDATE OF status,deleted_at ON matrix_displays
WHEN NEW.status='active' AND NEW.deleted_at IS NULL
 AND EXISTS(SELECT 1 FROM matrix_display_members own JOIN matrix_display_members other ON other.display_id=own.display_id AND other.matrix_id!=NEW.id JOIN matrix_displays m ON m.id=other.matrix_id WHERE own.matrix_id=NEW.id AND m.status='active' AND m.deleted_at IS NULL)
BEGIN SELECT RAISE(ABORT,'Das Display ist bereits einer aktiven Matrix zugeordnet.'); END;
