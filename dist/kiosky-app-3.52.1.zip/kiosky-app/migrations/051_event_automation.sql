-- Distinguish automatic expiry from explicit archiving for finite post-event steps.
ALTER TABLE events ADD COLUMN auto_archived INTEGER NOT NULL DEFAULT 0;
