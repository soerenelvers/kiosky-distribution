CREATE TABLE player_health (
 display_id TEXT PRIMARY KEY REFERENCES displays(id) ON DELETE CASCADE,
 data_json TEXT NOT NULL
);
