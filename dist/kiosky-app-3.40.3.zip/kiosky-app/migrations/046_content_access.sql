-- Additive migration: existing users, sessions and tokens remain intact.
-- Keep the legacy base role read-only for compatibility with older raw consumers.
ALTER TABLE users ADD COLUMN content_role TEXT CHECK (content_role IS NULL OR content_role='designer');
ALTER TABLE user_invitations ADD COLUMN content_role TEXT CHECK (content_role IS NULL OR content_role='designer');
ALTER TABLE slides ADD COLUMN owner_id TEXT;
UPDATE slides SET owner_id=(SELECT created_by FROM slide_versions WHERE slide_id=slides.id AND version=1 AND created_by IS NOT NULL LIMIT 1);
CREATE INDEX slides_owner_active_idx ON slides(owner_id,deleted_at,status);
CREATE TABLE content_channel_access (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  channel_ids_json TEXT NOT NULL DEFAULT '[]',
  updated_at TEXT NOT NULL
);
