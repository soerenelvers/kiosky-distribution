-- Preserve existing published visibility while reducing the workflow to five states.
UPDATE events SET remaining_tickets='Ausverkauft' WHERE status='sold_out' AND COALESCE(remaining_tickets,'')='';
UPDATE events SET status=CASE status WHEN 'review' THEN 'draft' WHEN 'ready' THEN 'published' WHEN 'sold_out' THEN 'published' WHEN 'ended' THEN 'archived' ELSE status END;
CREATE INDEX IF NOT EXISTS idx_event_lifecycle ON events(status, event_end, date);
ALTER TABLE events ADD COLUMN removed_compacted_at TEXT;
