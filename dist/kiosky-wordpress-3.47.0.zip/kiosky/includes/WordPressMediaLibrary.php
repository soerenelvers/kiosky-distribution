<?php

declare(strict_types=1);
namespace Kiosky\WordPress;

use Kiosky\Core\MediaLibrary;
use Kiosky\Core\MediaUpload;
use RuntimeException;

final class WordPressMediaLibrary implements MediaLibrary
{
    public const TAXONOMY = 'kiosky_media_folder';

    public static function register(): void
    {
        register_taxonomy(self::TAXONOMY, 'attachment', ['hierarchical'=>true, 'public'=>false, 'show_ui'=>true, 'show_admin_column'=>true, 'label'=>'Kiosky Medienordner', 'capabilities'=>['manage_terms'=>'upload_files','edit_terms'=>'upload_files','delete_terms'=>'upload_files','assign_terms'=>'upload_files']]);
    }

    public function read(): array
    {
        $folders = [];
        $terms = get_terms(['taxonomy'=>self::TAXONOMY, 'hide_empty'=>false]);
        if (is_wp_error($terms)) throw new RuntimeException($terms->get_error_message(), 500);
        foreach ($terms as $term) $folders[] = ['id'=>'wp-folder:'.$term->term_id, 'name'=>$term->name, 'parentId'=>$term->parent ? 'wp-folder:'.$term->parent : null];
        $assets = [];
        foreach (get_posts(['post_type'=>'attachment','post_status'=>['inherit','private','trash'],'posts_per_page'=>-1,'orderby'=>'ID','order'=>'ASC']) as $post) {
            if (current_user_can('kiosky_access') && !current_user_can('read_post', $post->ID)) continue;
            $assets[] = $this->asset((int)$post->ID);
        }
        return ['folders'=>$folders,'assets'=>$assets];
    }

    /** Read only a configured public calendar image; no anonymous catalogue access. */
    public function calendarImage(string $id): ?array
    {
        if(!preg_match('/^wp:([1-9][0-9]*)$/D',$id,$match))return null;
        $post=get_post((int)$match[1]);
        if(!$post||$post->post_type!=='attachment'||!in_array($post->post_status,['inherit','publish'],true)||!empty($post->post_password))return null;
        if($post->post_parent){$parent=get_post((int)$post->post_parent);if(!$parent||$parent->post_status!=='publish'||!empty($parent->post_password))return null;}
        if(!str_starts_with((string)get_post_mime_type($post->ID),'image/'))return null;
        $asset=$this->asset((int)$post->ID);
        return empty($asset['deletedAt'])&&$asset['type']==='image'?$asset:null;
    }

    private function asset(int $id): array
    {
        $post = get_post($id);
        if (!$post || $post->post_type !== 'attachment') throw new RuntimeException('CMS-Medium nicht gefunden.', 404);
        $meta = get_post_meta($id, '_kiosky_media', true);
        $meta = is_array($meta) ? $meta : [];
        $native = wp_get_attachment_metadata($id);
        $mime = (string)get_post_mime_type($id);
        $terms = wp_get_object_terms($id, self::TAXONOMY, ['fields'=>'ids']);
        $folder = !is_wp_error($terms) && $terms ? 'wp-folder:'.$terms[0] : null;
        return ['id'=>'wp:'.$id,'name'=>$post->post_title,'src'=>(string)wp_get_attachment_url($id),'type'=>str_starts_with($mime,'video/')?'video':($mime==='image/svg+xml'?'icon':(str_starts_with($mime,'image/')?'image':'file')),'folderId'=>$folder,'metadata'=>array_replace($meta,['kioskyManaged'=>(bool)get_post_meta($id,'_kiosky_legacy_id',true),'cms'=>'wordpress','cmsId'=>$id,'mimeType'=>$mime,'width'=>$native['width']??null,'height'=>$native['height']??null]),'deletedAt'=>$post->post_status==='trash'?($meta['deletedAt']??gmdate('c')):null];
    }

    private function writable(?int $id = null): void
    {
        // Scheduled imports have no interactive user; the API supplies its system identity.
        if (wp_get_current_user()->ID && (!current_user_can('upload_files') || ($id && !current_user_can('edit_post', $id)))) throw new RuntimeException('Keine Berechtigung für dieses WordPress-Medium.', 403);
    }

    public function exportAssetData(array $asset, int $maximumBytes = 20000000): string
    {
        $id = (int)substr((string)$asset['id'],3);
        if (!str_starts_with((string)$asset['id'],'wp:') || !current_user_can('read_post',$id)) throw new RuntimeException('Keine Berechtigung für dieses WordPress-Medium.',403);
        $path = get_attached_file($id);
        if (!$path || !is_file($path) || !is_readable($path) || filesize($path)>min(128000000,$maximumBytes)) throw new RuntimeException('Die Mediendatei fehlt oder ist größer als 20 MB.',422);
        return 'data:'.get_post_mime_type($id).';base64,'.base64_encode(file_get_contents($path));
    }

    /** Restore font cache only; caller requires a registered font and verifies the exact SHA-256. */
    public function registeredFontData(string $id): string
    {
        if(!preg_match('/^wp:([1-9][0-9]*)$/D',$id,$match))throw new RuntimeException('Schriftdatei nicht gefunden.',404);
        $path=get_attached_file((int)$match[1]);
        if(!$path||!is_file($path)||!is_readable($path)||filesize($path)>2000000)throw new RuntimeException('Die registrierte Schriftdatei ist nicht verfügbar.',503);
        return 'data:application/octet-stream;base64,'.base64_encode(file_get_contents($path));
    }

    /** Only for the exact original uploaded by an already-authorized customer capability. */
    public function customerUploadData(string $id,string $hash,int $size,string $mime):string
    {
        if(!preg_match('/^wp:([1-9][0-9]*)$/D',$id,$match)||!preg_match('/^[a-f0-9]{64}$/D',$hash)||$size<1||$size>20000000)throw new RuntimeException('Originaldatei nicht gefunden.',404);
        if(get_post_type((int)$match[1])!=='attachment'||!in_array(get_post_status((int)$match[1]),['inherit','publish'],true))throw new RuntimeException('Die Originaldatei ist nicht mehr verfügbar.',404);
        $path=function_exists('wp_get_original_image_path')?wp_get_original_image_path((int)$match[1]):false;
        if(!$path)$path=get_attached_file((int)$match[1]);
        if(!$path||is_link($path)||!is_file($path)||!is_readable($path)||filesize($path)!==$size||@hash_file('sha256',$path)!==$hash)throw new RuntimeException('Die Originaldatei ist nicht mehr verfügbar.',404);
        return 'data:'.$mime.';base64,'.base64_encode((string)@file_get_contents($path));
    }

    public function saveFolder(array $folder): array
    {
        $this->writable();
        $parent = (int)str_replace('wp-folder:', '', (string)($folder['parentId']??''));
        $id = str_starts_with($folder['id'],'wp-folder:') ? (int)substr($folder['id'],10) : 0;
        if (!$id) {
            $existing = get_terms(['taxonomy'=>self::TAXONOMY,'hide_empty'=>false,'meta_key'=>'_kiosky_legacy_id','meta_value'=>$folder['id']]);
            if (!is_wp_error($existing) && $existing) $id = (int)$existing[0]->term_id;
        }
        $result = $id ? wp_update_term($id,self::TAXONOMY,['name'=>$folder['name'],'parent'=>$parent]) : wp_insert_term($folder['name'],self::TAXONOMY,['parent'=>$parent]);
        if (is_wp_error($result)) {
            if ($result->get_error_code() !== 'term_exists') throw new RuntimeException($result->get_error_message(),422);
            $id = (int)$result->get_error_data();
        } else $id = (int)$result['term_id'];
        update_term_meta($id,'_kiosky_legacy_id',$folder['id']);
        return ['id'=>'wp-folder:'.$id,'name'=>$folder['name'],'parentId'=>$parent?'wp-folder:'.$parent:null];
    }

    public function deleteFolder(string $id): void
    {
        $this->writable();
        $result = wp_delete_term((int)substr($id,10),self::TAXONOMY);
        if (is_wp_error($result)) throw new RuntimeException($result->get_error_message(),422);
    }

    public function saveAsset(array $asset, int $maximumBytes = 20000000): array
    {
        $id = str_starts_with($asset['id'],'wp:') ? (int)substr($asset['id'],3) : 0;
        if (!$id) {
            $existing = get_posts(['post_type'=>'attachment','post_status'=>['inherit','trash'],'posts_per_page'=>1,'meta_key'=>'_kiosky_legacy_id','meta_value'=>$asset['id']]);
            if ($existing) $id = (int)$existing[0]->ID;
        }
        $this->writable($id ?: null);
        $src = (string)($asset['src']??'');
        if (!$id && !str_starts_with($src,'data:')) $id = (int)attachment_url_to_postid($src);
        $this->writable($id ?: null);
        if (!$id || $src !== (string)wp_get_attachment_url($id)) {
            if (!str_starts_with($src,'data:')) {
                $response = wp_safe_remote_get($src,['timeout'=>30,'limit_response_size'=>20_000_001]);
                if (is_wp_error($response) || wp_remote_retrieve_response_code($response)!==200) throw new RuntimeException('Das bisherige Medium konnte nicht in WordPress importiert werden.',422);
                $asset['src'] = 'data:application/octet-stream;base64,'.base64_encode(wp_remote_retrieve_body($response));
            }
            $upload = MediaUpload::decode($asset,$maximumBytes);
            $hash = hash('sha256',$upload['bytes']);
            if (!$id || get_post_meta($id,'_kiosky_content_hash',true) !== $hash) {
                $allowSvg = static fn(array $mimes): array => $mimes + ['svg'=>'image/svg+xml'];
                if ($upload['mime']==='image/svg+xml') add_filter('upload_mimes',$allowSvg);
                try { $file = wp_upload_bits($upload['name'],null,$upload['bytes']); }
                finally { if ($upload['mime']==='image/svg+xml') remove_filter('upload_mimes',$allowSvg); }
                if ($file['error']) throw new RuntimeException((string)$file['error'],422);
                $result = wp_insert_attachment(['ID'=>$id,'post_title'=>$asset['name'],'post_mime_type'=>$upload['mime'],'post_status'=>'inherit'], $file['file'],0,true);
                if (is_wp_error($result)) { wp_delete_file($file['file']); throw new RuntimeException($result->get_error_message(),422); }
                $id = (int)$result;
                require_once ABSPATH.'wp-admin/includes/image.php';
                wp_update_attachment_metadata($id,wp_generate_attachment_metadata($id,$file['file']));
                update_post_meta($id,'_kiosky_content_hash',$hash);
            }
        }
        $result = wp_update_post(['ID'=>$id,'post_title'=>$asset['name']],true);
        if (is_wp_error($result)) throw new RuntimeException($result->get_error_message(),422);
        update_post_meta($id,'_kiosky_legacy_id',$asset['id']);
        update_post_meta($id,'_kiosky_media',array_replace($asset['metadata']??[],['deletedAt'=>$asset['deletedAt']??null]));
        $assigned = wp_set_object_terms($id,empty($asset['folderId'])?[]:[(int)substr($asset['folderId'],10)],self::TAXONOMY);
        if (is_wp_error($assigned)) throw new RuntimeException($assigned->get_error_message(),422);
        if (!empty($asset['deletedAt'])) {
            if (!current_user_can('delete_post',$id) && wp_get_current_user()->ID) throw new RuntimeException('Keine Berechtigung zum Löschen dieses Mediums.',403);
            // Attachments need a real trash state even when MEDIA_TRASH is disabled.
            update_post_meta($id,'_wp_trash_meta_status','inherit');
            wp_update_post(['ID'=>$id,'post_status'=>'trash']);
        } elseif (get_post_status($id)==='trash') wp_update_post(['ID'=>$id,'post_status'=>'inherit']);
        return $this->asset($id);
    }

    public function deleteAsset(string $id): void
    {
        $uid = (int)substr($id,3);
        $this->writable($uid);
        if (wp_get_current_user()->ID && !current_user_can('delete_post',$uid)) throw new RuntimeException('Keine Berechtigung zum Löschen dieses Mediums.',403);
        if (!wp_delete_attachment($uid,true)) throw new RuntimeException('CMS-Medium konnte nicht gelöscht werden.',422);
    }
}
