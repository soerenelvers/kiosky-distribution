<?php
declare(strict_types=1);
namespace Kiosky\WordPress;
use Kiosky\Core\PlaybackProofStore;
final class WordPressProofStore implements PlaybackProofStore {
 private function table():string{
  global $wpdb;$table=$wpdb->prefix.'kiosky_playback_receipts';
  if(get_option('kiosky_proof_schema')!=='1'){
   require_once ABSPATH.'wp-admin/includes/upgrade.php';
   dbDelta("CREATE TABLE $table (
 display_id varchar(100) NOT NULL,
 receipt_id varchar(100) NOT NULL,
 play_id varchar(100) NOT NULL,
 slide_id varchar(200) NOT NULL,
 channel_id varchar(100) NOT NULL,
 slide_name varchar(300) NOT NULL,
 channel_name varchar(300) NOT NULL,
 started_at varchar(30) NOT NULL,
 ended_at varchar(30) NOT NULL,
 seconds decimal(12,3) NOT NULL,
 received_at varchar(30) NOT NULL,
 PRIMARY KEY  (display_id,receipt_id),
 UNIQUE KEY proof_interval (display_id,started_at,ended_at),
 KEY proof_period (ended_at,display_id),
 KEY proof_retention (received_at)
) ".$wpdb->get_charset_collate().';');
   if($wpdb->last_error!=='')throw new \RuntimeException('Ausspielnachweise konnten nicht eingerichtet werden.',503);update_option('kiosky_proof_schema','1',false);
  }return $table;
 }
 public function insert(array $rows):void{
  global $wpdb;$table=$this->table();
  foreach($rows as $r){$values=[$r['displayId'],$r['id'],$r['playId'],$r['slideId'],$r['channelId'],$r['slideName'],$r['channelName'],$r['startedAt'],$r['endedAt'],$r['seconds'],$r['receivedAt']];
   if($wpdb->query($wpdb->prepare("INSERT IGNORE INTO %i (display_id,receipt_id,play_id,slide_id,channel_id,slide_name,channel_name,started_at,ended_at,seconds,received_at) VALUES (".implode(',',array_fill(0,11,'%s')).')',$table,...$values))===false)throw new \RuntimeException('Ausspielnachweise konnten nicht gespeichert werden.',503);
  }
  $wpdb->query($wpdb->prepare('DELETE FROM %i WHERE received_at<%s',$table,gmdate('Y-m-d\TH:i:s',time()-90*86400).'.000Z'));
 }
 public function report(string $from,string $until,array $displayIds):array{
  if(!$displayIds)return [];global $wpdb;$table=$this->table();
  $query="SELECT display_id displayId,slide_id slideId,channel_id channelId,MAX(slide_name) slideName,MAX(channel_name) channelName,MIN(started_at) firstAt,MAX(ended_at) lastAt,SUM(seconds) seconds,COUNT(DISTINCT play_id) plays,COUNT(*) intervals FROM %i WHERE ended_at>=%s AND ended_at<%s AND display_id IN (".implode(',',array_fill(0,count($displayIds),'%s')).') GROUP BY display_id,slide_id,channel_id ORDER BY display_id,slideName LIMIT 10000';
  $rows=$wpdb->get_results($wpdb->prepare($query,$table,$from,$until,...$displayIds),ARRAY_A);
  if($wpdb->last_error!=='')throw new \RuntimeException('Ausspielnachweise konnten nicht gelesen werden.',503);return $rows?:[];
 }
}
