/* Keep the app iframe inside the actual visible WordPress viewport, including keyboards. */
(function () {
    'use strict';
    let pending = false;
    function update() { pending = false; const frame = document.querySelector('.kiosky-admin-frame'); if (!frame)
        return; const view = window.visualViewport, bottom = (view?.offsetTop || 0) + (view?.height || innerHeight), top = Math.max(view?.offsetTop || 0, frame.getBoundingClientRect().top), height = Math.max(160, Math.floor(bottom - top)); if (Math.abs(frame.getBoundingClientRect().height - height) > 1)
        frame.style.height = height + 'px'; }
    function schedule() { if (!pending) {
        pending = true;
        requestAnimationFrame(update);
    } }
    window.addEventListener('resize', schedule);
    window.visualViewport?.addEventListener('resize', schedule);
    window.visualViewport?.addEventListener('scroll', schedule);
    if (document.readyState === 'loading')
        document.addEventListener('DOMContentLoaded', schedule, { once: true });
    else
        schedule();
})();
