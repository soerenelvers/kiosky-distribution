=== Kiosky ===
Contributors: kiosky
Author: Sören Elvers
Requires at least: 6.6
Requires PHP: 8.1
Stable tag: 3.21.0
License: GPLv2 or later

Copyright © 2026 Sören Elvers.

Eigenständiges Digital-Signage-System für WordPress.

== Installation ==

1. Das ZIP über Plugins > Installieren hochladen und aktivieren.
2. Im WordPress-Administrationsmenü Kiosky öffnen.
3. Übersicht, Veranstaltungen, Displays, Slides & Kanäle, Zeitplanung, Betrieb und
   Schnittstellen über die Untermenüpunkte unter Kiosky öffnen.

Es wird kein externer Kiosky- oder Node.js-Server benötigt. Benutzer und Anmeldung
werden von WordPress übernommen. Die Kiosky-Fachdaten liegen lokal in der
WordPress-Datenbank. Eine separate Kiosky-Benutzer- oder Mediendatenbank-Navigation
wird in WordPress nicht angezeigt. Öffentliche Player laufen unter /kiosky-player/.

Im WordPress-Benutzermanagement stehen Kiosky Administrator, Kiosky Redakteur und
Kiosky Betrachter als native Rollen zur Verfügung. Bestehende WordPress-
Administratoren, Redakteure und Abonnenten werden automatisch den entsprechenden
Kiosky-Rechtestufen zugeordnet.

CrewBrain-Livetest, Tokenabruf, Vorschau und Import laufen direkt über die
WordPress-HTTP-API. Der automatische Import wird durch WP-Cron ausgeführt. Die
External Control API ist unter /wp-json/kiosky/v1/control erreichbar. Eigene
API-Zugänge werden unter Schnittstellen > Externe API angelegt und über Bearer
oder X-API-Key genutzt. Administratoren und Anwendungspasswörter werden als
bisheriger Zugang weiterhin unterstützt.

== Website-Veranstaltungskalender ==

Der Shortcode `[kiosky_event_calendar]` bindet den öffentlichen Kalender in Seiten
und Beiträge ein. Er erbt Schrift, Farben und Grundgestaltung des aktiven Themes.
Monat, Jahr und Tag sind navigierbar; die Suche erfasst alle freigegebenen
Veranstaltungen.

Optionale Attribute: `upcoming="15"`, `show_search="true"`,
`show_upcoming="true"`, `title="Programm"` und
`upcoming_title="Demnächst"`. Ohne Attribute gelten die zentralen
Kiosky-Einstellungen.

== Einrichtung, Updates und Home Assistant ==

Einstellungen > Kiosky Update-Zugang: eingeschränkten GitHub-Lesetoken für
soerenelvers/kiosky-distribution speichern. Kiosky > Updates > Nach Updates suchen
prüft sofort und umgeht den sechs Stunden gültigen Kiosky-Cache. WordPress plant
Plugin-Prüfungen regulär zweimal täglich; WP-Cron kann sich ohne Seitenaufrufe
verzögern. Der Kiosky-Updateweg prüft die SHA-256-Prüfsumme des Pakets.

Medien stammen aus der WordPress-Mediathek. Lauftexte können im Slide-Editor unter
Element-Hintergrund auf Transparent gesetzt werden.

Home Assistant: https://github.com/soerenelvers/hacs-kiosky in HACS als
benutzerdefiniertes Repository vom Typ Integration hinzufügen. Herunterladen,
Home Assistant neu starten und Kiosky unter Geräte & Dienste hinzufügen.
Externe API-Adresse und einen in Kiosky erzeugten API-Schlüssel verwenden,
keinen GitHub-Token. Benötigt Kiosky ab 3.3.1 und Home Assistant ab 2026.3.0.

Vollständige Anleitung: assets/app/docs/setup-guide.md im Plugin-Paket oder
https://github.com/soerenelvers/hacs-kiosky/blob/main/docs/kiosky-setup.md
