-- Player polling resolves memberships by display, rather than by group.
CREATE INDEX IF NOT EXISTS idx_display_group_members_display
ON display_group_members(display_id, group_id);
