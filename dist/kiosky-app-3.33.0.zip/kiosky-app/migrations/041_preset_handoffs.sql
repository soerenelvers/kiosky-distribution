CREATE TABLE display_preset_handoffs (
  display_id TEXT NOT NULL REFERENCES displays(id) ON DELETE CASCADE,
  preset_key TEXT NOT NULL,
  PRIMARY KEY (display_id, preset_key)
);
