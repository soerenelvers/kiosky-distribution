ALTER TABLE displays ADD COLUMN default_content_type TEXT NOT NULL DEFAULT 'channel' CHECK (default_content_type IN ('channel','slide'));
ALTER TABLE displays ADD COLUMN default_slide_id TEXT REFERENCES slides(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_displays_default_slide ON displays(default_slide_id);
