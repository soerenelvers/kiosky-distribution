ALTER TABLE schedule_entries ADD COLUMN recurrence_timezone TEXT;
