ALTER TABLE locations ADD COLUMN player_background_color TEXT NOT NULL DEFAULT '#000000';
