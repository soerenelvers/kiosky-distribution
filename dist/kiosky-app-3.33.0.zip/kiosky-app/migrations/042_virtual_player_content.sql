-- Preserve the foreign key for physical slides; virtual content is runtime metadata.
ALTER TABLE player_heartbeats ADD COLUMN current_virtual_slide_id TEXT;
