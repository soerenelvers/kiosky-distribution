CREATE TABLE IF NOT EXISTS preset_triggers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  preset_id TEXT NOT NULL REFERENCES operational_presets(id),
  timing_json TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  next_run_at TEXT,
  last_run_at TEXT,
  last_status TEXT,
  last_error TEXT,
  deleted_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_preset_triggers_due ON preset_triggers(enabled,next_run_at) WHERE deleted_at IS NULL;
CREATE TABLE IF NOT EXISTS preset_trigger_runs (
  id TEXT PRIMARY KEY,
  trigger_id TEXT NOT NULL REFERENCES preset_triggers(id),
  preset_id TEXT NOT NULL,
  scheduled_at TEXT NOT NULL,
  executed_at TEXT NOT NULL,
  status TEXT NOT NULL,
  result_json TEXT NOT NULL DEFAULT '{}',
  error TEXT,
  UNIQUE(trigger_id,scheduled_at)
);
CREATE INDEX IF NOT EXISTS idx_preset_trigger_runs_time ON preset_trigger_runs(executed_at DESC);
